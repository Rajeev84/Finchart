# Project Knowledge Base & Recovered Insights

**Document Version**: 1.0  
**Project**: FinChart Engineering Blueprint

---

## 1. Overview

This document consolidates all recovered developer notes, inline code comments, design ideas, architecture rules, and task specifications scattered across `general.md`, `project.md`, `PROJECT_CHARTER.md`, `planning/todo.md`, and code comments into a single unified knowledge base.

---

## 2. Recovered Architectural Principles & Rules

### 2.1 The KISS & Agile Development Principles
- **KISS Principle**: Keep architecture simple and modular. Avoid over-engineering early abstractions while strictly enforcing subsystem boundaries.
- **Unit Testing with Sample Data**: Every core mathematical component (coordinate conversions, TPO calculations, indicator formulas) must have standalone unit test scripts (`test_1.py`, `verify_1.py`, etc.) for rapid verification.
- **Library Modification Rule**: Do not modify standard Python libraries or external dependencies. Keep the charting engine 100% pure Python using native Tkinter and standard math libraries (with optional pandas/numpy integration for data ingest).

### 2.2 Strict Control & Responsibility Boundaries
```
                  ┌─────────────────────────────────────┐
                  │            Public API               │
                  └──────────────────┬──────────────────┘
                                     │
                  ┌──────────────────▼──────────────────┐
                  │          Chart Application          │
                  └──────────────────┬──────────────────┘
                                     │
                  ┌──────────────────▼──────────────────┐
                  │             Chart Core              │
                  └──────────────────┬──────────────────┘
                                     │
                  ┌──────────────────▼──────────────────┐
                  │            State Store              │
                  └──────────────────┬──────────────────┘
                                     │
                  ┌──────────────────▼──────────────────┐
                  │            Layout Engine            │
                  └──────────────────┬──────────────────┘
                                     │
                  ┌──────────────────▼──────────────────┐
                  │          Coordinate Engine          │
                  └──────────────────┬──────────────────┘
                                     │
                  ┌──────────────────▼──────────────────┐
                  │         Rendering Pipeline          │
                  └──────────────────┬──────────────────┘
                                     │
                  ┌──────────────────▼──────────────────┐
                  │           Canvas Backend            │
                  └─────────────────────────────────────┘
```

#### Forbidden Coupling Rules
1. **Renderer Engine** MUST NOT directly import or query `DataStore` or market data dataframes. It receives sanitized `DrawCommand` buffers or visible window data arrays.
2. **Indicator Engine** MUST NOT invoke Tkinter Canvas drawing methods. It calculates series outputs or abstract render primitives.
3. **Coordinate Engine** MUST NOT trigger rendering passes directly. It emits scale/viewport change events to the `EventBus`.
4. **Drawing Objects** MUST NOT mutate global chart layout or pane weights.

---

## 3. Standardized Task Status & Lifecycle System

To prevent AI agents or human developers from jumping straight into coding without prior design, all tasks follow a strict 8-stage lifecycle:

```
[⚪ BACKLOG] ──► [🔵 READY] ──► [🟣 DESIGN] ──► [🟡 IMPLEMENTING]
                                                        │
[🟢 DONE] ◄── [🟤 BENCHMARKING] ◄── [🔴 REVIEW] ◄── [🟠 TESTING]
```

### 3.1 Task Lifecycle Definitions
* **⚪ BACKLOG**: Task identified and scoped to a milestone.
* **🔵 READY**: Specs and dependencies fully known; ready for design.
* **🟣 DESIGN**: Architectural interfaces, data flow, and ADR documented.
* **🟡 IMPLEMENTING**: Code being written following strict solid guidelines.
* **🟠 TESTING**: Unit tests and regression tests passing.
* **🔴 REVIEW**: Code reviewed against architecture rules and typing standards.
* **🟤 BENCHMARKING**: Latency (ms), frame time, and memory measured against targets.
* **🟢 DONE**: Merged, documented, tested, and benchmarked.

---

## 4. LLM Wiki Knowledge System Architecture

To maintain project context across long-running development sessions and multiple AI agent invocations, the project adopts a 3-layer documentation system:

```
┌────────────────────────────────────────────────────────┐
│ Layer 1: PROJECT_CHARTER.md (Immutable Philosophy)     │
├────────────────────────────────────────────────────────┤
│ Layer 2: /docs/ (Formal Engineering Specifications)    │
├────────────────────────────────────────────────────────┤
│ Layer 3: /wiki/ (Living Knowledge Base & Component Map)│
└────────────────────────────────────────────────────────┘
```

### 4.1 Living Wiki Structure (`/wiki/`)
* `wiki/README.md`: Overview and entry point for LLM agents.
* `wiki/architecture.md`: Current subsystem architecture map.
* `wiki/components.md`: Detailed component contracts and invariants.
* `wiki/api.md`: Up-to-date public API reference.
* `wiki/features.md`: Feature registry and implementation status.
* `wiki/keyboard-shortcuts.md`: Key binding registry.
* `wiki/decisions.md`: Summary of Architecture Decision Records (ADRs).
* `wiki/known-issues.md`: Tracked edge cases and known limitations.
* `wiki/changelog.md`: Record of milestone completions.
* `wiki/project_map.yaml`: Machine-readable component/owner mapping.

---

## 5. Recovered Mathematical & UX Parameters

### 5.1 TradingView Visual & UX Ratios
* **Default Dark Palette**:
  - Background: `#131722`
  - Grid Lines: `#2A2E39`
  - Bullish Candle/Wick: `#089981` (TradingView Green)
  - Bearish Candle/Wick: `#F23645` (TradingView Red)
  - Crosshair/Axis Text: `#9598A1` / `#B2B5BE`
  - Axis Background: `#181C27`
* **Default Sizing & Ratios**:
  - Bar Width Ratio: $80\%$ of bar spacing (`bar_spacing * 0.8`).
  - Minimum Wick Width: $1.0\text{ px}$.
  - Price Axis Width: $60\text{ px}$.
  - Time Axis Height: $25\text{ px}$.
  - Default Right Padding: $5\text{ bars}$ empty offset.
  - Zoom Ratio: $1.15\times$ (zoom in), $0.85\times$ (zoom out) centered at mouse cursor X position.
  - Smooth Pan Response: $\le 16\text{ ms}$ render time for instant 60 FPS feedback.
