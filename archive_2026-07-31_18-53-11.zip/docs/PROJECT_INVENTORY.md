# Project Inventory: FinChart Workspace

**Generated Date**: 2026-07-31  
**Project Name**: FinChart (Pure-Python Financial Charting Library)

---

## 1. Overview

This document provides a comprehensive inventory of all assets, folders, prototypes, reference source trees, documentation, and media files present in the `pyEasyChart` workspace.

---

## 2. Directory & Component Classification

| Asset Path | Type | Category | File Count / Size | Status | Primary Purpose / Summary |
|------------|------|----------|-------------------|--------|---------------------------|
| `homework/EasyPyChart/` | Folder | Python Prototype | 31 files (~180 KB) | Legacy Prototype | Monolithic Tkinter Canvas charting prototype (`core.py` ~1970 LOC) with `InteractionManager` and `LayoutManager`. Rich feature set (drawing tools, Market Profile, session JSON). |
| `homework/finchart/` | Folder | Python Prototype | 21 files (~70 KB) | Baseline Architecture | Architecturally modular Tkinter charting engine. Features clean layer separation: `chart/`, `core/`, `coordinates/`, `rendering/`, `data/`, `indicators/`, `themes/`. |
| `homework/pycanvascharts/` | Folder | Python Prototype | 16 files (~50 KB) | Experimental | Modular store/pane architecture with observer pattern. Primarily renders via standalone HTML5 Canvas template/JS generation, though includes Tkinter stubs. |
| `Tradingview lightweight-charts-master/` | Folder | External Reference | 150+ files (TypeScript) | Gold Standard Reference | Open-source TypeScript financial charting library by TradingView. Used as primary reference for UX, rendering invalidation, and interaction model. |
| `KlineCharts pro-main/` | Folder | External Reference | 30+ files (TS / React) | Secondary Reference | Commercial-grade Web charting UI wrapper for KLineCharts. Used as secondary reference for indicator management and plugin architecture concepts. |
| `spec.md` | File | Root Specification | 562 lines (7 KB) | Active Guidance | Master prompt defining the 7-phase requirement for building the complete engineering blueprint. |
| `project.md` | File | Core Charter | 691 lines (11 KB) | Design Specification | Detailed requirements document outlining architecture principles, interaction standards, and technical specifications. |
| `PROJECT_CHARTER.md` | File | Project Vision | 166 lines (2 KB) | Vision Document | High-level mission, guiding principles, milestone list, and definition of done for FinChart. |
| `EXECUTION_PROMPT.md` | File | Execution Guide | 59 lines (1.6 KB) | Agent Guidance | Architectural execution standards and prompt rules for subsystem development. |
| `general.md` | File | Design & Wiki Notes | 1332 lines (17.8 KB) | Living Knowledge | Task status system, token-efficient response guides, architecture rules, and LLM Wiki maintenance guide. |
| `planning/todo.md` | File | Project Roadmap | 789 lines (9 KB) | Workflow Plan | 20-phase roadmap from setup through release, including task taxonomy and dependency graphs. |
| `homework/EasyPyChart_vs_pycanvascharts.md` | File | Analysis Document | 101 lines (7.3 KB) | Comparative Analysis | Feature-by-feature comparison matrix between EasyPyChart and pycanvascharts. |
| `candlestick_chart.html` | File | HTML Prototype | 41 KB | Standalone Output | Self-contained HTML/JS candlestick renderer generated from pycanvascharts exports. |
| `chart default mode.png` | File | Screenshot | 103 KB | Visual Reference | Image capture showing standard EasyPyChart rendering mode. |
| `chart fully zoomed in.png` | File | Screenshot | 79.5 KB | Visual Reference | Image capture showing EasyPyChart zoomed-in rendering state. |
| `chart fully zoomed out.png` | File | Screenshot | 105.9 KB | Visual Reference | Image capture showing EasyPyChart zoomed-out rendering state. |

---

## 3. Subsystem Inventory Summary

### 3.1 Python Prototype Comparison Matrix

```
                          ┌───────────────────────────┐
                          │   FinChart Workspace      │
                          └─────────────┬─────────────┘
                                        │
      ┌─────────────────────────────────┼─────────────────────────────────┐
      ▼                                 ▼                                 ▼
┌──────────────┐                ┌──────────────┐                ┌─────────────────┐
│ EasyPyChart  │                │   finchart   │                │ pycanvascharts  │
├──────────────┤                ├──────────────┤                ├─────────────────┤
│ Monolithic   │                │ Modular Architecture           │ HTML/JS-centric │
│ Rich Features│                │ Clean Pipeline               │ Store Observer  │
└──────────────┘                └──────────────┘                └─────────────────┘
```

### 3.2 Reference Source Trees
1. **TradingView Lightweight Charts (`Tradingview lightweight-charts-master/src/`)**:
   - `model/`: State domain objects (time scale, price scale, series, pane, crosshair).
   - `views/`: Coordinate calculation for items.
   - `renderers/`: Immediate-mode canvas draw routines.
   - `gui/`: DOM canvas containers, mouse/touch event handlers.

2. **KLineCharts Pro (`KlineCharts pro-main/src/`)**:
   - `component/`: React UI layout (toolbars, indicator pickers, setting dialogs).
   - `extension/`: Custom indicators and drawing shapes.
   - `widget/`: Core canvas controller wrappers.
