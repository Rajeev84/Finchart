# Performance Specification & Benchmarking Strategy

**Document Version**: 1.0  
**Project**: FinChart Engineering Blueprint

---

## 1. Executive Performance Mandate

Because Python is an interpreted language and Tkinter interfaces with Tcl/Tk via C extensions, UI responsiveness depends heavily on minimizing object allocations and reducing C-level Canvas operations.

---

## 2. Quantitative Performance Targets

| Benchmark Metric | Target Threshold | Degradation Warning Limit | Failure Threshold |
|------------------|------------------|---------------------------|-------------------|
| **Frame Rate (FPS during pan/zoom)** | **60 FPS** (16.6 ms/frame) | 45 FPS (22 ms/frame) | < 30 FPS (>33 ms/frame) |
| **Crosshair Move Latency** | **< 4 ms** | 8 ms | > 16 ms |
| **Initial Load Time (10,000 candles)** | **< 100 ms** | 250 ms | > 500 ms |
| **Streaming Bar Update Latency** | **< 2 ms** | 5 ms | > 10 ms |
| **Memory Consumption (50,000 bars)** | **< 45 MB** | 75 MB | > 120 MB |
| **Canvas Item Allocations (Zoom step)** | **0 new items** (Pool hit 100%) | < 50 items | > 200 items |

---

## 3. Mandatory Optimization Strategies

### 3.1 Object Pooling (`CanvasItemPool`)
To maintain zero object allocation during continuous user interactions (pan/zoom), all Tkinter Canvas items are acquired from and released to a pre-allocated item pool.

### 3.2 Viewport Index Clipping
Never iterate over the full dataset during a render pass. Convert viewport left and right pixel edges to integer bar indices $i_{\text{start}}$ and $i_{\text{end}}$, and process only visible candles.

### 3.3 Deferred Invalidation Scheduler
Wrap all visual dirty signals in a frame scheduler using `widget.after_idle()`. If a user streams 50 tick updates in a single millisecond, only 1 frame render pass executes at the end of the event cycle.

### 3.4 Spatial Indexing for Hit-Testing
Shape selection and crosshair handle hit-testing use bounding box (`Rect`) spatial partitioning to achieve $O(1)$ or $O(\log N)$ selection speed instead of brute-force $O(N)$ linear scans.

---

## 4. Benchmarking Suite Protocol

A standard benchmark script (`verify_benchmark.py`) will automatically measure and log performance metrics:

```python
def benchmark_render_loop(chart: ChartWidget, bars_count: int = 10000) -> float:
    data = generate_sample_ohlcv(bars_count)
    chart.set_data(data)
    
    start_time = time.perf_counter()
    frames = 120
    for i in range(frames):
        chart.pan(delta_x=2.5)
        chart.update_idletasks() # Flush Tkinter queue
    
    elapsed = time.perf_counter() - start_time
    fps = frames / elapsed
    ms_per_frame = (elapsed / frames) * 1000.0
    print(f"Benchmark Results ({bars_count} bars): {fps:.2f} FPS ({ms_per_frame:.2f} ms/frame)")
    return ms_per_frame
```
