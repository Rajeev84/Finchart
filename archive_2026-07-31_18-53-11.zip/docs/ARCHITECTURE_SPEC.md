# Master Architecture Specification: FinChart Engine

**Document Version**: 1.0  
**Project**: FinChart (Pure-Python Financial Charting Library)  
**Status**: Approved Architecture Blueprint

---

## 1. Executive Summary & Vision

FinChart is a professional, high-performance financial charting library implemented in **100% pure Python** using **Tkinter Canvas** as the rendering backend. Its core mission is to provide the responsiveness, interaction quality, aesthetic elegance, and extensibility of **TradingView Lightweight Charts** while remaining completely native to standard Python GUI applications.

---

## 2. Goals & Non-Goals

### 2.1 Primary Goals
1. **TradingView-Grade Interaction**: Smooth mouse wheel zooming around cursor, low-latency drag panning, interactive crosshairs, snapping, shape resize handles, and multi-pane synchronization.
2. **High-Performance Tkinter Rendering**: Stable 60 FPS rendering for datasets up to 100,000 bars using canvas item pooling, viewport culling, dirty layer isolation, and deferred invalidation.
3. **Pure Python Architecture**: Zero heavy external C/C++ or web dependencies. Works out-of-the-box with standard Python `tkinter`.
4. **Rich Extensibility**: Plugin engines for indicators, custom series types, overlay drawing tools, themes, and mouse interaction controllers.

### 2.2 Non-Goals
* FinChart is **NOT** a web-wrapper or HTML/JS renderer (unlike `pycanvascharts` export mode or `pywebview` wrappers).
* FinChart is **NOT** a full trading application terminal UI (it is a reusable library component).

---

## 3. High-Level Subsystem Architecture

FinChart is composed of 12 decoupled core subsystems:

```mermaid
graph TD
    API[Public API / ChartWidget] --> Core[Chart Core Orchestrator]
    Core --> Store[Data Store]
    Core --> Layout[Layout Engine]
    Core --> EventBus[Event Bus]
    
    EventBus --> Coord[Coordinate Engine]
    EventBus --> Inter[Interaction Engine]
    
    Layout --> Panes[Pane System]
    Panes --> Scales[Price & Time Scales]
    
    Coord --> Pipeline[Rendering Pipeline]
    
    Pipeline --> LayerMgr[Layer Manager]
    Pipeline --> ItemPool[Canvas Item Pool]
    
    LayerMgr --> CanvasBackend[Tkinter Canvas Backend]
    
    Plugins[Indicator & Drawing Plugins] --> Pipeline
    Plugins --> EventBus
```

---

## 4. Subsystem Responsibility Matrix

| Subsystem | Primary Responsibility | Input | Output | Forbidden Actions |
|-----------|------------------------|-------|--------|-------------------|
| **Public API (`ChartWidget`)** | User-facing entry point, container frame | User calls (`set_data`, `add_indicator`) | Rendered GUI widget | Must not contain low-level draw loops |
| **Data Store (`DataStore`)** | Manages OHLCV buffers, streaming updates, indexing | Raw OHLCV lists or pandas DataFrames | Normalized bar slices & price ranges | Must not depend on Tkinter or pixel metrics |
| **Coordinate Engine (`CoordinateEngine`)** | Data $\leftrightarrow$ Pixel coordinate transformations | Bar index, price, viewport dimensions | Pixel X/Y coords, bar widths | Must not execute canvas draw commands |
| **Layout Engine (`LayoutEngine`)** | Multi-pane height/weight partitioning | Pane weight ratios, window size | Viewport bounding boxes (`Rect`) | Must not store price or bar data |
| **Rendering Pipeline (`RenderingPipeline`)** | Draw command batching, layer sorting, render loop | List of `DrawCommand` objects | Optimized Tkinter Canvas items | Must not perform business/indicator math |
| **Item Pool (`CanvasItemPool`)** | Reusable C-level canvas item storage | `item_type` request | Re-configured item ID | Must not manage z-ordering |
| **Layer Manager (`LayerManager`)** | Tag isolation and z-index ordering per layer | Render layer Enum | Canvas tag strings | Must not manipulate item coordinates |
| **Interaction Engine (`InteractionEngine`)** | Mouse/keyboard event interpretation, tool FSM | Native Tkinter mouse/key events | Intent events (`PAN`, `ZOOM`, `SELECT`) | Must not draw directly on canvas |
| **Indicator Engine (`IndicatorEngine`)** | Calculation of technical indicators | Visible data slices | `DrawCommand` lists or series lines | Must not access mouse state |
| **Drawing Tool Engine (`DrawingEngine`)** | Interactive shape placement, hit-testing, drag handles | Mouse click coords, active shape | Interactive canvas shapes | Must not alter main price scales |

---

## 5. Invalidation & Render Pipeline Architecture

To achieve 60 FPS without redundant canvas item creation, FinChart uses a **retained-mode pipeline with deferred invalidation**:

```
State Change (Pan / Zoom / Data)
         │
         ▼
Emit EventBus Signal
         │
         ▼
Invalidate Specific Layers (e.g., Layer.SERIES, Layer.CROSSHAIR)
         │
         ▼
Schedule Deferral (`after_idle`) ──► Merge duplicate render requests in frame
         │
         ▼
Execute Pipeline Render Pass
         ├── 1. Acquire Canvas Item IDs from Item Pool
         ├── 2. Update item coords & options via `coords()` and `itemconfig()`
         └── 3. Release unneeded items to pool (state='hidden')
```

### 5.1 Layer Ordering Hierarchy
Render items are assigned to discrete z-ordered layers using canvas tag isolation:

```
[Layer 8: OVERLAY]    (Alerts, debug overlays)
[Layer 7: UI]         (Resize handles, toolbar elements)
[Layer 6: CROSSHAIR]  (Cursor lines, price/time axis labels, bar highlight)
[Layer 5: DRAWING]    (Trend lines, rectangles, position tools)
[Layer 4: INDICATORS] (SMA, EMA, RSI, MACD polylines)
[Layer 3: SERIES]     (Candlestick bodies & wicks, OHLC bars, volume)
[Layer 2: GRID]       (Horizontal/vertical grid lines, tick marks)
[Layer 1: BACKGROUND] (Canvas background rect)
```

---

## 6. Mathematical Viewport Transformation Matrix

$$\begin{aligned}
X_{\text{pixel}} &= X_{\text{left}} + \text{offset}_x + i \cdot S_{\text{bar}} \\
i &= \frac{X_{\text{pixel}} - X_{\text{left}} - \text{offset}_x}{S_{\text{bar}}} \\
Y_{\text{pixel}} &= Y_{\text{bottom}} - \left( \frac{P - P_{\text{min}}}{P_{\text{max}} - P_{\text{min}}} \right) \cdot H_{\text{viewport}} \\
P &= P_{\text{min}} + \left( \frac{Y_{\text{bottom}} - Y_{\text{pixel}}}{H_{\text{viewport}}} \right) \cdot (P_{\text{max}} - P_{\text{min}})
\end{aligned}$$

Where:
* $i$: Bar index ($\mathbb{R}$, floating point for sub-bar precision)
* $S_{\text{bar}}$: Bar spacing in pixels (`time_scale.bar_spacing`)
* $\text{offset}_x$: Pixel panning offset (`time_scale.offset`)
* $P$: Financial asset price
* $P_{\text{min}}, P_{\text{max}}$: Minimum and maximum prices in current visible range (including top/bottom padding)
* $H_{\text{viewport}}$: Height of the target pane viewport in pixels

---

## 7. Directory & Module Package Map

```text
finchart/
├── __init__.py                # Package version & public exports
├── py.typed                   # PEP 561 type marker
├── api/
│   ├── __init__.py
│   └── widget.py              # Main ChartWidget public API
├── core/
│   ├── __init__.py
│   ├── types.py               # Core data models (OHLCV, Point, Rect, Viewport, Color)
│   ├── events.py              # EventBus pub/sub implementation
│   └── store.py               # DataStore time-series buffer
├── coordinates/
│   ├── __init__.py
│   ├── engine.py              # CoordinateEngine orchestrator
│   ├── time_scale.py          # TimeScale state & index mapping
│   └── price_scale.py         # PriceScale state & auto-scaling
├── layout/
│   ├── __init__.py
│   └── engine.py              # Multi-pane LayoutEngine
├── rendering/
│   ├── __init__.py
│   ├── pipeline.py            # RenderingPipeline & DrawCommand
│   ├── pool.py                # CanvasItemPool allocation manager
│   ├── layer.py               # LayerManager tag z-ordering
│   ├── series.py              # Candlestick & Line series renderers
│   ├── grid.py                # Axis & Grid line renderers
│   └── crosshair.py           # Crosshair & Tooltip renderers
├── interaction/
│   ├── __init__.py
│   ├── controller.py          # Mouse & Keyboard interaction controller
│   └── hit_test.py            # Hit testing math primitives
├── indicators/
│   ├── __init__.py
│   ├── base.py                # Abstract Indicator base class
│   └── standard.py            # Built-in SMA, EMA, RSI, MACD, BB
├── drawing/
│   ├── __init__.py
│   ├── base.py                # Abstract DrawingTool base class
│   └── tools.py               # TrendLine, Rectangle, HLine, VLine, PositionTool
├── themes/
│   ├── __init__.py
│   └── style.py               # Color schemes (Dark, Light, Custom)
└── utils/
    ├── __init__.py
    └── math.py                # Nice-number step calculation algorithms
```
