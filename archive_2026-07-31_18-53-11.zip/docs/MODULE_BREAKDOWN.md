# Comprehensive Module & Subsystem Breakdown

**Document Version**: 1.0  
**Project**: FinChart Engineering Blueprint

---

## 1. Subsystem Overview

This document provides a class-level breakdown for every core module in the FinChart library, detailing responsibilities, public interfaces, dependencies, and internal state.

---

## 2. Core Subsystems & Class Descriptions

### 2.1 Core Types & Domain Models (`finchart.core.types`)

#### `OHLCV`
* **Type**: Immutable Dataclass (`frozen=True`, `slots=True`)
* **Purpose**: Represents a single candlestick data bar.
* **Fields**: `timestamp: float`, `open: float`, `high: float`, `low: float`, `close: float`, `volume: float = 0.0`.
* **Properties**: `body_top`, `body_bottom`, `is_bullish`, `is_bearish`, `range`, `body_size`, `upper_wick`, `lower_wick`.

#### `Viewport`
* **Type**: Mutable Dataclass (`slots=True`)
* **Purpose**: Represents a 2D bounding rectangle in pixel space.
* **Fields**: `x: float`, `y: float`, `width: float`, `height: float`.
* **Properties**: `left`, `right`, `top`, `bottom`, `center_x`, `center_y`.
* **Methods**: `contains(px, py) -> bool`, `inset(dx, dy) -> Viewport`.

#### `Color`
* **Type**: Dataclass (`slots=True`)
* **Purpose**: Color representation supporting Hex and RGBA string formatting.
* **Fields**: `r: int`, `g: int`, `b: int`, `a: float = 1.0`.
* **Methods**: `to_hex() -> str`, `to_rgba() -> str`, `from_hex(hex_str: str) -> Color`.

---

### 2.2 Event System (`finchart.core.events`)

#### `EventBus`
* **Type**: Class
* **Purpose**: Decoupled pub/sub event dispatcher using weak references to eliminate memory leaks.
* **Methods**:
  - `subscribe(event_type: EventType, callback: Callable[[Event], None]) -> int`
  - `unsubscribe(sub_id: int) -> None`
  - `emit(event: Event) -> None`
  - `emit_new(event_type: EventType, source: Any, **data) -> None`

---

### 2.3 Data Store (`finchart.core.store`)

#### `DataStore`
* **Type**: Class
* **Purpose**: Maintains time-series OHLCV bar array, index lookup maps, and visible range price queries.
* **Methods**:
  - `set_data(data: List[OHLCV]) -> None`
  - `append(bar: OHLCV) -> None`
  - `update_last(bar: OHLCV) -> None`
  - `get_price_range(start_idx: int, end_idx: int) -> Tuple[float, float]`
  - `get_index_by_timestamp(timestamp: float) -> int`

---

### 2.4 Coordinate Engine (`finchart.coordinates.engine`)

#### `CoordinateEngine`
* **Type**: Class
* **Purpose**: Transforms between bar index / price values and canvas pixel coordinates. Maintains `TimeScale` and `PriceScale` objects.
* **Methods**:
  - `index_to_x(index: float) -> float`
  - `x_to_index(x: float) -> float`
  - `price_to_y(price: float) -> float`
  - `y_to_price(y: float) -> float`
  - `zoom(factor: float, anchor_x: Optional[float]) -> None`
  - `pan(delta_x: float) -> None`
  - `set_price_range(min_price: float, max_price: float) -> None`

---

### 2.5 Layout Engine (`finchart.layout.engine`)

#### `LayoutEngine`
* **Type**: Class
* **Purpose**: Partition canvas space into multi-pane subplots (e.g., Main Candlestick Pane, Volume Pane, RSI Pane) based on relative weights.
* **Methods**:
  - `add_pane(name: str, weight: float) -> Pane`
  - `remove_pane(name: str) -> None`
  - `recalculate(total_width: float, total_height: float) -> Dict[str, Viewport]`

---

### 2.6 Rendering Pipeline (`finchart.rendering.pipeline`)

#### `RenderingPipeline`
* **Type**: Class
* **Purpose**: Retained-mode frame scheduler, draw command buffer manager, and canvas sync engine.
* **Methods**:
  - `schedule_render(full_redraw: bool = False) -> None`
  - `schedule_layer(layer: Layer) -> None`
  - `add_command(command: DrawCommand) -> None`
  - `force_full_redraw() -> None`

#### `CanvasItemPool`
* **Type**: Class
* **Purpose**: Object pool for Tkinter Canvas item IDs.
* **Methods**:
  - `acquire(item_type: str) -> int`
  - `release(item_id: int) -> None`
  - `release_all(item_ids: List[int]) -> None`

---

### 2.7 Interaction Engine (`finchart.interaction.controller`)

#### `InteractionController`
* **Type**: Class
* **Purpose**: Binds native Tkinter mouse and keyboard events, translates user input into pan/zoom commands, shape drag handles, or crosshair motion.
* **Methods**:
  - `bind_canvas(canvas: tk.Canvas) -> None`
  - `set_active_tool(tool_name: str) -> None`
  - `_on_mouse_wheel(event: tk.Event) -> None`
  - `_on_mouse_drag(event: tk.Event) -> None`

---

### 2.8 Indicator Framework (`finchart.indicators.base`)

#### `Indicator` (Abstract Base Class)
* **Purpose**: Base contract for all technical indicators.
* **Abstract Methods**:
  - `calculate(data: List[OHLCV]) -> IndicatorResult`
  - `render_commands(coord_engine: CoordinateEngine, start_idx: int, end_idx: int) -> List[DrawCommand]`

---

### 2.9 Drawing Tools (`finchart.drawing.base`)

#### `DrawingTool` (Abstract Base Class)
* **Purpose**: Base contract for interactive drawing shapes (lines, rectangles, channels, position tools).
* **Abstract Methods**:
  - `on_click(point: Point, coord_engine: CoordinateEngine) -> bool`
  - `hit_test(px: float, py: float, coord_engine: CoordinateEngine) -> Optional[str]`
  - `render_commands(coord_engine: CoordinateEngine) -> List[DrawCommand]`
