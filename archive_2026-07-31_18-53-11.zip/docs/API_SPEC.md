# Public API & Plugin System Specification

**Document Version**: 1.0  
**Project**: FinChart Engineering Blueprint

---

## 1. Overview & API Design Philosophy

The FinChart public API is designed to be **intuitive, minimal, discoverable, Pythonic, and strongly typed**. It conceals all internal coordinate math, invalidation scheduling, and object pooling behind a clean high-level interface.

---

## 2. Public API Surface (`finchart.ChartWidget`)

The primary entry point for library consumers is `ChartWidget`, a subclass of `tkinter.Frame`.

```python
class ChartWidget(tk.Frame):
    def __init__(
        self,
        parent: tk.Widget,
        width: int = 800,
        height: int = 600,
        theme: Optional[Theme] = None,
        **kwargs
    ) -> None: ...

    # --- Data Ingestion ---
    def set_data(self, data: List[OHLCV] | pd.DataFrame) -> None: ...
    def append(self, bar: OHLCV | dict) -> None: ...
    def update_last(self, bar: OHLCV | dict) -> None: ...

    # --- Chart Series & Types ---
    def set_chart_type(self, chart_type: ChartType) -> None: ...

    # --- Indicator API ---
    def add_indicator(self, indicator: Indicator, pane: Optional[str] = None) -> IndicatorHandle: ...
    def remove_indicator(self, handle: IndicatorHandle) -> None: ...
    def clear_indicators(self) -> None: ...

    # --- Interactive Drawing Tools ---
    def set_active_tool(self, tool_type: str, **options) -> None: ...
    def clear_drawings(self) -> None: ...

    # --- Viewport & Navigation ---
    def fit_content(self) -> None: ...
    def zoom(self, factor: float) -> None: ...
    def pan(self, delta_bars: float) -> None: ...

    # --- Persistence ---
    def save_session(self, filepath: str) -> None: ...
    def load_session(self, filepath: str) -> None: ...
```

---

## 3. Indicator Plugin Extension Interface

Custom indicators extend the abstract `Indicator` class and register with the indicator engine:

```python
class Indicator(ABC):
    def __init__(self, name: str, params: Dict[str, Any]) -> None:
        self.name = name
        self.params = params

    @abstractmethod
    def calculate(self, data: List[OHLCV]) -> IndicatorResult:
        """Calculate numerical output arrays from OHLCV input."""
        pass

    @abstractmethod
    def render_commands(
        self,
        coord_engine: CoordinateEngine,
        start_idx: int,
        end_idx: int
    ) -> List[DrawCommand]:
        """Generate abstract draw commands for visible bar range."""
        pass
```

### 3.1 Example Custom Indicator (SMA Implementation)
```python
class SMA(Indicator):
    def __init__(self, period: int = 20, color: str = "#2196F3") -> None:
        super().__init__("SMA", {"period": period})
        self.period = period
        self.color = Color.from_hex(color)
        self._values: List[Optional[float]] = []

    def calculate(self, data: List[OHLCV]) -> IndicatorResult:
        closes = [b.close for b in data]
        self._values = []
        for i in range(len(closes)):
            if i < self.period - 1:
                self._values.append(None)
            else:
                window = closes[i - self.period + 1 : i + 1]
                self._values.append(sum(window) / self.period)
        return IndicatorResult(values={"sma": self._values})

    def render_commands(
        self, coord_engine: CoordinateEngine, start_idx: int, end_idx: int
    ) -> List[DrawCommand]:
        points = []
        for i in range(start_idx, end_idx):
            val = self._values[i]
            if val is not None:
                x = coord_engine.index_to_x(i)
                y = coord_engine.price_to_y(val)
                points.extend([x, y])

        if len(points) < 4:
            return []

        return [
            DrawCommand(
                layer=Layer.INDICATORS,
                tag=f"sma_{self.period}",
                item_type="line",
                coords=tuple(points),
                options={"fill": self.color.to_hex(), "width": 1.5},
            )
        ]
```

---

## 4. Session Persistence Schema (JSON Specification)

```json
{
  "version": "1.0",
  "symbol": "BTCUSDT",
  "timeframe": "1h",
  "layout": {
    "panes": [
      {"id": "main", "weight": 0.75},
      {"id": "rsi_pane", "weight": 0.25}
    ]
  },
  "indicators": [
    {
      "id": "sma_20",
      "type": "SMA",
      "params": {"period": 20, "color": "#2196F3"},
      "pane": "main"
    }
  ],
  "drawings": [
    {
      "id": "trendline_104",
      "type": "trendline",
      "points": [
        {"timestamp": 1700000000, "price": 34500.0},
        {"timestamp": 1700050000, "price": 36200.0}
      ],
      "style": {"color": "#FF9F1C", "width": 2}
    }
  ]
}
```
