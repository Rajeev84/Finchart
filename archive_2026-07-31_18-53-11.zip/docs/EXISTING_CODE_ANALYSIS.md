# Existing Code Analysis & Reverse Engineering Report

**Document Version**: 1.0  
**Project**: FinChart Engineering Blueprint

---

## 1. Overview

This document presents a reverse-engineering analysis of all existing prototypes in the workspace (`EasyPyChart`, `pycanvascharts`, `finchart`), along with architectural studies of reference libraries (**TradingView Lightweight Charts** and **KLineCharts Pro**).

---

## 2. Reverse Engineering Existing Python Prototypes

### 2.1 EasyPyChart Deep Dive (`homework/EasyPyChart/`)
* **Purpose**: Production-focused interactive trading chart widget written in Tkinter.
* **Architecture**:
  - `core.py` (1,970 LOC): Monolithic `tk.Frame` subclass (`EasyPyChart`). Handles rendering, mouse/keyboard bindings, coordinate transforms (`transform_index_to_x`, `transform_price_to_y`), Market Profile (TPO) calculation, shape drawing (rect, line, hline, vline, text), selection handles, and JSON state persistence (`save_state`/`load_state`).
  - `interaction_manager.py` (1,375 LOC): Outer event controller and state machine for interactive tool multi-phase placement (Long/Short position, trend lines, angle lines).
  - `layout_manager.py` (670 LOC): Symbol/timeframe session state store and global indicator manager.
* **Render Pipeline**: Full wipe-and-redraw canvas approach (`self.canvas.delete('all')`). Every pan/zoom step deletes all canvas items and recreates candles, axes, series polylines, and drawing objects.
* **Strengths**:
  - Extremely rich feature coverage: multi-phase drawing tools, drag/resize handles, Market Profile (TPO) overlay with VAH/VAL/POC detection, multi-symbol session persistence.
  - Good hit-testing logic for line/rectangle handles.
* **Weaknesses & Limitations**:
  - Monolithic tight coupling in `core.py`.
  - Inefficient render loop (`delete('all')`), causing UI lag with large datasets (>5,000 candles).
  - Lack of type annotations, no explicit event bus (uses a single dictionary-based `callback` function).
* **Reuse Recommendation**: **Discard `core.py` rendering code; REUSE interaction workflows & math algorithms** (such as shape hit-testing, position tool calculations, and TPO value area algorithms).

---

### 2.2 pycanvascharts (`homework/pycanvascharts/`)
* **Purpose**: Modular TradingView/KLineCharts-inspired charting library designed for Jupyter and standalone Web output.
* **Architecture**:
  - Modular structure (`core/chart.py`, `core/store.py`, `core/pane.py`, `core/axis.py`, `core/styles.py`, `core/events.py`).
  - Implements an observer pattern (`ChartStore.subscribe`) and an `EventBus`.
  - Uses double-canvas rendering via HTML5 Canvas generation (`save()` / `show()`) with JS templates.
* **Strengths**:
  - Clean separation of concerns (Store vs. Pane vs. Axis vs. Styles).
  - DPR-aware HTML5 canvas rendering script.
  - Comprehensive `Styles` and `Theme` data structures.
* **Weaknesses**:
  - Tkinter rendering backend (`renderers/canvas_renderer.py`) is an incomplete stub.
  - No interactive drawing tools or hit-testing for desktop Python.
* **Reuse Recommendation**: **REUSE architectural concepts** (Store subscription model, Pane layout separation, Theme/Style data models). **DISCARD the HTML/JS renderer generator** (since FinChart targets pure Tkinter Canvas).

---

### 2.3 finchart Prototype (`homework/finchart/`)
* **Purpose**: Architectural prototype built specifically for high-performance pure Tkinter Canvas rendering.
* **Architecture**:
  - `chart/widget.py`: `ChartWidget` orchestrator.
  - `coordinates/engine.py`: `CoordinateEngine` with `TimeScale`, `PriceScale`, `Viewport`, and cached index-to-pixel / price-to-pixel conversions.
  - `rendering/pipeline.py`: Retained-mode `RenderingPipeline` with canvas item pooling (`CanvasItemPool`), layer isolation via tags (`LayerManager`), and dirty-layer rendering (`schedule_layer`).
  - `rendering/series.py`, `rendering/grid.py`, `rendering/crosshair.py`: Modular renderers emitting abstract `DrawCommand` instances.
  - `core/events.py`: Decoupled `EventBus` using weak references.
* **Strengths**:
  - Best architectural decomposition among all 3 Python prototypes.
  - Canvas item recycling pool (`CanvasItemPool`) dramatically reduces Tkinter C-level allocation overhead.
  - Retained-mode dirty layer scheduling (`Layer.GRID`, `Layer.SERIES`, `Layer.CROSSHAIR`).
  - Strict separation of coordinates, data, events, and rendering.
* **Weaknesses**:
  - Missing interactive drawing tools and position tools.
  - Lacks session persistence and Market Profile.
* **Reuse Recommendation**: **REUSE AS ARCHITECTURAL BASELINE**. `finchart` provides the ideal pure-Tkinter rendering pipeline and coordinate transformation structure for FinChart.

---

## 3. Reverse Engineering Reference Open-Source Libraries

### 3.1 TradingView Lightweight Charts (LWC)
* **Architecture Overview**:
  - **Model-View-Renderer Pattern**: Complete isolation between state models (`TimeScale`, `PriceScale`, `Series`), views (`SeriesPaneView`, `CrosshairPaneView`), and immediate-mode renderers (`CandlesticksRenderer`, `LineRenderer`).
  - **Invalidation System**: `InvalidateMask` tracks dirty state levels (`None`, `FitContent`, `ApplyRange`, `Full`). Only dirty subsystems recompute geometry.
  - **Time Scale & Index Space**: All series map timestamps to integer bar indices. Panning/zooming updates index offset and bar spacing; price scaling occurs per visible index range.
  - **Pane Management**: Multi-pane layout engine with proportional height splitting.
* **Key Lessons for FinChart**:
  - Separate coordinate resolution (index $\leftrightarrow$ X, price $\leftrightarrow$ Y) into an isolated coordinate engine.
  - Implement deferred invalidation (`after_idle` scheduling) so multiple state mutations trigger only a single render pass per frame.

### 3.2 KLineCharts Pro
* **Architecture Overview**:
  - Extensible plugin system for custom indicators (`extension/indicator`) and overlay drawings (`extension/overlay`).
  - Centralized store for chart configuration, theme management, and locale string lookup.
* **Key Lessons for FinChart**:
  - Design indicators and drawing tools as self-contained plugin classes with standard lifecycle methods (`calc`, `draw`, `hit_test`).

---

## 4. Comprehensive Comparison Table

| Metric | EasyPyChart | pycanvascharts | finchart Prototype | TradingView LWC | FinChart Target Architecture |
|--------|-------------|----------------|--------------------|-----------------|------------------------------|
| **Rendering Backend** | Tkinter Canvas (Full Redraw) | HTML5 Canvas (JS export) | Tkinter Canvas (Item Pool + Layers) | HTML5 2D Canvas (Immediate) | **Tkinter Canvas (Retained + Item Pool)** |
| **Architecture** | Monolithic (`core.py`) | Modular Store/Pane | Modular Subsystems | Model-View-Renderer | **Layered Decoupled Subsystems** |
| **Render Invalidation** | `delete('all')` on every frame | Full redraw per update | Layered invalidation (`schedule_layer`) | InvalidateMask (Deferred) | **Deferred Dirty-Layer Scheduler** |
| **Item Allocation** | High overhead (new items/frame) | N/A (JS immediate) | Low (Item Pool acquire/release) | Zero (immediate canvas) | **Object Pool (`CanvasItemPool`)** |
| **Drawing Tools** | Rich (Line, Rect, Pos, TPO) | Basic stubs | None | Plugins | **Extensible Drawing System (from EasyPyChart)** |
| **Indicator Framework** | Manual series list | Basic `SMA` class | Abstract `Indicator` base | Plugin Series Primitives | **Plugin Indicator Engine** |
| **Performance (10k bars)** | Low (~15-20 FPS) | High (Browser JS) | High (60 FPS Tkinter target) | Ultra High (60 FPS) | **High (60 FPS target via viewport clipping)** |
