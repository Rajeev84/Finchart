# Technical Risk Analysis & Mitigation Strategy

**Document Version**: 1.0  
**Project**: FinChart Engineering Blueprint

---

## 1. Risk Assessment Framework

This document identifies technical, performance, architectural, and compatibility risks associated with building a TradingView-quality charting library in pure Python using Tkinter Canvas, along with concrete mitigation strategies.

---

## 2. Risk Matrix

```
       HIGH  │ [R1: Tkinter Latency]        [R2: Floating Precision]
             │
   I         │
   M   MED   │ [R3: Memory Leakage]        [R4: Multi-Pane Scaling]
   P         │
   A         │
   C   LOW   │ [R5: OS Font Rendering]
   T         └────────────────────────────────────────────────────────
                      LOW                    MED                   HIGH
                                     PROBABILITY
```

---

## 3. Detailed Risk Identification & Mitigations

### 3.1 Risk 1: Tkinter Canvas Overhead at High Bar Counts (R1)
* **Severity**: Critical | **Probability**: High
* **Risk Description**: Creating thousands of C-level Tkinter Canvas items for 50,000+ candles causes severe render lag and UI freezes during dragging or zooming.
* **Mitigation Strategy**:
  1. Implement `CanvasItemPool` to recycle item IDs rather than destroying/re-allocating items on each frame.
  2. Perform viewport index culling so that only candles within the visible pixel range (typically 50 to 500 bars) are drawn.
  3. Defer render execution using `after_idle` to collapse multi-event updates into a single render frame.

---

### 3.2 Risk 2: Floating Point Precision Loss in Index-Price Math (R2)
* **Severity**: High | **Probability**: Medium
* **Risk Description**: Accumulating floating-point rounding errors during mouse wheel zoom or pan ops can cause bar misalignment or jitter between price scales and candle wicks.
* **Mitigation Strategy**:
  1. Maintain time indices as integer indexes ($\mathbb{Z}$) for bar positions, using floats ($\mathbb{R}$) only during transient sub-bar interpolation.
  2. Implement bi-directional conversion verification tests enforcing exact coordinate mapping within $10^{-6}$ error limits.

---

### 3.3 Risk 3: Memory Leakage via Event Bus Callbacks (R3)
* **Severity**: Medium | **Probability**: Medium
* **Risk Description**: Long-lived chart events holding hard references to destroyed indicator widgets or pane views prevent garbage collection.
* **Mitigation Strategy**:
  1. The `EventBus` MUST store callbacks using `weakref.ref`. Dead references are automatically purged during event dispatch.

---

### 3.4 Risk 4: Multi-Pane Y-Scale Overflow & Boundary Distortion (R4)
* **Severity**: Medium | **Probability**: Medium
* **Risk Description**: When user adds multiple subplots (e.g., RSI, MACD, Volume), polylines may bleed out of their assigned subplot pane and overlap adjacent axes.
* **Mitigation Strategy**:
  1. Implement Cohen-Sutherland line clipping in `_clip_line()` to mathematically clip polyline vectors against pane bounding boxes (`Viewport`).

---

### 3.5 Risk 5: Cross-Platform Font & Line Rendering Discrepancies (R5)
* **Severity**: Low | **Probability**: High
* **Risk Description**: Windows, macOS, and Linux render default fonts and stipple patterns differently in Tkinter.
* **Mitigation Strategy**:
  1. Standardize font fallback stacks (`Segoe UI`, `SF Pro Text`, `DejaVu Sans`, `Helvetica`).
  2. Use platform-independent stipple fill tokens (`gray25`, `gray50`) for transparency.
