# Rendering Engine Specification: FinChart

**Document Version**: 1.0  
**Subsystem**: Retained-Mode Tkinter Canvas Rendering Pipeline

---

## 1. Overview & Performance Mandate

Tkinter's native `tk.Canvas` widget is an immediate/retained hybrid vector graphics surface. Traditional Tkinter charting implementations suffer severe performance drops because they execute `canvas.delete('all')` on every mouse movement or scroll event. Deleting and allocating thousands of C-level canvas items per frame causes severe memory churn and drops frame rates below 15 FPS.

The **FinChart Rendering Engine** solves this problem by introducing:
1. **Canvas Item Pooling (`CanvasItemPool`)**: Recycles existing Tkinter item IDs (`line`, `rectangle`, `polygon`, `text`).
2. **Abstract Draw Command Buffer (`DrawCommand`)**: Decouples indicator/series geometry generation from Canvas invocations.
3. **Layer-Based Invalidation (`LayerManager`)**: Redraws only changed layers (e.g., updating crosshair lines at 60 FPS without touching static candlestick items).
4. **Deferred Frame Scheduler**: Merges multiple state updates within a single event-loop cycle via `after_idle`.

---

## 2. Canvas Item Pool Architecture

```
                       acquire("rectangle")
      Renderer ─────────────────────────────────────► CanvasItemPool
         │                                                 │
         │ Returns item_id (e.g., ID 1042)                 │
         ▼                                                 │
  canvas.coords(1042, x1, y1, x2, y2)                      │
  canvas.itemconfig(1042, state="normal", fill="#089981")   │
                                                           │
                                                           ▼
                       release_all(unused_ids)       Pool Storage
      Frame End ────────────────────────────────────► [Hidden Items]
                                                     (state="hidden")
```

### 2.1 Object Pool Memory Contract
* Items in the pool maintain `state="hidden"` when inactive.
* When acquired, an item is configured with `state="normal"` and updated with new coordinates and styling options.
* Pool size expands dynamically as needed up to a max cap (default $10,000\text{ items}$).
* Unused items from a previous frame are returned to the pool, preventing memory leaks.

---

## 3. Abstract Draw Command Definition

Renderers do not call `canvas.create_line()` directly. Instead, they produce light `DrawCommand` instances:

```python
@dataclass(slots=True)
class DrawCommand:
    layer: Layer
    tag: str
    item_type: str  # 'line', 'rectangle', 'oval', 'polygon', 'text'
    coords: Tuple[float, ...]
    options: Dict[str, Any]
    z_index: int = 0
```

### 3.1 Supported Item Primitive Mapping

| Item Type | Required `coords` Format | Options Keys |
|-----------|--------------------------|--------------|
| `"line"` | `(x1, y1, x2, y2)` or `(x1, y1, ..., xn, yn)` | `fill`, `width`, `dash`, `capstyle`, `smooth` |
| `"rectangle"` | `(x1, y1, x2, y2)` | `fill`, `outline`, `width`, `stipple` |
| `"polygon"` | `(x1, y1, x2, y2, ..., xn, yn)` | `fill`, `outline`, `width` |
| `"oval"` | `(x1, y1, x2, y2)` | `fill`, `outline`, `width` |
| `"text"` | `(x, y)` | `text`, `fill`, `font`, `anchor` |

---

## 4. Layer Tag & Z-Ordering Architecture

To guarantee correct visual stacking without sorting thousands of Canvas items on every frame, items are grouped into tag-isolated layers:

```python
class Layer(Enum):
    BACKGROUND = 100
    GRID = 200
    SERIES = 300
    INDICATORS = 400
    DRAWING = 500
    CROSSHAIR = 600
    UI = 700
    OVERLAY = 800
```

### 4.1 Tag Manipulation
Each layer owns a Canvas tag (e.g., `layer_series`, `layer_crosshair`). When a specific layer is marked dirty (`schedule_layer(Layer.CROSSHAIR)`):
1. Only commands registered to `Layer.CROSSHAIR` are re-processed.
2. Existing items under tag `layer_crosshair` are released to the item pool (`state="hidden"`).
3. New commands for `Layer.CROSSHAIR` acquire items from the pool and assign tag `layer_crosshair`.
4. Layers `BACKGROUND`, `GRID`, `SERIES`, and `INDICATORS` remain completely untouched in the Tkinter C engine.

---

## 5. Viewport Culling & Clipping Optimization

To maintain sub-millisecond frame times regardless of total dataset size (e.g., 100,000 candles):

### 5.1 Bar Index Range Clipping
Only bars within the visible viewport bounds plus a 1-bar margin are generated:

```python
visible_start = max(0, int(coord_engine.x_to_index(viewport.left)) - 1)
visible_end = min(total_bars, int(coord_engine.x_to_index(viewport.right)) + 1)
```

### 5.2 Line Segment Cohen-Sutherland Clipping
For extended drawing lines or indicator polylines that cross viewport boundaries, lines are mathematically clipped before being submitted as canvas primitives to prevent rendering off-screen coordinate overflows.

---

## 6. Rendering Performance Guidelines

1. **Text Width Caching**: Font text measurements are cached in a hash map (`TextWidthCache`) to avoid repetitive string width queries.
2. **Minimal State Changes**: `itemconfig()` options are compared against previous settings; calls are skipped if color, width, or fill remain unchanged.
3. **Stipple Alpha Emulation**: Because standard Tkinter Canvas does not natively support 32-bit RGBA transparency on all platforms, transparent shape overlays use hardware-compatible stipple bitmasks (`gray25`, `gray50`, `gray75`) for smooth fill opacity.
