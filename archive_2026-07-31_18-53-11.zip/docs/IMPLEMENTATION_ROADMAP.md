# Implementation Roadmap & Milestone Plan

**Document Version**: 1.0  
**Project**: FinChart Engineering Blueprint

---

## 1. Overview & Phased Roadmap Strategy

FinChart development is divided into 11 distinct, sequential milestones (M0 through M10). Development must proceed strictly milestone-by-milestone. Each milestone requires 100% unit test coverage, passing benchmark gates, and architectural approval before the next milestone begins.

```
M0 Foundation ──► M1 Core Types ──► M2 Coordinate Engine ──► M3 Render Pipeline
                                                                      │
M7 Indicators ◄── M6 Drawing Tools ◄── M5 Interaction FSM ◄── M4 Layout & Panes
      │
      ▼
M8 Public API ──► M9 Optimization & Wiki ──► M10 Final Release
```

---

## 2. Milestone Detailed Breakdown

### Milestone 0: Foundation & CI Setup
* **Goal**: Establish project directory tree, typing configuration (`py.typed`), linting (`flake8`/`black`/`mypy`), and test runners.
* **Deliverables**: Package layout under `finchart/`, standard `pytest` harness, CI configuration.
* **Acceptance Criteria**: `pytest` passes with zero errors; `mypy --strict` passes cleanly.
* **Complexity / Risk**: XS / Low.

---

### Milestone 1: Core Types & Event Bus
* **Goal**: Implement `OHLCV`, `Viewport`, `Point`, `Rect`, `Color`, `VisibleRange`, `DataStore`, and `EventBus`.
* **Deliverables**: `finchart/core/types.py`, `finchart/core/events.py`, `finchart/core/store.py`, unit test suite (`test_core.py`).
* **Acceptance Criteria**: Weakref `EventBus` prevents memory leaks; `DataStore` handles 100,000 candles under 30 MB memory usage.
* **Complexity / Risk**: S / Low.

---

### Milestone 2: Coordinate & Transformation Engine
* **Goal**: Implement `TimeScale`, `PriceScale`, and `CoordinateEngine`.
* **Deliverables**: `finchart/coordinates/engine.py`, unit tests (`test_coordinates.py`).
* **Acceptance Criteria**: Bi-directional conversions ($\text{index} \leftrightarrow \text{X}$ and $\text{price} \leftrightarrow \text{Y}$) pass exact round-trip validation within $10^{-6}$ precision float limits.
* **Complexity / Risk**: M / Medium.

---

### Milestone 3: Retained-Mode Rendering Pipeline
* **Goal**: Implement `CanvasItemPool`, `LayerManager`, `RenderingPipeline`, and primitive draw command dispatcher.
* **Deliverables**: `finchart/rendering/pipeline.py`, `finchart/rendering/pool.py`, unit & visual tests (`test_pipeline.py`).
* **Acceptance Criteria**: `CanvasItemPool` acquires/releases 5,000 items without memory leakage or new allocations; dirty layer scheduling (`schedule_layer`) executes under 2 ms.
* **Complexity / Risk**: L / High.

---

### Milestone 4: Layout & Multi-Pane Engine
* **Goal**: Implement `LayoutEngine` and `Pane` bounding box partitioning.
* **Deliverables**: `finchart/layout/engine.py`, `finchart/rendering/grid.py`.
* **Acceptance Criteria**: Multi-pane layout resizes smoothly with dynamic window resizing; price and time axis labels render with nice-number rounding.
* **Complexity / Risk**: M / Medium.

---

### Milestone 5: Interaction Controller & Navigation FSM
* **Goal**: Implement mouse wheel zoom around cursor, drag pan, crosshair rendering, and keyboard shortcuts.
* **Deliverables**: `finchart/interaction/controller.py`, `finchart/rendering/crosshair.py`.
* **Acceptance Criteria**: Smooth 60 FPS panning response; crosshair snaps instantly to bar timestamp and price level.
* **Complexity / Risk**: L / High.

---

### Milestone 6: Interactive Drawing Tools & Hit Testing
* **Goal**: Implement interactive shapes (`TrendLine`, `Rectangle`, `HLine`, `VLine`, `PositionTool`) with selection handles and drag/resize behavior.
* **Deliverables**: `finchart/drawing/tools.py`, `finchart/interaction/hit_test.py`.
* **Acceptance Criteria**: Shape selection handles render correctly; dragging handles mutates shape coordinates accurately; shapes serialize/deserialize to JSON.
* **Complexity / Risk**: L / High.

---

### Milestone 7: Indicator Plugin Framework
* **Goal**: Implement abstract `Indicator` base class and built-in indicators (`SMA`, `EMA`, `RSI`, `MACD`, `BollingerBands`).
* **Deliverables**: `finchart/indicators/base.py`, `finchart/indicators/standard.py`.
* **Acceptance Criteria**: Indicators compute outputs cleanly; custom user-defined indicator plugins attach seamlessly to chart instances.
* **Complexity / Risk**: M / Medium.

---

### Milestone 8: Public API (`ChartWidget`) & Theme Engine
* **Goal**: Package all subsystems into clean `ChartWidget` API with Dark/Light theme switching.
* **Deliverables**: `finchart/api/widget.py`, `finchart/themes/style.py`, user examples (`demo_1.py`, `demo_fullfeatures.py`).
* **Acceptance Criteria**: Complete high-level API functions (`set_data`, `add_indicator`, `fit_content`, `save_session`) work reliably.
* **Complexity / Risk**: M / Medium.

---

### Milestone 9: Performance Optimization & LLM Wiki Integration
* **Goal**: Run comprehensive profiling (`cProfile`), optimize bottlenecks, and initialize `/wiki/` directory structure.
* **Deliverables**: Benchmark report (`verify_benchmark.py`), living wiki files in `/wiki/`.
* **Acceptance Criteria**: 60 FPS target met for 50,000 candles; wiki documentation fully synchronized.
* **Complexity / Risk**: S / Low.

---

### Milestone 10: Final Code Freeze & 1.0 Release
* **Goal**: Final code review, zero open TODOs/FIXMEs, release packaging.
* **Deliverables**: `v1.0.0` distribution package, developer documentation.
* **Acceptance Criteria**: All automated test suites pass cleanly across Windows/Linux/macOS Tkinter runtime environments.
* **Complexity / Risk**: S / Low.
