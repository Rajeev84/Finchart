# Project Glossary & Terminology Index

**Document Version**: 1.0  
**Project**: FinChart Engineering Blueprint

---

## Terminology & Definitions

### Bar Index ($i$)
A zero-based contiguous integer index representing a candlestick's sequential position in the dataset.

### Bar Spacing ($S_{\text{bar}}$)
The distance in pixels between the centerlines of two adjacent candlestick bars on the chart.

### Canvas Item Pool (`CanvasItemPool`)
A memory management structure that retains and recycles Tkinter Canvas item IDs (`line`, `rectangle`, `polygon`, `text`) using `state="hidden"` to eliminate object allocation overhead during rendering.

### Cohen-Sutherland Clipping
A 2D line clipping algorithm used to trim extended vector lines to the exact boundary of a target viewport or pane before submission to the canvas renderer.

### Crosshair
An interactive cursor overlay consisting of intersecting horizontal (price) and vertical (time) dashed lines, accompanied by coordinate badge labels on the respective axes.

### Deferred Invalidation
A frame scheduling technique where state change events schedule a single render pass via `after_idle`, merging rapid sequential updates into one frame pass.

### Event Bus (`EventBus`)
A publish-subscribe event routing subsystem that dispatches strongly-typed signals across decoupled modules using weak references.

### Layer Manager (`LayerManager`)
A component that organizes canvas items into distinct z-ordered visual layers (`BACKGROUND`, `GRID`, `SERIES`, `INDICATORS`, `DRAWING`, `CROSSHAIR`, `UI`, `OVERLAY`) using Canvas tag isolation.

### Market Profile (TPO)
A financial charting overlay that displays time-at-price distribution using letter brackets, identifying Value Area High (VAH), Value Area Low (VAL), and Point of Control (POC).

### Nice-Number Step Algorithm
A rounding algorithm that computes human-friendly interval steps (e.g., 1, 2, 5, 10, 20, 50, 100) for grid lines and tick marks across dynamic zoom levels.

### OHLCV
Acronym for Open, High, Low, Close, Volume — the core 5-tuple data structure representing financial price action over a given period.

### Price Scale ($P$)
The vertical coordinate transformation system mapping asset prices to Canvas Y pixels, supporting Auto-scale, Logarithmic, Percentage, and Manual modes.

### Retained-Mode Rendering
A rendering paradigm where graphic elements are maintained in a persistent scene representation or object pool rather than completely erased and recreated on every frame.

### Time Scale ($T$)
The horizontal coordinate transformation system mapping bar indices to Canvas X pixels based on current bar spacing and offset.

### Viewport (`Viewport`)
A 2D bounding rectangle in pixel coordinates defining the visible drawing region of a pane or chart component.
