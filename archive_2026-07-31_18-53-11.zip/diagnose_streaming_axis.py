"""Diagnose axis label disappearance during streaming + mouse move."""
import tkinter as tk
from datetime import datetime
import random

from finchart import ChartWidget, OHLCV, DarkTheme
from finchart.rendering.pipeline import Layer


def flush(root: tk.Tk, n: int = 5) -> None:
    for _ in range(n):
        root.update_idletasks()
        root.update()


def count_visible_grid_texts(canvas: tk.Canvas) -> int:
    count = 0
    for item in canvas.find_withtag("layer_grid"):
        if canvas.type(item) == "text" and str(canvas.itemcget(item, "state")) == "normal":
            count += 1
    return count


def count_visible_crosshair_texts(canvas: tk.Canvas) -> int:
    count = 0
    for item in canvas.find_withtag("layer_crosshair"):
        if canvas.type(item) == "text" and str(canvas.itemcget(item, "state")) == "normal":
            count += 1
    return count


def main() -> None:
    root = tk.Tk()
    root.geometry("1440x860")
    chart = ChartWidget(root, width=1440, height=780, theme=DarkTheme())
    chart.pack(fill="both", expand=True)

    # Generate 500 bars like the demo
    random.seed(99)
    bars = []
    price = 45000.0
    base_ts = datetime(2024, 1, 1, 0, 0).timestamp()
    volatility = 0.012
    trend = 0.0002
    for i in range(500):
        if i % 100 == 50:
            trend = -trend
        open_ = price
        change = random.gauss(trend * price, volatility * price)
        close = max(1.0, price + change)
        high = max(open_, close) * (1.0 + abs(random.gauss(0.0, 0.004)))
        low = min(open_, close) * (1.0 - abs(random.gauss(0.0, 0.004)))
        vol = random.uniform(10_000_000, 100_000_000)
        ts = base_ts + i * 3600
        bars.append(OHLCV(timestamp=ts, open=open_, high=high, low=low, close=close, volume=vol))
        price = close

    chart.set_data(bars)
    flush(root, 20)

    print("=== INITIAL STATE ===")
    print(f"GRID visible texts: {count_visible_grid_texts(chart._canvas)}")
    print(f"CROSSHAIR visible texts: {count_visible_crosshair_texts(chart._canvas)}")
    print(f"GRID current items: {len(chart._pipeline._current_items[Layer.GRID])}")
    print(f"SERIES current items: {len(chart._pipeline._current_items[Layer.SERIES])}")
    print(f"CROSSHAIR current items: {len(chart._pipeline._current_items[Layer.CROSSHAIR])}")
    print(f"Command buffer: {len(chart._pipeline._command_buffer)}")
    print(f"Pending layers: {chart._pipeline._pending_layers}")
    print(f"Needs full redraw: {chart._pipeline._needs_full_redraw}")

    # Simulate mouse move
    print("\n=== AFTER MOUSE MOVE (inside chart) ===")
    chart._on_mouse_move_event(type("E", (), {"data": {"x": 400.0, "y": 200.0}})())
    flush(root, 5)
    print(f"GRID visible texts: {count_visible_grid_texts(chart._canvas)}")
    print(f"CROSSHAIR visible texts: {count_visible_crosshair_texts(chart._canvas)}")
    print(f"GRID current items: {len(chart._pipeline._current_items[Layer.GRID])}")
    print(f"CROSSHAIR current items: {len(chart._pipeline._current_items[Layer.CROSSHAIR])}")
    print(f"Command buffer: {len(chart._pipeline._command_buffer)}")
    print(f"Pending layers: {chart._pipeline._pending_layers}")

    # Simulate streaming - append bars while mouse is moving
    print("\n=== SIMULATING STREAMING + MOUSE MOVES ===")
    for tick in range(20):
        # Append a bar (like streaming)
        last = bars[-1]
        new_price = last.close * (1.0 + random.gauss(0.0, 0.005))
        new_bar = OHLCV(
            timestamp=last.timestamp + 3600,
            open=last.close,
            high=max(last.close, new_price) * (1 + abs(random.gauss(0.0, 0.003))),
            low=min(last.close, new_price) * (1 - abs(random.gauss(0.0, 0.003))),
            close=new_price,
            volume=random.uniform(5_000_000, 50_000_000),
        )
        bars.append(new_bar)
        chart.append(new_bar)

        # Simulate mouse move
        chart._on_mouse_move_event(type("E", (), {"data": {"x": 400.0 + tick * 5, "y": 200.0}})())
        flush(root, 3)

        if tick % 5 == 0:
            grid_count = count_visible_grid_texts(chart._canvas)
            ch_count = count_visible_crosshair_texts(chart._canvas)
            print(f"  tick {tick}: GRID texts={grid_count}, CROSSHAIR texts={ch_count}, "
                  f"buffer={len(chart._pipeline._command_buffer)}, "
                  f"pending={chart._pipeline._pending_layers}")

    # Final state
    print("\n=== FINAL STATE ===")
    print(f"GRID visible texts: {count_visible_grid_texts(chart._canvas)}")
    print(f"CROSSHAIR visible texts: {count_visible_crosshair_texts(chart._canvas)}")
    print(f"GRID current items: {len(chart._pipeline._current_items[Layer.GRID])}")
    print(f"SERIES current items: {len(chart._pipeline._current_items[Layer.SERIES])}")
    print(f"CROSSHAIR current items: {len(chart._pipeline._current_items[Layer.CROSSHAIR])}")
    print(f"Command buffer: {len(chart._pipeline._command_buffer)}")
    print(f"Pending layers: {chart._pipeline._pending_layers}")
    print(f"Needs full redraw: {chart._pipeline._needs_full_redraw}")

    # Check if GRID items are hidden
    grid_hidden = 0
    grid_visible = 0
    for item in chart._canvas.find_withtag("layer_grid"):
        state = str(chart._canvas.itemcget(item, "state"))
        if state == "hidden":
            grid_hidden += 1
        else:
            grid_visible += 1
    print(f"\nGRID items: visible={grid_visible}, hidden={grid_hidden}")

    # Check z-order: find the stacking order of items
    print("\n=== Z-ORDER CHECK (first 20 items) ===")
    for i, item in enumerate(chart._canvas.find_all()[:20]):
        typ = chart._canvas.type(item)
        state = chart._canvas.itemcget(item, "state")
        tags = chart._canvas.gettags(item)
        print(f"  [{i}] type={typ} state={state} tags={tags}")

    root.destroy()


if __name__ == "__main__":
    main()