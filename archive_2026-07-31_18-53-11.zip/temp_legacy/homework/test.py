from pycanvascharts import Chart, CandlestickSeries, Theme, KLineData
import random
from datetime import datetime, timedelta

# Generate sample OHLC data
def generate_data(n=200):
    data = []
    base_price = 100.0
    timestamp = int(datetime(2024, 1, 1).timestamp() * 1000)
    
    for i in range(n):
        open_p = base_price + random.uniform(-2, 2)
        close_p = open_p + random.uniform(-3, 3)
        high_p = max(open_p, close_p) + random.uniform(0, 2)
        low_p = min(open_p, close_p) - random.uniform(0, 2)
        volume = random.uniform(1000, 10000)
        
        data.append(KLineData(
            timestamp=timestamp,
            open=round(open_p, 4),
            high=round(high_p, 4),
            low=round(low_p, 4),
            close=round(close_p, 4),
            volume=round(volume, 2)
        ))
        base_price = close_p
        timestamp += 24 * 60 * 60 * 1000  # +1 day
    
    return data

# Create chart
chart = Chart(width=900, height=500, theme="dark")

# Add candlestick series
data = generate_data(200)
series = chart.add_series(CandlestickSeries, data=data)

# Save to standalone HTML
chart.save("candlestick_chart.html")

# Or display in Jupyter
# chart.show()