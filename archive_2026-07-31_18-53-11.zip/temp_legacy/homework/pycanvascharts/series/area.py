
# area.py  
class AreaSeries(BaseSeries):
    def __init__(self, store, styles, **options):
        super().__init__(store, styles, **options)
        self._top_color = options.get("top_color", styles.area.top_color)
