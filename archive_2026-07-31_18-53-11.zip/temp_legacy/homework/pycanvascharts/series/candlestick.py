"""
CandlestickSeries — OHLC candle rendering.
"""
from .base import BaseSeries


class CandlestickSeries(BaseSeries):
    """Candlestick/OHLC series."""
    
    def __init__(self, store, styles, **options):
        super().__init__(store, styles, **options)
        self._bar_style = options.get("bar_style", "candle")
    
    def render(self, ctx, cs):
        # Rendering is handled by the Canvas renderer for performance
        pass