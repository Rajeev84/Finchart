# histogram.py
class HistogramSeries(BaseSeries):
    pass