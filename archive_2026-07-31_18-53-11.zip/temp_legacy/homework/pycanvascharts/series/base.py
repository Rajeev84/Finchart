"""
BaseSeries — Abstract base for all series types.
"""
from __future__ import annotations
from typing import List, Optional, Dict, Any
from abc import ABC, abstractmethod

from ..core.store import ChartStore, KLineData
from ..core.styles import Styles


class BaseSeries(ABC):
    def __init__(self, store: ChartStore, styles: Styles, **options):
        self._store = store
        self._styles = styles
        self._options = options
        self._data: List[KLineData] = []
        self._visible = True
    
    def set_data(self, data: List[KLineData]) -> None:
        self._data = data
    
    def get_data(self) -> List[KLineData]:
        return self._data
    
    def apply_options(self, **options) -> None:
        self._options.update(options)
    
    @abstractmethod
    def render(self, ctx: Any, coordinate_system: Any) -> None:
        pass