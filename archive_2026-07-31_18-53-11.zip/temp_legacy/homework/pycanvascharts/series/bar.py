
# bar.py
class BarSeries(BaseSeries):
    pass

