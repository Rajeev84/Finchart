# line.py
class LineSeries(BaseSeries):
    def __init__(self, store, styles, **options):
        super().__init__(store, styles, **options)
        self._color = options.get("color", styles.line.color)
