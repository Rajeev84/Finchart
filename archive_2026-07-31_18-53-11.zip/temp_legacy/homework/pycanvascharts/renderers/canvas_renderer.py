"""
Tkinter Canvas Renderer — Renders chart on a Tkinter Canvas widget.
Supports zoom, pan, indicators, and shape drawing.
"""
from __future__ import annotations
from typing import Any, Optional, List, Dict, Tuple
import tkinter as tk
import re
import math


def _rgba_to_tk(color: str) -> str:
    """Convert CSS rgba() or hex color to Tkinter-compatible hex color."""
    if not color:
        return "#000000"
    if color.startswith("#"):
        return color
    m = re.match(r'rgba\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([\d.]+)\s*\)', color)
    if m:
        r, g, b = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return f"#{r:02x}{g:02x}{b:02x}"
    m = re.match(r'rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)', color)
    if m:
        r, g, b = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return f"#{r:02x}{g:02x}{b:02x}"
    return color


class DrawingShape:
    """Base class for drawn shapes/annotations."""
    def __init__(self, shape_type: str, color: str = "#f0d43a", width: int = 1):
        self.type = shape_type
        self.color = color
        self.width = width
        self.visible = True


class HorizontalLine(DrawingShape):
    def __init__(self, y_price: float, color: str = "#f0d43a", width: int = 1):
        super().__init__("horizontal_line", color, width)
        self.y_price = y_price


class VerticalLine(DrawingShape):
    def __init__(self, x_index: float, color: str = "#f0d43a", width: int = 1):
        super().__init__("vertical_line", color, width)
        self.x_index = x_index


class TrendLine(DrawingShape):
    def __init__(self, x1_idx: float, y1_price: float,
                 x2_idx: float, y2_price: float,
                 color: str = "#f0d43a", width: int = 1):
        super().__init__("trend_line", color, width)
        self.x1_idx = x1_idx
        self.y1_price = y1_price
        self.x2_idx = x2_idx
        self.y2_price = y2_price


class TkinterCanvasRenderer:
    """Renders the chart state onto a Tkinter Canvas with interactivity."""

    # Tool modes
    MODE_CROSSHAIR = "crosshair"
    MODE_DRAW_HLINE = "draw_hline"
    MODE_DRAW_VLINE = "draw_vline"
    MODE_DRAW_TREND = "draw_trend"

    def __init__(self, canvas: tk.Canvas, chart: Any):
        self._canvas = canvas
        self._chart = chart
        self._main_left = 0
        self._main_width = 0
        self._main_h = 0
        self._axis_h = 28

        # Interaction state
        self._mode = self.MODE_CROSSHAIR
        self._is_dragging = False
        self._drag_start_x = 0
        self._drag_start_y = 0
        self._last_x = 0
        self._last_y = 0
        self._crosshair_x: Optional[float] = None
        self._crosshair_y: Optional[float] = None

        # Drawing state
        self._shapes: List[DrawingShape] = []
        self._drawing_trend: Optional[dict] = None  # temp trend line being drawn

        # Price scale cache (recalculated each render)
        self._min_px = 0.0
        self._max_px = 100.0
        self._ratio = 1.0

        # Bind events
        self._bind_events()

    def _bind_events(self):
        self._canvas.bind("<Motion>", self._on_mouse_move)
        self._canvas.bind("<ButtonPress-1>", self._on_mouse_down)
        self._canvas.bind("<ButtonRelease-1>", self._on_mouse_up)
        self._canvas.bind("<MouseWheel>", self._on_mouse_wheel)
        self._canvas.bind("<Button-4>", self._on_mouse_wheel_up)   # Linux scroll up
        self._canvas.bind("<Button-5>", self._on_mouse_wheel_down) # Linux scroll down
        self._canvas.bind("<Leave>", self._on_mouse_leave)

    def set_mode(self, mode: str):
        """Set the current interaction mode."""
        self._mode = mode
        self._drawing_trend = None
        self._canvas.config(cursor="crosshair" if mode != self.MODE_CROSSHAIR else "arrow")

    def add_shape(self, shape: DrawingShape):
        """Add a drawn shape."""
        self._shapes.append(shape)
        self.render(None)

    def remove_shapes(self, shape_type: Optional[str] = None):
        """Remove shapes. If type is None, remove all."""
        if shape_type is None:
            self._shapes.clear()
        else:
            self._shapes = [s for s in self._shapes if s.type != shape_type]
        self.render(None)

    def get_shapes(self) -> List[DrawingShape]:
        return self._shapes

    # ─── Coordinate Conversion ───

    def _calc_price_scale(self, data, vr, main_h):
        """Calculate price-to-y mapping."""
        v_high = -float('inf')
        v_low = float('inf')
        for i in range(vr.from_idx, min(vr.to_idx, len(data))):
            d = data[i]
            v_high = max(v_high, d.high)
            v_low = min(v_low, d.low)
        if v_high == -float('inf'):
            v_high = 100
        if v_low == float('inf'):
            v_low = 0
        price_range = max(v_high - v_low, 0.001)
        self._min_px = v_low - price_range * 0.1
        self._max_px = v_high + price_range * 0.1
        self._ratio = main_h / (self._max_px - self._min_px)

    def price_to_y(self, price: float) -> float:
        return self._main_h - (price - self._min_px) * self._ratio

    def y_to_price(self, y: float) -> float:
        return self._min_px + (self._main_h - y) / self._ratio

    def x_to_index(self, x: float) -> float:
        """Convert canvas x to data index (float)."""
        store = self._chart._store
        vr = store.get_visible_range()
        bar_space = store.get_bar_space()
        return vr.from_idx + (x - self._main_left) / bar_space.bar - 0.5

    def index_to_x(self, idx: float) -> float:
        """Convert data index to canvas x."""
        store = self._chart._store
        vr = store.get_visible_range()
        bar_space = store.get_bar_space()
        return self._main_left + (idx - vr.from_idx + 0.5) * bar_space.bar

    # ─── Event Handlers ───

    def _on_mouse_move(self, event):
        self._crosshair_x = event.x
        self._crosshair_y = event.y

        if self._is_dragging and self._mode == self.MODE_CROSSHAIR:
            # Pan
            dx = event.x - self._last_x
            store = self._chart._store
            bar_space = store.get_bar_space()
            store._last_bar_right_side_diff_bar_count -= dx / bar_space.bar
            count = len(store.get_data_list())
            visible = store.get_total_bar_space() / bar_space.bar
            max_r = visible
            min_r = -count + 2
            store._last_bar_right_side_diff_bar_count = max(min_r, min(max_r, store._last_bar_right_side_diff_bar_count))
            self._last_x = event.x
            self._last_y = event.y
            self._chart._layout_dirty = True
            self._chart._store.notify(None)

        elif self._mode == self.MODE_DRAW_TREND and self._drawing_trend:
            # Preview trend line
            self.render(None)
            x1 = self._drawing_trend["x1"]
            y1 = self._drawing_trend["y1"]
            self._canvas.create_line(x1, y1, event.x, event.y,
                                      fill="#f0d43a", width=1, dash=(4, 4),
                                      tags="preview")

        elif self._mode in (self.MODE_DRAW_HLINE, self.MODE_DRAW_VLINE):
            self.render(None)
            if self._mode == self.MODE_DRAW_HLINE:
                self._canvas.create_line(self._main_left, event.y,
                                          self._main_left + self._main_width, event.y,
                                          fill="#f0d43a", width=1, dash=(4, 4),
                                          tags="preview")
            else:
                self._canvas.create_line(event.x, 0, event.x, self._main_h,
                                          fill="#f0d43a", width=1, dash=(4, 4),
                                          tags="preview")
        else:
            self.render(None)

    def _on_mouse_down(self, event):
        self._last_x = event.x
        self._last_y = event.y

        if self._mode == self.MODE_CROSSHAIR:
            self._is_dragging = True
            self._drag_start_x = event.x
            self._drag_start_y = event.y

        elif self._mode == self.MODE_DRAW_HLINE:
            price = self.y_to_price(event.y)
            self.add_shape(HorizontalLine(price))

        elif self._mode == self.MODE_DRAW_VLINE:
            idx = self.x_to_index(event.x)
            self.add_shape(VerticalLine(idx))

        elif self._mode == self.MODE_DRAW_TREND:
            if not self._drawing_trend:
                self._drawing_trend = {
                    "x1": event.x,
                    "y1": event.y,
                    "idx1": self.x_to_index(event.x),
                    "price1": self.y_to_price(event.y),
                }
            else:
                # Complete the trend line
                self.add_shape(TrendLine(
                    self._drawing_trend["idx1"],
                    self._drawing_trend["price1"],
                    self.x_to_index(event.x),
                    self.y_to_price(event.y),
                ))
                self._drawing_trend = None

    def _on_mouse_up(self, event):
        self._is_dragging = False

    def _on_mouse_leave(self, event):
        self._crosshair_x = None
        self._crosshair_y = None
        self._is_dragging = False
        self.render(None)

    def _on_mouse_wheel(self, event):
        """Zoom with scroll wheel."""
        scale = -1 if event.delta > 0 else 1
        self._zoom_at_point(event.x, scale)

    def _on_mouse_wheel_up(self, event):
        self._zoom_at_point(event.x, 1)

    def _on_mouse_wheel_down(self, event):
        self._zoom_at_point(event.x, -1)

    def _zoom_at_point(self, x: float, direction: int):
        """Zoom in/out centered on cursor x position."""
        store = self._chart._store
        bar_space = store.get_bar_space()
        float_idx = self.x_to_index(x)
        new_bar = bar_space.bar + direction * (bar_space.bar / 10)
        store.set_bar_space(new_bar)
        # Adjust offset to keep the point under cursor stable
        store._last_bar_right_side_diff_bar_count += float_idx - self.x_to_index(x)
        count = len(store.get_data_list())
        visible = store.get_total_bar_space() / bar_space.bar
        to_idx = int(store._last_bar_right_side_diff_bar_count + count + 0.5)
        store._visible_range.from_idx = max(0, int(to_idx - visible) - 1)
        store._visible_range.to_idx = min(to_idx, count)
        self._chart._layout_dirty = True
        self._chart._store.notify(None)

    # ─── Rendering ───

    def render(self, level: Any) -> None:
        """Main render method called by Chart on store updates."""
        self._canvas.delete("all")
        store = self._chart._store
        styles = self._chart._styles
        data = store.get_data_list()
        vr = store.get_visible_range()
        w = self._chart._width
        h = self._chart._height

        # Layout
        right_axis_w = 60
        left_axis_w = 0
        self._axis_h = 28
        self._main_left = left_axis_w
        self._main_width = w - left_axis_w - right_axis_w
        self._main_h = h - self._axis_h

        # Background
        self._canvas.create_rectangle(
            0, 0, w, h,
            fill=_rgba_to_tk(styles.layout.background_color),
            outline=""
        )

        if data and vr.from_idx < vr.to_idx:
            self._calc_price_scale(data, vr, self._main_h)
            bar_space = store.get_bar_space()

            # ─── Draw Candles ───
            for i in range(vr.from_idx, min(vr.to_idx, len(data))):
                d = data[i]
                x = self.index_to_x(i)
                if x < self._main_left - 20 or x > self._main_left + self._main_width + 20:
                    continue

                is_up = d.close >= d.open
                color = _rgba_to_tk(styles.candle.up_color if is_up else styles.candle.down_color)
                y_open = self.price_to_y(d.open)
                y_close = self.price_to_y(d.close)
                y_high = self.price_to_y(d.high)
                y_low = self.price_to_y(d.low)
                body_top = min(y_open, y_close)
                body_bottom = max(y_open, y_close)
                body_h = max(body_bottom - body_top, 1)
                half_gap = bar_space.half_gap_bar

                # Wick
                self._canvas.create_line(x, y_high, x, y_low, fill=color, width=1)
                # Body
                self._canvas.create_rectangle(x - half_gap, body_top,
                                               x + half_gap, body_top + body_h,
                                               fill=color, outline=color)

            # ─── Draw SMA Indicators ───
            indicators = store.get_indicators()
            for name, indicator in indicators.items():
                if hasattr(indicator, '_data') and hasattr(indicator, '_color'):
                    sma_data = indicator._data
                    if sma_data and len(sma_data) > 1:
                        points = []
                        for i in range(vr.from_idx, min(vr.to_idx, len(sma_data))):
                            if i < len(sma_data) and not (isinstance(sma_data[i], float) and math.isnan(sma_data[i])):
                                x = self.index_to_x(i)
                                y = self.price_to_y(sma_data[i])
                                points.append((x, y))
                        if len(points) > 1:
                            for j in range(len(points) - 1):
                                self._canvas.create_line(
                                    points[j][0], points[j][1],
                                    points[j + 1][0], points[j + 1][1],
                                    fill=_rgba_to_tk(indicator._color),
                                    width=1.5
                                )

            # ─── Draw Shapes ───
            for shape in self._shapes:
                if not shape.visible:
                    continue
                color = _rgba_to_tk(shape.color)
                if isinstance(shape, HorizontalLine):
                    y = self.price_to_y(shape.y_price)
                    if 0 <= y <= self._main_h:
                        self._canvas.create_line(
                            self._main_left, y,
                            self._main_left + self._main_width, y,
                            fill=color, width=shape.width, dash=(6, 3)
                        )
                elif isinstance(shape, VerticalLine):
                    x = self.index_to_x(shape.x_index)
                    if self._main_left <= x <= self._main_left + self._main_width:
                        self._canvas.create_line(
                            x, 0, x, self._main_h,
                            fill=color, width=shape.width, dash=(6, 3)
                        )
                elif isinstance(shape, TrendLine):
                    x1 = self.index_to_x(shape.x1_idx)
                    y1 = self.price_to_y(shape.y1_price)
                    x2 = self.index_to_x(shape.x2_idx)
                    y2 = self.price_to_y(shape.y2_price)
                    self._canvas.create_line(x1, y1, x2, y2,
                                              fill=color, width=shape.width)

            # ─── Time axis labels ───
            time_color = _rgba_to_tk(styles.time_axis.text_color)
            t_step = max(1, int((vr.to_idx - vr.from_idx) / 6))
            for i in range(vr.from_idx, min(vr.to_idx, len(data)), t_step):
                d = data[i]
                x = self.index_to_x(i)
                label = f"{d.timestamp}"
                self._canvas.create_text(x, h - self._axis_h + 14,
                                          text=label,
                                          fill=time_color,
                                          font=(styles.time_axis.font_family,
                                                styles.time_axis.font_size),
                                          anchor="center")

            # ─── Price axis labels (right) ───
            price_color = _rgba_to_tk(styles.price_axis.text_color)
            price_range = self._max_px - self._min_px
            rough_step = price_range / 5
            mag = 10 ** max(0, int(math.log10(max(rough_step, 0.0001))))
            res = rough_step / mag if mag > 0 else 1
            step = (1 if res < 1.5 else 2 if res < 3 else 5 if res < 7 else 10) * mag
            p = ((self._min_px + step - 1) // step) * step
            while p <= self._max_px:
                y = self.price_to_y(p)
                if 0 <= y <= self._main_h:
                    self._canvas.create_text(w - 5, y,
                                              text=f"{p:.2f}",
                                              fill=price_color,
                                              font=(styles.price_axis.font_family,
                                                    styles.price_axis.font_size),
                                              anchor="e")
                p += step

        # ─── Axis separator lines ───
        sep_color = _rgba_to_tk(styles.price_axis.border_color)
        self._canvas.create_line(self._main_left + self._main_width, 0,
                                 self._main_left + self._main_width, h - self._axis_h,
                                 fill=sep_color)
        self._canvas.create_line(0, h - self._axis_h, w, h - self._axis_h, fill=sep_color)

        # ─── Crosshair ───
        if self._crosshair_x is not None and self._crosshair_y is not None:
            cx, cy = self._crosshair_x, self._crosshair_y
            ch_color = _rgba_to_tk(styles.crosshair.vert_line_color)
            # Vertical line
            if self._main_left <= cx <= self._main_left + self._main_width:
                self._canvas.create_line(cx, 0, cx, h - self._axis_h,
                                          fill=ch_color, width=1, dash=(4, 4))
            # Horizontal line
            if 0 <= cy <= self._main_h:
                self._canvas.create_line(self._main_left, cy,
                                          self._main_left + self._main_width, cy,
                                          fill=ch_color, width=1, dash=(4, 4))

            # Crosshair price label
            if 0 <= cy <= self._main_h:
                price = self.y_to_price(cy)
                label = f"{price:.2f}"
                self._canvas.create_rectangle(
                    self._main_left + self._main_width + 2, cy - 8,
                    self._main_left + self._main_width + 60, cy + 8,
                    fill=_rgba_to_tk(styles.crosshair.horz_line_color), outline=""
                )
                self._canvas.create_text(
                    self._main_left + self._main_width + 5, cy,
                    text=label, fill="#ffffff", font=("monospace", 10),
                    anchor="w"
                )

            # Crosshair tooltip
            idx = int(self.x_to_index(cx))
            if 0 <= idx < len(data):
                d = data[idx]
                lines = [
                    f"O: {d.open:.4f}",
                    f"H: {d.high:.4f}",
                    f"L: {d.low:.4f}",
                    f"C: {d.close:.4f}",
                ]
                if d.volume:
                    lines.append(f"V: {d.volume:.0f}")
                line_h = 14
                box_w = 90
                box_h = len(lines) * line_h + 8
                bx = cx + 15
                by = cy + 15
                if bx + box_w > self._main_left + self._main_width:
                    bx = cx - box_w - 15
                if by + box_h > h - self._axis_h:
                    by = cy - box_h - 15
                # Background
                self._canvas.create_rectangle(bx, by, bx + box_w, by + box_h,
                                               fill="#2a2e39", outline="#555555")
                for j, line in enumerate(lines):
                    self._canvas.create_text(bx + 4, by + 4 + j * line_h,
                                              text=line, fill="#d1d4dc",
                                              font=("monospace", 10), anchor="nw")