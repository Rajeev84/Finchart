"""
CoordinateSystem — Price/Time ↔ Pixel transformations.
"""
from typing import Tuple


class CoordinateSystem:
    def __init__(self, store, price_axis, time_axis):
        self._store = store
        self._price_axis = price_axis
        self._time_axis = time_axis
    
    def time_to_x(self, timestamp: int) -> float:
        idx = self._store.timestamp_to_data_index(timestamp)
        return self._store.data_index_to_coordinate(idx)
    
    def price_to_y(self, price: float) -> float:
        return self._price_axis.price_to_coordinate(price)
    
    def x_to_time(self, x: float) -> int:
        idx = self._store.coordinate_to_data_index(x)
        ts = self._store.data_index_to_timestamp(idx)
        return ts or 0
    
    def y_to_price(self, y: float) -> float:
        return self._price_axis.coordinate_to_price(y)