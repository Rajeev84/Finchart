"""
PriceFormatter and TimeFormatter.
"""
from datetime import datetime
from typing import Optional, Callable


class PriceFormatter:
    def __init__(self, precision: int = 2):
        self._precision = precision
    
    def format(self, price: float) -> str:
        return f"{price:,.{self._precision}f}"


class TimeFormatter:
    def __init__(self, template: str = "%Y-%m-%d %H:%M"):
        self._template = template
    
    def format(self, timestamp: int) -> str:
        dt = datetime.fromtimestamp(timestamp / 1000)
        return dt.strftime(self._template)