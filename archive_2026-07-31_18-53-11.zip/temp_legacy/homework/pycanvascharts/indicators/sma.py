"""
SMA — Simple Moving Average indicator.
"""
from __future__ import annotations
from typing import List, Optional, Any


class SMA:
    """Simple Moving Average indicator calculation."""

    def __init__(self, store: Any, styles: Any, period: int = 14, color: str = "#f0d43a", **options):
        self._store = store
        self._styles = styles
        self._period = period
        self._color = color
        self._options = options
        self._data: List[float] = []
        self._visible = True

    def set_data(self, data: List[Any]) -> None:
        """Calculate SMA values from OHLC data."""
        self._data = []
        if not data or len(data) < self._period:
            return
        closes = [d.close for d in data]
        for i in range(len(closes)):
            if i < self._period - 1:
                self._data.append(float('nan'))
            else:
                self._data.append(sum(closes[i - self._period + 1:i + 1]) / self._period)

    def get_data(self) -> List[float]:
        return self._data

    def apply_options(self, **options) -> None:
        self._options.update(options)
        if "period" in options:
            self._period = options["period"]
        if "color" in options:
            self._color = options["color"]