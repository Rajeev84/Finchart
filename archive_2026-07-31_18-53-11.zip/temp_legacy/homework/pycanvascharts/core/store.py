"""
ChartStore — Central data store for chart state.
Inspired by KLineCharts' ChartStore.
"""
from __future__ import annotations
from typing import List, Optional, Dict, Any, Callable
from dataclasses import dataclass, field
from enum import Enum


class UpdateLevel(Enum):
    Light = 1
    Full = 2


@dataclass
class KLineData:
    """Single OHLCV data point."""
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "open": self.open,
            "high": self.high,
            "low": self.low,
            "close": self.close,
            "volume": self.volume,
        }


@dataclass
class BarSpace:
    bar: float = 6.0
    half_bar: float = 3.0
    gap_bar: float = 5.0
    half_gap_bar: float = 2.5


@dataclass
class VisibleRange:
    from_idx: int = 0
    to_idx: int = 0


class ChartStore:
    """Central data store managing OHLC data, indicators, and visible range."""

    def __init__(self):
        self._data: List[KLineData] = []
        self._indicators: Dict[str, Any] = {}
        self._bar_space = BarSpace()
        self._total_bar_space: float = 600.0
        self._last_bar_right_side_diff_bar_count: float = 0.0
        self._visible_range = VisibleRange()
        self._listeners: List[Callable] = []

    # ─── Data ───

    def set_data(self, data: List[KLineData]) -> None:
        self._data = data
        self._adjust_visible_range()

    def append_data(self, data: KLineData) -> None:
        self._data.append(data)
        self._adjust_visible_range()

    def get_data_list(self) -> List[KLineData]:
        return self._data

    def get_data_at(self, idx: int) -> Optional[KLineData]:
        if 0 <= idx < len(self._data):
            return self._data[idx]
        return None

    # ─── Indicators ───

    def add_indicator(self, name: str, indicator: Any) -> None:
        self._indicators[name] = indicator

    def get_indicator(self, name: str) -> Optional[Any]:
        return self._indicators.get(name)

    def get_indicators(self) -> Dict[str, Any]:
        return self._indicators

    # ─── Visible Range ───

    def _adjust_visible_range(self) -> None:
        count = len(self._data)
        if count == 0:
            self._visible_range = VisibleRange(0, 0)
            return
        visible_bars = self._total_bar_space / self._bar_space.bar
        to_idx = int(self._last_bar_right_side_diff_bar_count + count + 0.5)
        from_idx = max(0, int(to_idx - visible_bars) - 1)
        self._visible_range = VisibleRange(from_idx, min(to_idx, count))

    def get_visible_range(self) -> VisibleRange:
        return self._visible_range

    def get_visible_high_low(self) -> tuple:
        high = -float('inf')
        low = float('inf')
        vr = self._visible_range
        for i in range(vr.from_idx, vr.to_idx):
            if 0 <= i < len(self._data):
                d = self._data[i]
                high = max(high, d.high)
                low = min(low, d.low)
        if high == -float('inf'):
            high = 100
        if low == float('inf'):
            low = 0
        return high, low

    # ─── Bar Space ───

    def get_bar_space(self) -> BarSpace:
        return self._bar_space

    def set_bar_space(self, bar: float) -> None:
        self._bar_space.bar = max(1, min(50, bar))
        self._bar_space.half_bar = self._bar_space.bar / 2
        self._bar_space.gap_bar = max(1, int(self._bar_space.bar * 0.8))
        self._bar_space.half_gap_bar = self._bar_space.gap_bar / 2

    def set_total_bar_space(self, width: float) -> None:
        self._total_bar_space = width

    def get_total_bar_space(self) -> float:
        return self._total_bar_space

    # ─── Listeners ───

    def subscribe(self, callback: Callable) -> None:
        self._listeners.append(callback)

    def unsubscribe(self, callback: Callable) -> None:
        if callback in self._listeners:
            self._listeners.remove(callback)

    def notify(self, level: UpdateLevel) -> None:
        for cb in self._listeners:
            cb(level)