"""
Styles — Chart styling and theme management.
Inspired by TradingView's style system.
"""
from __future__ import annotations
from typing import Dict, Optional, Any


class LayoutStyles:
    def __init__(self):
        self.background_color = "#1e222d"
        self.background_type = "solid"
        self.background_gradient_top = "#1e222d"
        self.background_gradient_bottom = "#131722"


class GridStyles:
    def __init__(self):
        self.vert_lines_visible = True
        self.vert_lines_color = "rgba(255,255,255,0.06)"
        self.vert_lines_style = "dashed"
        self.horz_lines_visible = True
        self.horz_lines_color = "rgba(255,255,255,0.06)"
        self.horz_lines_style = "dashed"


class CandleStyles:
    def __init__(self):
        self.up_color = "#26a69a"
        self.down_color = "#ef5350"
        self.up_border_color = "#26a69a"
        self.down_border_color = "#ef5350"
        self.up_wick_color = "#26a69a"
        self.down_wick_color = "#ef5350"


class PriceAxisStyles:
    def __init__(self):
        self.background_color = "transparent"
        self.text_color = "rgba(255,255,255,0.5)"
        self.border_color = "rgba(255,255,255,0.15)"
        self.font_family = "monospace"
        self.font_size = 11


class TimeAxisStyles:
    def __init__(self):
        self.background_color = "transparent"
        self.text_color = "rgba(255,255,255,0.5)"
        self.font_family = "monospace"
        self.font_size = 11


class CrosshairStyles:
    def __init__(self):
        self.vert_line_visible = True
        self.vert_line_color = "rgba(255,255,255,0.25)"
        self.vert_line_width = 1
        self.vert_line_style = "dashed"
        self.horz_line_visible = True
        self.horz_line_color = "rgba(255,255,255,0.25)"
        self.horz_line_width = 1
        self.horz_line_style = "dashed"
        self.horz_line_label_visible = True


class TooltipStyles:
    def __init__(self):
        self.background_color = "rgba(30,34,45,0.9)"
        self.text_color = "#d1d4dc"
        self.border_color = "rgba(255,255,255,0.15)"
        self.border_width = 1
        self.shadow_color = "rgba(0,0,0,0.3)"
        self.font_family = "monospace"
        self.font_size = 11
        self.padding = 6


class Styles:
    """Container for all chart style groups."""

    def __init__(self):
        self.layout = LayoutStyles()
        self.grid = GridStyles()
        self.candle = CandleStyles()
        self.price_axis = PriceAxisStyles()
        self.time_axis = TimeAxisStyles()
        self.crosshair = CrosshairStyles()
        self.tooltip = TooltipStyles()

    def apply(self, overrides: Dict[str, Any]) -> None:
        """Apply style overrides from a flat dict with dot-notation keys."""
        for key, value in overrides.items():
            parts = key.split(".")
            obj = self
            for part in parts[:-1]:
                obj = getattr(obj, part, None)
                if obj is None:
                    break
            if obj is not None:
                setattr(obj, parts[-1], value)

    def to_dict(self) -> dict:
        """Serialize to a dict for JS consumption."""
        # This is simplified; in practice we'd recursively convert
        categories = ["layout", "grid", "candle", "price_axis",
                       "time_axis", "crosshair", "tooltip"]
        result = {}
        for cat in categories:
            obj = getattr(self, cat)
            result[cat] = {k: v for k, v in obj.__dict__.items()
                          if not k.startswith("_")}
        return result


class Theme:
    """Factory for creating preset themes."""

    @staticmethod
    def light() -> Styles:
        s = Styles()
        s.layout.background_color = "#ffffff"
        s.layout.background_gradient_top = "#ffffff"
        s.layout.background_gradient_bottom = "#f5f5f5"
        s.grid.vert_lines_color = "rgba(0,0,0,0.06)"
        s.grid.horz_lines_color = "rgba(0,0,0,0.06)"
        s.candle.up_color = "#26a69a"
        s.candle.down_color = "#ef5350"
        s.price_axis.text_color = "rgba(0,0,0,0.5)"
        s.price_axis.border_color = "rgba(0,0,0,0.15)"
        s.time_axis.text_color = "rgba(0,0,0,0.5)"
        s.crosshair.vert_line_color = "rgba(0,0,0,0.2)"
        s.crosshair.horz_line_color = "rgba(0,0,0,0.2)"
        s.tooltip.background_color = "rgba(255,255,255,0.9)"
        s.tooltip.text_color = "#333333"
        return s

    @staticmethod
    def dark() -> Styles:
        return Styles()