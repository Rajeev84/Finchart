"""
EventBus — Pub/sub system for chart interactions.
Inspired by KLineCharts' Action system.
"""
from typing import Dict, List, Callable, Any


class EventBus:
    def __init__(self):
        self._listeners: Dict[str, List[Callable]] = {}
    
    def subscribe(self, event_type: str, callback: Callable) -> None:
        if event_type not in self._listeners:
            self._listeners[event_type] = []
        self._listeners[event_type].append(callback)
    
    def unsubscribe(self, event_type: str, callback: Callable) -> None:
        if event_type in self._listeners and callback in self._listeners[event_type]:
            self._listeners[event_type].remove(callback)
    
    def emit(self, event_type: str, data: Any = None) -> None:
        for cb in self._listeners.get(event_type, []):
            cb(data)