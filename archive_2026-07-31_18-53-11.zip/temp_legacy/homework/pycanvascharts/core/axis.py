"""
Axis — Time and price axis implementations.
"""
from __future__ import annotations
from typing import Optional, Any


class TimeAxis:
    """Time axis (x-axis) at the bottom of the chart."""
    def __init__(self, store: Any):
        self._store = store
        self._width = 0
        self._height = 28

    def set_size(self, width: float, height: float) -> None:
        self._width = width
        self._height = height

    def get_width(self) -> float:
        return self._width

    def get_height(self) -> float:
        return self._height


class PriceAxis:
    """Price axis (y-axis) on the left or right side."""
    def __init__(self, store: Any, position: str = "right"):
        self._store = store
        self._position = position
        self._width = 60
        self._height = 0
        self._visible = True
        self._min_price = 0.0
        self._max_price = 100.0
        self._ratio = 1.0

    def set_size(self, width: float, height: float) -> None:
        self._width = width
        self._height = height

    def get_width(self) -> float:
        return self._width

    def get_height(self) -> float:
        return self._height

    def recalculate(self, low: float, high: float) -> None:
        """Recalculate price scale based on visible data range."""
        price_range = max(high - low, 0.001)
        self._min_price = low - price_range * 0.1
        self._max_price = high + price_range * 0.1
        if self._height > 0:
            self._ratio = self._height / (self._max_price - self._min_price)

    def price_to_y(self, price: float) -> float:
        """Convert price to y-coordinate."""
        return self._height - (price - self._min_price) * self._ratio

    def y_to_price(self, y: float) -> float:
        """Convert y-coordinate to price."""
        return self._min_price + (self._height - y) / self._ratio