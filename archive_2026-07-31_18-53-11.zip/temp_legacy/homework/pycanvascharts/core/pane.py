"""
Pane — Chart pane management for main chart, indicators, and x-axis.
"""
from __future__ import annotations
from typing import List, Optional, Any


class BoundingBox:
    """Rectangle bounding box."""
    def __init__(self, x: float = 0, y: float = 0, width: float = 0, height: float = 0):
        self.x = x
        self.y = y
        self.width = width
        self.height = height


class Pane:
    """Base pane class."""
    def __init__(self, pane_id: str):
        self.id = pane_id
        self._series: List[Any] = []
        self._bounding = BoundingBox()
        self._main_bounding = BoundingBox()
        self._state = "normal"
        self._min_height = 30
        self.stretch_factor = 1.0

    def add_series(self, series: Any) -> None:
        self._series.append(series)

    def get_series(self) -> List[Any]:
        return self._series

    def set_bounding(self, x: float, y: float, width: float, height: float) -> None:
        self._bounding = BoundingBox(x, y, width, height)

    def get_bounding(self) -> BoundingBox:
        return self._bounding

    def set_main_bounding(self, x: float, y: float, width: float, height: float) -> None:
        self._main_bounding = BoundingBox(x, y, width, height)

    def get_main_bounding(self) -> BoundingBox:
        return self._main_bounding

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "state": self._state,
            "bounding": {
                "x": self._bounding.x,
                "y": self._bounding.y,
                "width": self._bounding.width,
                "height": self._bounding.height,
            },
            "main_bounding": {
                "x": self._main_bounding.x,
                "y": self._main_bounding.y,
                "width": self._main_bounding.width,
                "height": self._main_bounding.height,
            },
        }


class MainPane(Pane):
    """Main chart pane for price series."""
    def __init__(self):
        super().__init__("main")


class IndicatorPane(Pane):
    """Pane for technical indicators."""
    def __init__(self, name: str):
        super().__init__(f"indicator_{name}")
        self.indicator_name = name


class XAxisPane(Pane):
    """Pane for the time axis at the bottom."""
    def __init__(self):
        super().__init__("x_axis")
        self._min_height = 28
        self.stretch_factor = 0