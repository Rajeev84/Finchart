"""
Chart — Main orchestrator class.
Inspired by TradingView's ChartWidget and KLineCharts' Chart.
"""
from __future__ import annotations
from typing import List, Dict, Optional, Type, Any, Callable
import json
import uuid

from .store import ChartStore, UpdateLevel, KLineData
from .pane import MainPane, IndicatorPane, XAxisPane, Pane, BoundingBox
from .axis import TimeAxis, PriceAxis
from .styles import Styles, Theme
from .events import EventBus


class Chart:
    """
    Main chart class — the public API entry point.
    
    Usage:
        chart = Chart(width=800, height=500, theme=Theme.dark())
        series = chart.add_series(CandlestickSeries, data=[...])
        chart.save("chart.html")
        chart.show()  # In Jupyter
    """
    
    def __init__(self, width: int = 800, height: int = 500, 
                 styles: Optional[Styles] = None,
                 theme: Optional[str] = None):
        self._id = f"chart_{uuid.uuid4().hex[:8]}"
        self._width = width
        self._height = height
        
        # State
        self._store = ChartStore()
        self._styles = styles or (Theme.dark() if theme == "dark" else Theme.light())
        self._event_bus = EventBus()
        
        # Panes
        self._main_pane = MainPane()
        self._x_axis_pane = XAxisPane()
        self._indicator_panes: Dict[str, IndicatorPane] = {}
        self._panes: List[Pane] = [self._main_pane, self._x_axis_pane]
        
        # Axes
        self._time_axis = TimeAxis(self._store)
        self._right_price_axis = PriceAxis(self._store, position="right")
        self._left_price_axis = PriceAxis(self._store, position="left")
        self._left_price_axis._visible = False
        
        # Series registry
        self._series: List[Any] = []
        
        # Renderer
        self._renderer: Optional[Any] = None
        
        # Subscribe store updates
        self._store.subscribe(self._on_store_update)
        
        # Layout state
        self._layout_dirty = True
        self._separator_size = 2
        
    # ─── Public API ───
    
    def add_series(self, series_class: Type, data: Optional[List[KLineData]] = None,
                   pane: Optional[Pane] = None, **options) -> Any:
        """Add a data series to the chart."""
        target_pane = pane or self._main_pane
        series = series_class(store=self._store, styles=self._styles, **options)
        
        if data:
            series.set_data(data)
        
        target_pane.add_series(series)
        self._series.append(series)
        
        if data and not self._store.get_data_list():
            self._store.set_data(data)
        
        self._layout_dirty = True
        self._store.notify(UpdateLevel.Full)
        return series
    
    def remove_series(self, series: Any) -> None:
        """Remove a series from the chart."""
        if series in self._series:
            self._series.remove(series)
            for pane in self._panes:
                if series in pane.get_series():
                    pane.get_series().remove(series)
            self._store.notify(UpdateLevel.Full)
    
    def add_indicator(self, name: str, indicator_class: Type, **params) -> Any:
        """Add a technical indicator pane."""
        pane = IndicatorPane(name)
        self._indicator_panes[name] = pane
        self._panes.insert(-1, pane)  # Before x-axis
        
        indicator = indicator_class(store=self._store, styles=self._styles, **params)
        pane.add_series(indicator)
        self._store.add_indicator(name, indicator)
        
        self._layout_dirty = True
        self._store.notify(UpdateLevel.Full)
        return indicator
    
    def set_data(self, data: List[KLineData]) -> None:
        """Set chart data."""
        self._store.set_data(data)
    
    def append_data(self, data: KLineData) -> None:
        """Stream a new data point."""
        self._store.append_data(data)
    
    def fit_content(self) -> None:
        """Fit all data into view."""
        count = len(self._store.get_data_list())
        if count > 0:
            vr = self._store.get_visible_range()
            self._store._last_bar_right_side_diff_bar_count = 0
            self._store._adjust_visible_range()
            self._store.notify(UpdateLevel.Light)
    
    def set_visible_range(self, from_idx: int, to_idx: int) -> None:
        """Set visible data range by index."""
        count = len(self._store.get_data_list())
        if count == 0:
            return
        self._store._last_bar_right_side_diff_bar_count = (to_idx - count)
        self._store._adjust_visible_range()
        self._store.notify(UpdateLevel.Light)
    
    def apply_styles(self, overrides: Dict[str, Any]) -> None:
        """Apply style overrides."""
        self._styles.apply(overrides)
        self._store.notify(UpdateLevel.Full)
    
    def set_theme(self, theme_name: str) -> None:
        """Set theme (light/dark)."""
        self._styles = Theme.dark() if theme_name == "dark" else Theme.light()
        self._store.notify(UpdateLevel.Full)
    
    def subscribe(self, event_type: str, callback: Callable) -> None:
        """Subscribe to chart events."""
        self._event_bus.subscribe(event_type, callback)
    
    # ─── Layout ───
    
    def _calculate_layout(self) -> None:
        """Calculate pane and axis bounding boxes."""
        if not self._layout_dirty:
            return
        
        # Calculate Y-axis widths
        right_axis_width = self._right_price_axis.get_width()
        left_axis_width = self._left_price_axis.get_width() if self._left_price_axis._visible else 0
        
        main_width = self._width - left_axis_width - right_axis_width
        main_left = left_axis_width
        
        # Calculate pane heights
        x_axis_height = self._time_axis.get_height()
        separator_total = self._separator_size * max(0, len(self._panes) - 2)
        content_height = self._height - x_axis_height - separator_total
        
        # Distribute height among content panes
        normal_panes = [p for p in self._panes if p.id != "x_axis" and p._state == "normal"]
        total_stretch = sum(
            getattr(p, 'stretch_factor', 1.0) for p in normal_panes
        )
        
        y_offset = 0
        for pane in self._panes:
            if pane.id == "x_axis":
                pane.set_bounding(0, y_offset, self._width, x_axis_height)
                self._time_axis.set_size(self._width, x_axis_height)
                y_offset += x_axis_height
            else:
                if pane._state == "maximize":
                    h = content_height
                elif pane._state == "minimize":
                    h = pane._min_height
                else:
                    ratio = getattr(pane, 'stretch_factor', 1.0) / total_stretch
                    h = content_height * ratio
                
                pane.set_bounding(0, y_offset, self._width, h)
                pane.set_main_bounding(main_left, y_offset, main_width, h)
                
                # Update price axes
                self._right_price_axis.set_size(right_axis_width, h)
                self._left_price_axis.set_size(left_axis_width, h)
                
                y_offset += h + self._separator_size
        
        self._store.set_total_bar_space(main_width)
        self._layout_dirty = False
    
    def _on_store_update(self, level: UpdateLevel) -> None:
        """Handle store update notifications."""
        self._calculate_layout()
        
        # Recalculate price scales
        high, low = self._store.get_visible_high_low()
        self._right_price_axis.recalculate(low, high)
        if self._left_price_axis._visible:
            self._left_price_axis.recalculate(low, high)
        
        # Notify renderer
        if self._renderer:
            self._renderer.render(level)
        
        # Emit events
        level_name = level.name if level else "Full"
        self._event_bus.emit("update", {"level": level_name})
    
    # ─── Output ───
    
    def save(self, filepath: str) -> None:
        """Save chart as standalone HTML file."""
        html = self._generate_html()
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(html)
    
    def show(self) -> None:
        """Display chart in Jupyter notebook."""
        try:
            from IPython.display import HTML, display
            html = self._generate_html()
            display(HTML(html))
        except ImportError:
            print("IPython not available. Use chart.save('chart.html') instead.")
    
    def to_html(self) -> str:
        """Return chart as HTML string."""
        return self._generate_html()
    
    def _generate_html(self) -> str:
        """Generate complete HTML with embedded Canvas renderer."""
        self._calculate_layout()
        
        # Serialize state for JS renderer
        state = {
            "id": self._id,
            "width": self._width,
            "height": self._height,
            "styles": self._styles.to_dict(),
            "data": [d.to_dict() for d in self._store.get_data_list()],
            "visible_range": {
                "from": self._store.get_visible_range().from_idx,
                "to": self._store.get_visible_range().to_idx,
            },
            "bar_space": self._store.get_bar_space().__dict__,
            "panes": [p.to_dict() for p in self._panes],
            "layout": {
                "main_left": self._main_pane.get_main_bounding().x,
                "main_width": self._main_pane.get_main_bounding().width,
            }
        }
        
        return f'''<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  body {{ margin: 0; padding: 0; background: {self._styles.layout.background_color}; overflow: hidden; }}
  #{self._id} {{ position: relative; width: {self._width}px; height: {self._height}px; }}
  #{self._id} canvas {{ position: absolute; top: 0; left: 0; }}
</style>
</head>
<body>
<div id="{self._id}">
  <canvas id="{self._id}_bg" style="z-index: 1;"></canvas>
  <canvas id="{self._id}_overlay" style="z-index: 2;"></canvas>
</div>
<script>
(function() {{
  const state = {json.dumps(state)};
  const dpr = window.devicePixelRatio || 1;
  
  // Setup canvases with DPR scaling
  function setupCanvas(id, w, h) {{
    const canvas = document.getElementById(id);
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    return {{ canvas, ctx }};
  }}
  
  const bg = setupCanvas('{self._id}_bg', state.width, state.height);
  const ov = setupCanvas('{self._id}_overlay', state.width, state.height);
  
  // Coordinate helpers
  const store = {{
    data: state.data,
    barSpace: state.bar_space,
    visibleRange: state.visible_range,
    totalBarSpace: state.layout.main_width,
    lastBarRightSideDiffBarCount: 0,
    
    dataIndexToCoordinate(idx) {{
      const count = this.data.length;
      const delta = count + this.lastBarRightSideDiffBarCount - idx;
      return this.totalBarSpace - (delta - 0.5) * this.barSpace.bar;
    }},
    
    coordinateToDataIndex(x) {{
      const count = this.data.length;
      const delta = (this.totalBarSpace - x) / this.barSpace.bar;
      return Math.ceil(count + this.lastBarRightSideDiffBarCount - delta) - 1;
    }},
    
    getVisibleRange() {{
      return this.visibleRange;
    }}
  }};
  
  // Styles
  const styles = state.styles;
  
  // Price scale
  const priceAxis = {{
    minPrice: 0, maxPrice: 100, height: 0, ratio: 1,
    recalculate(min, max, height) {{
      const range = Math.max(max - min, 0.001);
      this.minPrice = min - range * 0.1;
      this.maxPrice = max + range * 0.1;
      this.height = height;
      this.ratio = height / (this.maxPrice - this.minPrice);
    }},
    priceToY(price) {{
      return this.height - (price - this.minPrice) * this.ratio;
    }},
    yToPrice(y) {{
      return this.minPrice + (this.height - y) / this.ratio;
    }}
  }};
  
  // Calculate visible high/low
  let vHigh = -Infinity, vLow = Infinity;
  for (let i = state.visible_range.from; i < state.visible_range.to; i++) {{
    if (i >= 0 && i < state.data.length) {{
      const d = state.data[i];
      vHigh = Math.max(vHigh, d.high);
      vLow = Math.min(vLow, d.low);
    }}
  }}
  priceAxis.recalculate(vLow, vHigh, state.height - 28);
  
  // Drawing functions
  function drawBackground(ctx, w, h) {{
    const l = styles.layout;
    if (l.background_type === 'gradient') {{
      const grad = ctx.createLinearGradient(0, 0, 0, h);
      grad.addColorStop(0, l.background_gradient_top);
      grad.addColorStop(1, l.background_gradient_bottom);
      ctx.fillStyle = grad;
    }} else {{
      ctx.fillStyle = l.background_color;
    }}
    ctx.fillRect(0, 0, w, h);
  }}
  
  function drawGrid(ctx, w, h, mainLeft, mainWidth) {{
    const g = styles.grid;
    if (!g.vert_lines_visible && !g.horz_lines_visible) return;
    
    ctx.lineWidth = 1;
    ctx.setLineDash(g.vert_lines_style === 'dashed' ? [4, 4] : []);
    
    // Vertical time grid
    if (g.vert_lines_visible) {{
      ctx.strokeStyle = g.vert_lines_color;
      const step = Math.max(1, Math.floor((state.visible_range.to - state.visible_range.from) / 6));
      for (let i = state.visible_range.from; i < state.visible_range.to; i += step) {{
        const x = store.dataIndexToCoordinate(i);
        if (x >= mainLeft && x <= mainLeft + mainWidth) {{
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, h - 28);
          ctx.stroke();
        }}
      }}
    }}
    
    // Horizontal price grid
    if (g.horz_lines_visible) {{
      ctx.strokeStyle = g.horz_lines_color;
      ctx.setLineDash(g.horz_lines_style === 'dashed' ? [4, 4] : []);
      const range = priceAxis.maxPrice - priceAxis.minPrice;
      const roughStep = range / 5;
      const mag = Math.pow(10, Math.floor(Math.log10(roughStep)));
      const residual = roughStep / mag;
      const step = (residual < 1.5 ? 1 : residual < 3 ? 2 : residual < 7 ? 5 : 10) * mag;
      const start = Math.ceil(priceAxis.minPrice / step) * step;
      const end = Math.floor(priceAxis.maxPrice / step) * step;
      
      for (let p = start; p <= end; p += step) {{
        const y = priceAxis.priceToY(p);
        if (y >= 0 && y <= h - 28) {{
          ctx.beginPath();
          ctx.moveTo(mainLeft, y);
          ctx.lineTo(mainLeft + mainWidth, y);
          ctx.stroke();
        }}
      }}
    }}
    ctx.setLineDash([]);
n  }}
  
  function drawCandles(ctx, mainLeft, mainWidth) {{
    const c = styles.candle;
    const halfGap = store.barSpace.half_gap_bar;
    
    for (let i = state.visible_range.from; i < state.visible_range.to; i++) {{
      if (i < 0 || i >= state.data.length) continue;
      const d = state.data[i];
      const x = store.dataIndexToCoordinate(i);
      if (x < mainLeft - 20 || x > mainLeft + mainWidth + 20) continue;
      
      const isUp = d.close >= d.open;
      const color = isUp ? c.up_color : c.down_color;
      const yOpen = priceAxis.priceToY(d.open);
      const yClose = priceAxis.priceToY(d.close);
      const yHigh = priceAxis.priceToY(d.high);
      const yLow = priceAxis.priceToY(d.low);
      const bodyTop = Math.min(yOpen, yClose);
      const bodyBottom = Math.max(yOpen, yClose);
      const bodyHeight = Math.max(bodyBottom - bodyTop, 1);
      
      ctx.fillStyle = color;
      ctx.strokeStyle = isUp ? c.up_border_color : c.down_border_color;
      
      // Wick
      ctx.beginPath();
      ctx.moveTo(x, yHigh);
      ctx.lineTo(x, yLow);
      ctx.strokeStyle = isUp ? c.up_wick_color : c.down_wick_color;
      ctx.stroke();
      
      // Body
      ctx.fillRect(x - halfGap, bodyTop, halfGap * 2, bodyHeight);
n      ctx.strokeRect(x - halfGap, bodyTop, halfGap * 2, bodyHeight);
n    }}
n  }}
  
  function drawAxes(ctx, w, h, mainLeft, mainWidth) {{
    const axisH = 28;
    const pa = styles.price_axis;
n    const ta = styles.time_axis;
n    
n    // Price axis background
n    if (pa.background_color !== 'transparent') {{
n      ctx.fillStyle = pa.background_color;
n      ctx.fillRect(mainLeft + mainWidth, 0, w - mainLeft - mainWidth, h - axisH);\n      ctx.fillRect(0, 0, mainLeft, h - axisH);\n    }}\n    
n    // Time axis background
n    if (ta.background_color !== 'transparent') {{
n      ctx.fillStyle = ta.background_color;\n      ctx.fillRect(0, h - axisH, w, axisH);\n    }}\n    
n    // Price ticks (right)\n    ctx.fillStyle = pa.text_color;\n    ctx.font = `${{pa.font_size}}px ${{pa.font_family}}`;\n    ctx.textAlign = 'left';\n    ctx.textBaseline = 'middle';\n    \n    const range = priceAxis.maxPrice - priceAxis.minPrice;\n    const roughStep = range / 5;\n    const mag = Math.pow(10, Math.floor(Math.log10(roughStep)));\n    const residual = roughStep / mag;\n    const step = (residual < 1.5 ? 1 : residual < 3 ? 2 : residual < 7 ? 5 : 10) * mag;\n    const start = Math.ceil(priceAxis.minPrice / step) * step;\n    const end = Math.floor(priceAxis.maxPrice / step) * step;\n    \n    for (let p = start; p <= end; p += step) {{\n      const y = priceAxis.priceToY(p);\n      if (y >= 0 && y <= h - axisH) {{\n        let label;\n        const ap = Math.abs(p);\n        if (ap >= 10000) label = p.toLocaleString('en', {{maximumFractionDigits: 0}});\n        else if (ap >= 1000) label = p.toLocaleString('en', {{maximumFractionDigits: 1}});\n        else if (ap >= 100) label = p.toFixed(2);\n        else if (ap >= 1) label = p.toFixed(4);\n        else label = p.toFixed(6);\n        \n        ctx.fillText(label, mainLeft + mainWidth + 5, y);\n      }}\n    }}\n    \n    // Time ticks\n    ctx.fillStyle = ta.text_color;\n    ctx.textAlign = 'center';\n    ctx.textBaseline = 'top';\n    const tStep = Math.max(1, Math.floor((state.visible_range.to - state.visible_range.from) / 6));\n    for (let i = state.visible_range.from; i < state.visible_range.to; i += tStep) {{\n      if (i < 0 || i >= state.data.length) continue;\n      const x = store.dataIndexToCoordinate(i);\n      if (x >= mainLeft && x <= mainLeft + mainWidth) {{\n        const d = new Date(state.data[i].timestamp);\n        const label = `${{String(d.getMonth()+1).padStart(2,'0')}}-${{String(d.getDate()).padStart(2,'0')}}`;\n        ctx.fillText(label, x, h - axisH + 6);\n      }}\n    }}\n    \n    // Axis borders\n    ctx.strokeStyle = pa.border_color;\n    ctx.lineWidth = 1;\n    ctx.beginPath();\n    ctx.moveTo(mainLeft + mainWidth, 0);\n    ctx.lineTo(mainLeft + mainWidth, h - axisH);\n    ctx.moveTo(mainLeft, 0);\n    ctx.lineTo(mainLeft, h - axisH);\n    ctx.moveTo(0, h - axisH);\n    ctx.lineTo(w, h - axisH);\n    ctx.stroke();\n  }}\n  \n  // Crosshair\n  let crosshairX = null, crosshairY = null;\n  \n  function drawCrosshair(ctx, w, h, mainLeft, mainWidth) {{\n    if (crosshairX === null || crosshairY === null) return;\n    \n    const c = styles.crosshair;\n    if (!c.vert_line_visible && !c.horz_line_visible) return;\n    \n    ctx.save();\n    ctx.setLineDash(c.vert_line_style === 'dashed' ? [4, 4] : []);\n    ctx.lineWidth = c.vert_line_width;\n    ctx.strokeStyle = c.vert_line_color;\n    \n    if (c.vert_line_visible && crosshairX >= mainLeft && crosshairX <= mainLeft + mainWidth) {{\n      ctx.beginPath();\n      ctx.moveTo(crosshairX, 0);\n      ctx.lineTo(crosshairX, h - 28);\n      ctx.stroke();\n    }}\n    \n    ctx.setLineDash(c.horz_line_style === 'dashed' ? [4, 4] : []);\n    ctx.lineWidth = c.horz_line_width;\n    ctx.strokeStyle = c.horz_line_color;\n    \n    if (c.horz_line_visible && crosshairY >= 0 && crosshairY <= h - 28) {{\n      ctx.beginPath();\n      ctx.moveTo(mainLeft, crosshairY);\n      ctx.lineTo(mainLeft + mainWidth, crosshairY);\n      ctx.stroke();\n    }}\n    \n    // Price label\n    if (c.horz_line_label_visible) {{\n      const price = priceAxis.yToPrice(crosshairY);\n      const label = price.toFixed(2);\n      ctx.font = '11px sans-serif';\n      const tw = ctx.measureText(label).width;\n      ctx.fillStyle = c.horz_line_color;\n      ctx.fillRect(mainLeft + mainWidth + 2, crosshairY - 8, tw + 8, 16);\n      ctx.fillStyle = '#fff';\n      ctx.textAlign = 'left';\n      ctx.textBaseline = 'middle';\n      ctx.fillText(label, mainLeft + mainWidth + 6, crosshairY);\n    }}\n    \n    ctx.restore();\n  }}\n  \n  // Tooltip\n  function drawTooltip(ctx, w, h, mainLeft, mainWidth) {{\n    if (crosshairX === null) return;\n    const idx = store.coordinateToDataIndex(crosshairX);\n    if (idx < 0 || idx >= state.data.length) return;\n    \n    const d = state.data[idx];\n    const t = styles.tooltip;\n    const lines = [\n      `O: ${{d.open.toFixed(4)}}`,\n      `H: ${{d.high.toFixed(4)}}`,\n      `L: ${{d.low.toFixed(4)}}`,\n      `C: ${{d.close.toFixed(4)}}`,\n    ];\n    if (d.volume) lines.push(`V: ${{d.volume.toFixed(0)}}`);\n    \n    ctx.font = `${{t.font_size}}px ${{t.font_family}}`;\n    const lineH = t.font_size + 4;\n    const maxW = Math.max(...lines.map(l => ctx.measureText(l).width));\n    const boxW = maxW + t.padding * 2;\n    const boxH = lines.length * lineH + t.padding * 2;\n    \n    let bx = crosshairX + 15;\n    let by = crosshairY + 15;\n    if (bx + boxW > mainLeft + mainWidth) bx = crosshairX - boxW - 15;\n    if (by + boxH > h - 28) by = crosshairY - boxH - 15;\n    \n    // Shadow\n    ctx.fillStyle = t.shadow_color;\n    ctx.fillRect(bx + 2, by + 2, boxW, boxH);\n    \n    // Background\n    ctx.fillStyle = t.background_color;\n    ctx.fillRect(bx, by, boxW, boxH);\n    \n    // Border\n    ctx.strokeStyle = t.border_color;\n    ctx.lineWidth = t.border_width;\n    ctx.strokeRect(bx, by, boxW, boxH);\n    \n    // Text\n    ctx.fillStyle = t.text_color;\n    ctx.textAlign = 'left';\n    ctx.textBaseline = 'top';\n    lines.forEach((line, i) => {{\n      ctx.fillText(line, bx + t.padding, by + t.padding + i * lineH);\n    }});\n  }}\n  \n  // Main render\n  function render() {{\n    const w = state.width;\n    const h = state.height;\n    const mainLeft = state.layout.main_left;\n    const mainWidth = state.layout.main_width;\n    \n    // Background layer\n    drawBackground(bg.ctx, w, h);\n    drawGrid(bg.ctx, w, h, mainLeft, mainWidth);\n    drawCandles(bg.ctx, mainLeft, mainWidth);\n    drawAxes(bg.ctx, w, h, mainLeft, mainWidth);\n    \n    // Overlay layer\n    ov.ctx.clearRect(0, 0, w, h);\n    drawCrosshair(ov.ctx, w, h, mainLeft, mainWidth);\n    drawTooltip(ov.ctx, w, h, mainLeft, mainWidth);\n  }}\n  \n  // Events\n  const container = document.getElementById('{self._id}');\n  let isDragging = false;\n  let lastX = 0;\n  \n  container.addEventListener('mousemove', (e) => {{\n    const rect = container.getBoundingClientRect();\n    crosshairX = e.clientX - rect.left;\n    crosshairY = e.clientY - rect.top;\n    \n    if (isDragging) {{\n      const dx = crosshairX - lastX;\n      store.lastBarRightSideDiffBarCount -= dx / store.barSpace.bar;\n      // Clamp\n      const count = store.data.length;\n      const visible = store.totalBarSpace / store.barSpace.bar;\n      const maxR = visible;\n      const minR = -count + 2;\n      store.lastBarRightSideDiffBarCount = Math.max(minR, Math.min(maxR, store.lastBarRightSideDiffBarCount));\n      lastX = crosshairX;\n      \n      // Recalculate visible range\n      const to = Math.round(store.lastBarRightSideDiffBarCount + count + 0.5);\n      const from = Math.max(0, Math.round(to - visible) - 1);\n      state.visible_range.from = from;\n      state.visible_range.to = Math.min(to, count);\n    }}\n    \n    render();\n  }});\n  \n  container.addEventListener('mouseleave', () => {{\n    crosshairX = null;\n    crosshairY = null;\n    isDragging = false;\n    render();\n  }});\n  \n  container.addEventListener('mousedown', (e) => {{\n    isDragging = true;\n    lastX = e.clientX - container.getBoundingClientRect().left;\n  }});\n  \n  window.addEventListener('mouseup', () => {{\n    isDragging = false;\n  }});\n  \n  container.addEventListener('wheel', (e) => {{\n    e.preventDefault();\n    const rect = container.getBoundingClientRect();\n    const x = e.clientX - rect.left;\n    const floatIdx = store.coordinateToDataIndex(x);\n    const scale = e.deltaY > 0 ? -1 : 1;\n    const newBar = store.barSpace.bar + scale * (store.barSpace.bar / 10);\n    store.barSpace.bar = Math.max(1, Math.min(50, newBar));\n    store.barSpace.half_bar = store.barSpace.bar / 2;\n    store.barSpace.gap_bar = Math.max(1, Math.floor(store.barSpace.bar * 0.8));\n    store.barSpace.half_gap_bar = Math.floor(store.barSpace.gap_bar / 2);\n    store.lastBarRightSideDiffBarCount += floatIdx - store.coordinateToDataIndex(x);\n    \n    const count = store.data.length;\n    const visible = store.totalBarSpace / store.barSpace.bar;\n    const to = Math.round(store.lastBarRightSideDiffBarCount + count + 0.5);\n    state.visible_range.from = Math.max(0, Math.round(to - visible) - 1);\n    state.visible_range.to = Math.min(to, count);\n    \n    render();\n  }}, {{ passive: false }});\n  \n  // Initial render\n  render();\n}})();\n</script>
</body>
</html>'''