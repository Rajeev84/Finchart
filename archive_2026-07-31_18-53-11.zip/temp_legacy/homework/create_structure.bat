@echo off
setlocal

:: Create root folder
mkdir pycanvascharts

:: Create subfolders
mkdir pycanvascharts\core
mkdir pycanvascharts\series
mkdir pycanvascharts\renderers
mkdir pycanvascharts\indicators
mkdir pycanvascharts\utils

:: Create root files
type nul > pycanvascharts\__init__.py

:: Core
type nul > pycanvascharts\core\chart.py
type nul > pycanvascharts\core\store.py
type nul > pycanvascharts\core\pane.py
type nul > pycanvascharts\core\axis.py
type nul > pycanvascharts\core\styles.py
type nul > pycanvascharts\core\events.py

:: Series
type nul > pycanvascharts\series\base.py
type nul > pycanvascharts\series\candlestick.py
type nul > pycanvascharts\series\line.py
type nul > pycanvascharts\series\area.py
type nul > pycanvascharts\series\bar.py
type nul > pycanvascharts\series\histogram.py

:: Renderers
type nul > pycanvascharts\renderers\canvas_renderer.py

:: Indicators
type nul > pycanvascharts\indicators\sma.py

:: Utils
type nul > pycanvascharts\utils\coordinates.py
type nul > pycanvascharts\utils\formatters.py

echo.
echo Project structure created successfully!
pause