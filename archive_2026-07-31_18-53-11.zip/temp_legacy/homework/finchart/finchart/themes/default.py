"""Theme Engine - Color schemes and visual styling."""
from __future__ import annotations

from typing import Dict, Any
from dataclasses import dataclass, field

from finchart.core.types import Color


@dataclass
class Theme:
    """Complete chart theme definition."""

    # Background
    background: Color = field(default_factory=lambda: Color(30, 34, 45))
    chart_background: Color = field(default_factory=lambda: Color(30, 34, 45))

    # Grid
    grid_color: Color = field(default_factory=lambda: Color(42, 46, 57))
    grid_text: Color = field(default_factory=lambda: Color(132, 140, 150))
    grid_text_size: int = 11

    # Crosshair
    crosshair_color: Color = field(default_factory=lambda: Color(151, 159, 170, 0.5))
    crosshair_text: Color = field(default_factory=lambda: Color(255, 255, 255))
    crosshair_bg: Color = field(default_factory=lambda: Color(60, 63, 75))

    # Candlesticks
    bullish_color: Color = field(default_factory=lambda: Color(38, 166, 154))
    bearish_color: Color = field(default_factory=lambda: Color(239, 83, 80))
    bullish_wick: Color = field(default_factory=lambda: Color(38, 166, 154))
    bearish_wick: Color = field(default_factory=lambda: Color(239, 83, 80))

    # Line/Area
    line_color: Color = field(default_factory=lambda: Color(33, 150, 243))
    area_top_color: Color = field(default_factory=lambda: Color(33, 150, 243, 0.4))
    area_bottom_color: Color = field(default_factory=lambda: Color(33, 150, 243, 0.0))

    # Volume
    volume_bullish: Color = field(default_factory=lambda: Color(38, 166, 154, 0.5))
    volume_bearish: Color = field(default_factory=lambda: Color(239, 83, 80, 0.5))

    # Axis
    axis_text: Color = field(default_factory=lambda: Color(132, 140, 150))
    axis_line: Color = field(default_factory=lambda: Color(55, 60, 70))
    axis_bg: Color = field(default_factory=lambda: Color(30, 34, 45))

    # Selection
    selection_color: Color = field(default_factory=lambda: Color(255, 255, 255, 0.3))
    hover_color: Color = field(default_factory=lambda: Color(255, 255, 255, 0.1))

    # UI
    tooltip_bg: Color = field(default_factory=lambda: Color(45, 48, 60))
    tooltip_border: Color = field(default_factory=lambda: Color(60, 63, 75))
    tooltip_text: Color = field(default_factory=lambda: Color(255, 255, 255))

    # Border
    border_color: Color = field(default_factory=lambda: Color(42, 46, 57))

    def to_tk_color(self, color: Color) -> str:
        """Convert Color to Tkinter color string."""
        if color.a < 1.0:
            return color.to_rgba()
        return color.to_hex()


# Predefined themes
DARK_THEME = Theme()

LIGHT_THEME = Theme(
    background=Color(255, 255, 255),
    chart_background=Color(255, 255, 255),
    grid_color=Color(230, 232, 235),
    grid_text=Color(100, 100, 100),
    bullish_color=Color(33, 150, 83),
    bearish_color=Color(217, 48, 37),
    bullish_wick=Color(33, 150, 83),
    bearish_wick=Color(217, 48, 37),
    axis_text=Color(100, 100, 100),
    axis_line=Color(200, 200, 200),
    axis_bg=Color(255, 255, 255),
    border_color=Color(200, 200, 200),
    crosshair_color=Color(100, 100, 100, 0.3),
    tooltip_bg=Color(250, 250, 250),
    tooltip_border=Color(200, 200, 200),
    tooltip_text=Color(50, 50, 50),
)

TRADINGVIEW_DARK = Theme(
    background=Color(19, 23, 34),
    chart_background=Color(19, 23, 34),
    grid_color=Color(34, 38, 49),
    bullish_color=Color(0, 192, 135),
    bearish_color=Color(255, 96, 96),
    bullish_wick=Color(0, 192, 135),
    bearish_wick=Color(255, 96, 96),
    axis_bg=Color(19, 23, 34),
)
