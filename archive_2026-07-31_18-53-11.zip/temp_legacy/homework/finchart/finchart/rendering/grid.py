"""Grid Renderer - Renders grid lines, time axis, and price axis."""
from __future__ import annotations

from typing import List, Optional, Tuple
from dataclasses import dataclass, field
import math
import time
from datetime import datetime

from ..core.types import Viewport, Color
from ..core.events import EventBus
from ..coordinates.engine import CoordinateEngine
from .pipeline import RenderingPipeline, DrawCommand, Layer


@dataclass
class GridStyle:
    """Visual style for grid and axes."""
    grid_color: Color = field(default_factory=lambda: Color(42, 46, 57))
    grid_width: float = 1.0
    axis_text_color: Color = field(default_factory=lambda: Color(131, 131, 131))
    axis_text_font: Tuple[str, int] = ("Segoe UI", 9)
    axis_bg_color: Color = field(default_factory=lambda: Color(18, 18, 18))
    axis_border_color: Color = field(default_factory=lambda: Color(42, 46, 57))
    axis_border_width: float = 1.0
    price_axis_width: float = 60.0
    time_axis_height: float = 25.0
    show_horizontal_grid: bool = True
    show_vertical_grid: bool = True
    show_price_labels: bool = True
    show_time_labels: bool = True


class GridRenderer:
    """Renders grid lines and axis labels.

    Calculates optimal grid spacing based on zoom level and viewport.
    Uses nice number rounding for clean price labels.
    """

    def __init__(
        self,
        pipeline: RenderingPipeline,
        coord_engine: CoordinateEngine,
        style: Optional[GridStyle] = None
    ) -> None:
        self._pipeline = pipeline
        self._coord = coord_engine
        self._style = style or GridStyle()

    @property
    def style(self) -> GridStyle:
        return self._style

    def render(self, data_count: int) -> None:
        """Render grid and axes."""
        commands = []

        # Calculate chart viewport (excluding axes)
        chart_vp = self._get_chart_viewport()

        # Horizontal grid lines (price levels)
        if self._style.show_horizontal_grid:
            commands.extend(self._render_horizontal_grid(chart_vp))

        # Vertical grid lines (time levels)
        if self._style.show_vertical_grid:
            commands.extend(self._render_vertical_grid(chart_vp, data_count))

        # Price axis labels
        if self._style.show_price_labels:
            commands.extend(self._render_price_axis(chart_vp))

        # Time axis labels
        if self._style.show_time_labels:
            commands.extend(self._render_time_axis(chart_vp, data_count))

        # Axis backgrounds and borders
        commands.extend(self._render_axis_backgrounds(chart_vp))

        self._pipeline.add_commands(commands)
        self._pipeline.schedule_layer(Layer.GRID)

    def _get_chart_viewport(self) -> Viewport:
        """Get the chart area viewport (excluding axes)."""
        vp = self._coord.viewport
        return Viewport(
            x=vp.x,
            y=vp.y,
            width=vp.width - self._style.price_axis_width,
            height=vp.height - self._style.time_axis_height
        )

    def _render_horizontal_grid(self, chart_vp: Viewport) -> List[DrawCommand]:
        """Render horizontal price grid lines."""
        commands = []

        min_price = self._coord.price_scale.min_price
        max_price = self._coord.price_scale.max_price
        price_range = max_price - min_price

        if price_range <= 0:
            return commands

        # Calculate optimal price step
        approx_lines = max(3, int(chart_vp.height / 60))
        raw_step = price_range / approx_lines
        step = self._nice_number(raw_step)

        # Round min price to step
        start_price = math.ceil(min_price / step) * step

        y_positions = []
        price = start_price
        while price <= max_price:
            y = self._coord.price_to_y(price)
            if chart_vp.top <= y <= chart_vp.bottom:
                y_positions.append((y, price))
            price += step

        for y, price in y_positions:
            commands.append(DrawCommand(
                layer=Layer.GRID,
                tag=f"hgrid_{price:.6f}",
                item_type="line",
                coords=(chart_vp.left, y, chart_vp.right, y),
                options={
                    "fill": self._style.grid_color.to_hex(),
                    "width": self._style.grid_width,
                },
                z_index=0
            ))

        return commands

    def _render_vertical_grid(self, chart_vp: Viewport, data_count: int) -> List[DrawCommand]:
        """Render vertical time grid lines."""
        commands = []

        if data_count <= 0:
            return commands

        vr = self._coord.visible_range
        visible_count = vr.end_index - vr.start_index

        if visible_count <= 0:
            return commands

        # Calculate optimal bar spacing for labels
        approx_labels = max(2, int(chart_vp.width / 120))
        step_bars = max(1, visible_count // approx_labels)

        # Round to nice number
        step_bars = self._nice_bar_step(step_bars)

        start_idx = (vr.start_index // step_bars) * step_bars

        for i in range(start_idx, vr.end_index + 1, step_bars):
            if i >= data_count:
                break
            x = self._coord.index_to_x(i)
            if chart_vp.left <= x <= chart_vp.right:
                commands.append(DrawCommand(
                    layer=Layer.GRID,
                    tag=f"vgrid_{i}",
                    item_type="line",
                    coords=(x, chart_vp.top, x, chart_vp.bottom),
                    options={
                        "fill": self._style.grid_color.to_hex(),
                        "width": self._style.grid_width,
                    },
                    z_index=0
                ))

        return commands

    def _render_price_axis(self, chart_vp: Viewport) -> List[DrawCommand]:
        """Render price axis labels."""
        commands = []

        axis_x = chart_vp.right
        axis_width = self._style.price_axis_width

        min_price = self._coord.price_scale.min_price
        max_price = self._coord.price_scale.max_price
        price_range = max_price - min_price

        if price_range <= 0:
            return commands

        approx_lines = max(3, int(chart_vp.height / 40))
        raw_step = price_range / approx_lines
        step = self._nice_number(raw_step)
        start_price = math.ceil(min_price / step) * step

        price = start_price
        while price <= max_price:
            y = self._coord.price_to_y(price)
            if chart_vp.top <= y <= chart_vp.bottom:
                label = self._format_price(price)
                commands.append(DrawCommand(
                    layer=Layer.GRID,
                    tag=f"price_label_{price:.6f}",
                    item_type="text",
                    coords=(axis_x + axis_width / 2, y),
                    options={
                        "text": label,
                        "fill": self._style.axis_text_color.to_hex(),
                        "font": self._style.axis_text_font,
                        "anchor": "center",
                    },
                    z_index=10
                ))
            price += step

        return commands

    def _render_time_axis(self, chart_vp: Viewport, data_count: int) -> List[DrawCommand]:
        """Render time axis labels."""
        commands = []

        if data_count <= 0:
            return commands

        axis_y = chart_vp.bottom

        vr = self._coord.visible_range
        visible_count = vr.end_index - vr.start_index

        if visible_count <= 0:
            return commands

        approx_labels = max(2, int(chart_vp.width / 100))
        step_bars = max(1, visible_count // approx_labels)
        step_bars = self._nice_bar_step(step_bars)

        start_idx = (vr.start_index // step_bars) * step_bars

        for i in range(start_idx, min(vr.end_index + 1, data_count), step_bars):
            x = self._coord.index_to_x(i)
            if chart_vp.left <= x <= chart_vp.right:
                # Placeholder - would need actual timestamp from data
                label = self._format_time_index(i)
                commands.append(DrawCommand(
                    layer=Layer.GRID,
                    tag=f"time_label_{i}",
                    item_type="text",
                    coords=(x, axis_y + self._style.time_axis_height / 2),
                    options={
                        "text": label,
                        "fill": self._style.axis_text_color.to_hex(),
                        "font": self._style.axis_text_font,
                        "anchor": "n",
                    },
                    z_index=10
                ))

        return commands

    def _render_axis_backgrounds(self, chart_vp: Viewport) -> List[DrawCommand]:
        """Render axis background rectangles."""
        commands = []
        vp = self._coord.viewport

        # Price axis background
        commands.append(DrawCommand(
            layer=Layer.GRID,
            tag="price_axis_bg",
            item_type="rectangle",
            coords=(chart_vp.right, vp.top, vp.right, vp.bottom),
            options={
                "fill": self._style.axis_bg_color.to_hex(),
                "outline": self._style.axis_border_color.to_hex(),
                "width": self._style.axis_border_width,
            },
            z_index=5
        ))

        # Time axis background
        commands.append(DrawCommand(
            layer=Layer.GRID,
            tag="time_axis_bg",
            item_type="rectangle",
            coords=(vp.left, chart_vp.bottom, chart_vp.right, vp.bottom),
            options={
                "fill": self._style.axis_bg_color.to_hex(),
                "outline": self._style.axis_border_color.to_hex(),
                "width": self._style.axis_border_width,
            },
            z_index=5
        ))

        # Corner fill
        commands.append(DrawCommand(
            layer=Layer.GRID,
            tag="corner_bg",
            item_type="rectangle",
            coords=(chart_vp.right, chart_vp.bottom, vp.right, vp.bottom),
            options={
                "fill": self._style.axis_bg_color.to_hex(),
                "outline": self._style.axis_border_color.to_hex(),
                "width": self._style.axis_border_width,
            },
            z_index=5
        ))

        return commands

    def _nice_number(self, value: float) -> float:
        """Round to a nice number (1, 2, 5, 10, ...)."""
        if value <= 0:
            return 1.0

        exponent = math.floor(math.log10(value))
        fraction = value / (10 ** exponent)

        if fraction <= 1.0:
            nice_fraction = 1.0
        elif fraction <= 2.0:
            nice_fraction = 2.0
        elif fraction <= 5.0:
            nice_fraction = 5.0
        else:
            nice_fraction = 10.0

        return nice_fraction * (10 ** exponent)

    def _nice_bar_step(self, step: int) -> int:
        """Round bar step to nice number."""
        if step <= 1:
            return 1
        if step <= 2:
            return 2
        if step <= 5:
            return 5
        if step <= 10:
            return 10
        if step <= 20:
            return 20
        if step <= 50:
            return 50
        if step <= 100:
            return 100
        return ((step // 100) + 1) * 100

    def _format_price(self, price: float) -> str:
        """Format price for display."""
        abs_price = abs(price)
        if abs_price >= 10000:
            return f"{price:,.0f}"
        elif abs_price >= 100:
            return f"{price:,.2f}"
        elif abs_price >= 1:
            return f"{price:,.4f}"
        elif abs_price >= 0.01:
            return f"{price:,.6f}"
        else:
            return f"{price:.8f}"

    def _format_time_index(self, index: int) -> str:
        """Format time index for display (placeholder)."""
        return str(index)
