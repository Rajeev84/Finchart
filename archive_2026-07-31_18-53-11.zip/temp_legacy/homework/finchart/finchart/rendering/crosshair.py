"""Crosshair Renderer - Renders crosshair lines, hover info, and tooltip."""
from __future__ import annotations

from typing import List, Optional, Tuple
from dataclasses import dataclass, field

from ..core.types import Viewport, Color, OHLCV
from ..core.events import EventBus, EventType, Event
from ..coordinates.engine import CoordinateEngine
from .pipeline import RenderingPipeline, DrawCommand, Layer


@dataclass
class CrosshairStyle:
    """Visual style for crosshair."""
    line_color: Color = field(default_factory=lambda: Color(150, 150, 150))
    line_width: float = 1.0
    line_dash: Tuple[int, ...] = (4, 4)
    label_bg_color: Color = field(default_factory=lambda: Color(42, 46, 57))
    label_text_color: Color = field(default_factory=lambda: Color(200, 200, 200))
    label_font: Tuple[str, int] = ("Segoe UI", 10)
    label_padding: float = 4.0
    price_label_width: float = 60.0
    time_label_height: float = 20.0
    show_price_label: bool = True
    show_time_label: bool = True
    highlight_color: Color = field(default_factory=lambda: Color(255, 255, 255))
    highlight_opacity: float = 0.1


class CrosshairRenderer:
    """Renders crosshair lines and labels following mouse position.

    Tracks mouse position, snaps to nearest bar, and renders:
    - Horizontal line with price label
    - Vertical line with time label
    - Highlighted bar background
    """

    def __init__(
        self,
        pipeline: RenderingPipeline,
        coord_engine: CoordinateEngine,
        style: Optional[CrosshairStyle] = None
    ) -> None:
        self._pipeline = pipeline
        self._coord = coord_engine
        self._style = style or CrosshairStyle()

        self._mouse_x: float = -1.0
        self._mouse_y: float = -1.0
        self._is_visible: bool = False
        self._snapped_index: int = -1
        self._snapped_bar: Optional[OHLCV] = None
        self._data: List[OHLCV] = []

    @property
    def is_visible(self) -> bool:
        return self._is_visible

    @property
    def snapped_index(self) -> int:
        return self._snapped_index

    @property
    def snapped_bar(self) -> Optional[OHLCV]:
        return self._snapped_bar

    def set_data(self, data: List[OHLCV]) -> None:
        """Set the data for snapping."""
        self._data = data

    def on_mouse_move(self, x: float, y: float) -> None:
        """Update crosshair position from mouse coordinates."""
        self._mouse_x = x
        self._mouse_y = y
        self._is_visible = True

        # Snap to nearest bar
        if self._data:
            snapped = self._coord.x_to_index(x)
            self._snapped_index = max(0, min(len(self._data) - 1, int(round(snapped))))
            self._snapped_bar = self._data[self._snapped_index]

        self._pipeline.schedule_layer(Layer.CROSSHAIR)

    def on_mouse_leave(self) -> None:
        """Hide crosshair when mouse leaves."""
        self._is_visible = False
        self._snapped_index = -1
        self._snapped_bar = None
        self._pipeline.schedule_layer(Layer.CROSSHAIR)

    def render(self) -> None:
        """Render crosshair."""
        if not self._is_visible:
            return

        commands = []
        vp = self._coord.viewport
        chart_vp = self._get_chart_viewport()

        # Check if mouse is in chart area
        if not chart_vp.contains(self._mouse_x, self._mouse_y):
            return

        # Snap x to bar center
        if self._snapped_index >= 0:
            snapped_x = self._coord.index_to_x(self._snapped_index)
        else:
            snapped_x = self._mouse_x

        # Horizontal line
        commands.append(DrawCommand(
            layer=Layer.CROSSHAIR,
            tag="crosshair_h",
            item_type="line",
            coords=(chart_vp.left, self._mouse_y, chart_vp.right, self._mouse_y),
            options={
                "fill": self._style.line_color.to_hex(),
                "width": self._style.line_width,
                "dash": self._style.line_dash,
            },
            z_index=0
        ))

        # Vertical line
        commands.append(DrawCommand(
            layer=Layer.CROSSHAIR,
            tag="crosshair_v",
            item_type="line",
            coords=(snapped_x, chart_vp.top, snapped_x, chart_vp.bottom),
            options={
                "fill": self._style.line_color.to_hex(),
                "width": self._style.line_width,
                "dash": self._style.line_dash,
            },
            z_index=0
        ))

        # Price label on right axis
        if self._style.show_price_label:
            price = self._coord.y_to_price(self._mouse_y)
            label_text = self._format_price(price)
            label_x = chart_vp.right + self._style.price_label_width / 2

            commands.append(DrawCommand(
                layer=Layer.CROSSHAIR,
                tag="price_label_bg",
                item_type="rectangle",
                coords=(
                    chart_vp.right,
                    self._mouse_y - self._style.time_label_height / 2,
                    vp.right,
                    self._mouse_y + self._style.time_label_height / 2
                ),
                options={
                    "fill": self._style.label_bg_color.to_hex(),
                    "outline": self._style.line_color.to_hex(),
                    "width": 1,
                },
                z_index=10
            ))

            commands.append(DrawCommand(
                layer=Layer.CROSSHAIR,
                tag="price_label_text",
                item_type="text",
                coords=(label_x, self._mouse_y),
                options={
                    "text": label_text,
                    "fill": self._style.label_text_color.to_hex(),
                    "font": self._style.label_font,
                    "anchor": "center",
                },
                z_index=11
            ))

        # Time label on bottom axis
        if self._style.show_time_label and self._snapped_bar:
            label_text = self._format_time(self._snapped_bar.timestamp)
            label_y = chart_vp.bottom + self._style.time_label_height / 2

            commands.append(DrawCommand(
                layer=Layer.CROSSHAIR,
                tag="time_label_bg",
                item_type="rectangle",
                coords=(
                    snapped_x - 40,
                    chart_vp.bottom,
                    snapped_x + 40,
                    vp.bottom
                ),
                options={
                    "fill": self._style.label_bg_color.to_hex(),
                    "outline": self._style.line_color.to_hex(),
                    "width": 1,
                },
                z_index=10
            ))

            commands.append(DrawCommand(
                layer=Layer.CROSSHAIR,
                tag="time_label_text",
                item_type="text",
                coords=(snapped_x, label_y),
                options={
                    "text": label_text,
                    "fill": self._style.label_text_color.to_hex(),
                    "font": self._style.label_font,
                    "anchor": "center",
                },
                z_index=11
            ))

        # Highlight bar background
        if self._snapped_index >= 0:
            bar_width = self._coord.get_bar_width()
            highlight = DrawCommand(
                layer=Layer.CROSSHAIR,
                tag="bar_highlight",
                item_type="rectangle",
                coords=(
                    snapped_x - bar_width / 2 - 2,
                    chart_vp.top,
                    snapped_x + bar_width / 2 + 2,
                    chart_vp.bottom
                ),
                options={
                    "fill": self._style.highlight_color.to_hex(),
                    "outline": "",
                    "stipple": "gray50",
                },
                z_index=-1
            )
            commands.append(highlight)

        self._pipeline.add_commands(commands)

    def _get_chart_viewport(self) -> Viewport:
        """Get chart area excluding axes."""
        vp = self._coord.viewport
        # These should match GridRenderer settings
        price_axis_width = 60.0
        time_axis_height = 25.0
        return Viewport(
            x=vp.x,
            y=vp.y,
            width=vp.width - price_axis_width,
            height=vp.height - time_axis_height
        )

    def _format_price(self, price: float) -> str:
        """Format price for label."""
        abs_price = abs(price)
        if abs_price >= 10000:
            return f"{price:,.0f}"
        elif abs_price >= 100:
            return f"{price:,.2f}"
        elif abs_price >= 1:
            return f"{price:,.4f}"
        elif abs_price >= 0.01:
            return f"{price:,.6f}"
        else:
            return f"{price:.8f}"

    def _format_time(self, timestamp: float) -> str:
        """Format timestamp for label."""
        from datetime import datetime
        dt = datetime.fromtimestamp(timestamp)
        return dt.strftime("%H:%M")
