"""Rendering Pipeline - Retained-mode rendering engine for Tkinter Canvas.

Design:
- Uses Tkinter Canvas tags for layer isolation
- Maintains a draw command buffer that syncs to canvas items
- Supports incremental updates (only redraw changed regions)
- Object pooling for canvas items to reduce allocation
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple, Any, Callable
from dataclasses import dataclass, field
from enum import Enum, auto
import tkinter as tk

from ..core.types import Viewport, Color, Point, Rect
from ..core.events import EventBus, EventType


class Layer(Enum):
    """Rendering layers, ordered from bottom to top."""
    BACKGROUND = auto()
    GRID = auto()
    SERIES = auto()
    INDICATORS = auto()
    DRAWING = auto()
    CROSSHAIR = auto()
    UI = auto()
    OVERLAY = auto()


@dataclass(slots=True)
class DrawCommand:
    """Abstract draw command."""
    layer: Layer
    tag: str
    item_type: str
    coords: Tuple[float, ...]
    options: Dict[str, Any] = field(default_factory=dict)
    z_index: int = 0


class CanvasItemPool:
    """Pool for reusable canvas items to reduce allocation overhead."""

    def __init__(self, canvas: tk.Canvas) -> None:
        self._canvas = canvas
        self._pools: Dict[str, List[int]] = {}
        self._in_use: Dict[int, str] = {}

    def acquire(self, item_type: str) -> int:
        """Acquire a canvas item of given type."""
        if item_type not in self._pools:
            self._pools[item_type] = []

        if self._pools[item_type]:
            item_id = self._pools[item_type].pop()
        else:
            item_id = self._create_item(item_type)

        self._in_use[item_id] = item_type
        return item_id

    def release(self, item_id: int) -> None:
        """Release a canvas item back to the pool."""
        if item_id not in self._in_use:
            return

        item_type = self._in_use.pop(item_id)
        self._canvas.itemconfig(item_id, state="hidden")

        if item_type not in self._pools:
            self._pools[item_type] = []
        self._pools[item_type].append(item_id)

    def release_all(self, item_ids: List[int]) -> None:
        """Release multiple items."""
        for item_id in item_ids:
            self.release(item_id)

    def _create_item(self, item_type: str) -> int:
        """Create a new canvas item."""
        if item_type == "line":
            return self._canvas.create_line(0, 0, 0, 0, state="hidden")
        elif item_type == "rectangle":
            return self._canvas.create_rectangle(0, 0, 0, 0, state="hidden")
        elif item_type == "oval":
            return self._canvas.create_oval(0, 0, 0, 0, state="hidden")
        elif item_type == "polygon":
            return self._canvas.create_polygon(0, 0, 0, 0, state="hidden")
        elif item_type == "text":
            return self._canvas.create_text(0, 0, text="", state="hidden")
        elif item_type == "arc":
            return self._canvas.create_arc(0, 0, 0, 0, state="hidden")
        else:
            return self._canvas.create_line(0, 0, 0, 0, state="hidden")


class LayerManager:
    """Manages rendering layers and z-ordering."""

    def __init__(self, canvas: tk.Canvas) -> None:
        self._canvas = canvas
        self._layer_tags: Dict[Layer, str] = {}
        self._layer_z_base: Dict[Layer, int] = {
            Layer.BACKGROUND: 100,
            Layer.GRID: 200,
            Layer.SERIES: 300,
            Layer.INDICATORS: 400,
            Layer.DRAWING: 500,
            Layer.CROSSHAIR: 600,
            Layer.UI: 700,
            Layer.OVERLAY: 800,
        }

        for layer in Layer:
            tag = f"layer_{layer.name.lower()}"
            self._layer_tags[layer] = tag

    def get_tag(self, layer: Layer) -> str:
        """Get the canvas tag for a layer."""
        return self._layer_tags[layer]

    def get_z_base(self, layer: Layer) -> int:
        """Get the base z-index for a layer."""
        return self._layer_z_base[layer]

    def clear_layer(self, layer: Layer) -> None:
        """Remove all items from a layer."""
        tag = self._layer_tags[layer]
        self._canvas.delete(tag)

    def clear_all(self) -> None:
        """Remove all items from all layers."""
        for layer in Layer:
            self.clear_layer(layer)


class RenderingPipeline:
    """Main rendering pipeline.

    Coordinates the rendering process:
    1. Collect draw commands from all renderers
    2. Batch and sort commands by layer and z-index
    3. Sync commands to canvas items
    4. Hide unused items (return to pool)
    """

    def __init__(self, canvas: tk.Canvas, event_bus: EventBus) -> None:
        self._canvas = canvas
        self._event_bus = event_bus
        self._layer_manager = LayerManager(canvas)
        self._item_pool = CanvasItemPool(canvas)

        # Current frame items by layer
        self._current_items: Dict[Layer, List[int]] = {layer: [] for layer in Layer}
        # Next frame items by layer
        self._next_items: Dict[Layer, List[int]] = {layer: [] for layer in Layer}

        self._command_buffer: List[DrawCommand] = []
        self._needs_full_redraw = True
        self._pending_layers: set[Layer] = set()

        self._render_scheduled = False

    @property
    def canvas(self) -> tk.Canvas:
        return self._canvas

    @property
    def layer_manager(self) -> LayerManager:
        return self._layer_manager

    def schedule_render(self, full_redraw: bool = False) -> None:
        """Schedule a render pass."""
        if full_redraw:
            self._needs_full_redraw = True

        if not self._render_scheduled:
            self._render_scheduled = True
            self._canvas.after_idle(self._render)

    def schedule_layer(self, layer: Layer) -> None:
        """Schedule a specific layer for redraw."""
        self._pending_layers.add(layer)
        self.schedule_render()

    def add_command(self, command: DrawCommand) -> None:
        """Add a draw command to the buffer."""
        self._command_buffer.append(command)

    def add_commands(self, commands: List[DrawCommand]) -> None:
        """Add multiple draw commands."""
        self._command_buffer.extend(commands)

    def clear_commands(self) -> None:
        """Clear the command buffer."""
        self._command_buffer.clear()

    def _render(self) -> None:
        """Execute the render pass."""
        self._render_scheduled = False

        if self._needs_full_redraw:
            self._full_render()
        else:
            self._incremental_render()

        self._event_bus.emit_new(EventType.RENDER_COMPLETE, self)

    def _full_render(self) -> None:
        """Full redraw of all layers."""
        # Sort commands by layer and z-index
        self._command_buffer.sort(key=lambda c: (c.layer.value, c.z_index))

        # Release all current items
        for layer in Layer:
            self._item_pool.release_all(self._current_items[layer])
            self._current_items[layer] = []

        # Execute commands
        for command in self._command_buffer:
            item_id = self._execute_command(command)
            if item_id is not None:
                self._current_items[command.layer].append(item_id)

        self._command_buffer.clear()
        self._needs_full_redraw = False
        self._pending_layers.clear()

    def _incremental_render(self) -> None:
        """Incremental render of pending layers."""
        # Sort commands for pending layers
        pending_commands = [
            c for c in self._command_buffer 
            if c.layer in self._pending_layers
        ]
        pending_commands.sort(key=lambda c: c.z_index)

        # Release items for pending layers
        for layer in self._pending_layers:
            self._item_pool.release_all(self._current_items[layer])
            self._current_items[layer] = []

        # Execute pending commands
        for command in pending_commands:
            item_id = self._execute_command(command)
            if item_id is not None:
                self._current_items[command.layer].append(item_id)

        # Remove executed commands from buffer
        self._command_buffer = [
            c for c in self._command_buffer 
            if c.layer not in self._pending_layers
        ]
        self._pending_layers.clear()

    def _execute_command(self, command: DrawCommand) -> Optional[int]:
        """Execute a single draw command and return item ID."""
        try:
            item_id = self._item_pool.acquire(command.item_type)

            # Configure the item
            options = dict(command.options)
            options["tags"] = self._layer_manager.get_tag(command.layer)
            options["state"] = "normal"

            if command.item_type == "line":
                self._canvas.coords(item_id, *command.coords)
                self._canvas.itemconfig(item_id, **options)
            elif command.item_type == "rectangle":
                self._canvas.coords(item_id, *command.coords)
                self._canvas.itemconfig(item_id, **options)
            elif command.item_type == "oval":
                self._canvas.coords(item_id, *command.coords)
                self._canvas.itemconfig(item_id, **options)
            elif command.item_type == "polygon":
                self._canvas.coords(item_id, *command.coords)
                self._canvas.itemconfig(item_id, **options)
            elif command.item_type == "text":
                x, y = command.coords[:2]
                self._canvas.coords(item_id, x, y)
                self._canvas.itemconfig(item_id, **options)

            return item_id
        except Exception:
            return None

    def force_full_redraw(self) -> None:
        """Force a complete redraw on next render."""
        self._needs_full_redraw = True
        self.schedule_render()
