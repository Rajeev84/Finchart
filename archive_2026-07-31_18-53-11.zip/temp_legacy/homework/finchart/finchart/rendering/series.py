"""Series Renderer - Renders OHLCV data as various chart types."""
from __future__ import annotations

from typing import List, Optional, Tuple
from dataclasses import dataclass, field
import tkinter as tk

from ..core.types import OHLCV, Color, ChartType
from ..core.events import EventBus
from ..coordinates.engine import CoordinateEngine
from .pipeline import RenderingPipeline, DrawCommand, Layer


@dataclass
class SeriesStyle:
    """Visual style for a series."""
    bullish_color: Color = field(default_factory=lambda: Color(38, 166, 154))  # TradingView green
    bearish_color: Color = field(default_factory=lambda: Color(239, 83, 80))   # TradingView red
    wick_color: Color = field(default_factory=lambda: Color(120, 123, 134))
    line_color: Color = field(default_factory=lambda: Color(33, 150, 243))
    area_color: Color = field(default_factory=lambda: Color(33, 150, 243))
    area_opacity: float = 0.1
    line_width: float = 1.5
    border_width: float = 1.0


class SeriesRenderer:
    """Renders OHLCV data series.

    Supports multiple chart types with efficient viewport rendering.
    Only renders bars visible in the current viewport.
    """

    def __init__(
        self,
        pipeline: RenderingPipeline,
        coord_engine: CoordinateEngine,
        style: Optional[SeriesStyle] = None
    ) -> None:
        self._pipeline = pipeline
        self._coord = coord_engine
        self._style = style or SeriesStyle()
        self._chart_type = ChartType.CANDLESTICK
        self._data: List[OHLCV] = []

    @property
    def chart_type(self) -> ChartType:
        return self._chart_type

    @chart_type.setter
    def chart_type(self, value: ChartType) -> None:
        self._chart_type = value

    def set_data(self, data: List[OHLCV]) -> None:
        """Set the data to render."""
        self._data = data

    def render(self) -> None:
        """Render the series based on chart type."""
        if not self._data:
            return

        vr = self._coord.visible_range
        start_idx = max(0, vr.start_index - 1)
        end_idx = min(len(self._data), vr.end_index + 1)

        if self._chart_type == ChartType.CANDLESTICK:
            self._render_candlesticks(start_idx, end_idx)
        elif self._chart_type == ChartType.LINE:
            self._render_line(start_idx, end_idx)
        elif self._chart_type == ChartType.AREA:
            self._render_area(start_idx, end_idx)
        elif self._chart_type == ChartType.HISTOGRAM:
            self._render_histogram(start_idx, end_idx)

    def _render_candlesticks(self, start_idx: int, end_idx: int) -> None:
        """Render candlestick bars."""
        commands = []
        bar_width = self._coord.get_bar_width()
        wick_width = self._coord.get_wick_width()

        for i in range(start_idx, end_idx):
            bar = self._data[i]
            x = self._coord.index_to_x(i)

            # Skip if outside viewport
            if x + bar_width < self._coord.viewport.left or x - bar_width > self._coord.viewport.right:
                continue

            y_high = self._coord.price_to_y(bar.high)
            y_low = self._coord.price_to_y(bar.low)
            y_open = self._coord.price_to_y(bar.open)
            y_close = self._coord.price_to_y(bar.close)

            body_top = min(y_open, y_close)
            body_bottom = max(y_open, y_close)

            is_bullish = bar.close >= bar.open
            color = self._style.bullish_color if is_bullish else self._style.bearish_color

            # Wick (line)
            commands.append(DrawCommand(
                layer=Layer.SERIES,
                tag=f"wick_{i}",
                item_type="line",
                coords=(x, y_high, x, y_low),
                options={
                    "fill": color.to_hex(),
                    "width": wick_width,
                },
                z_index=i
            ))

            # Body (rectangle)
            # Ensure minimum body height for visibility
            body_height = max(1.0, body_bottom - body_top)

            commands.append(DrawCommand(
                layer=Layer.SERIES,
                tag=f"body_{i}",
                item_type="rectangle",
                coords=(x - bar_width / 2, body_top, x + bar_width / 2, body_top + body_height),
                options={
                    "fill": color.to_hex(),
                    "outline": color.to_hex(),
                    "width": 0,
                },
                z_index=i
            ))

        self._pipeline.add_commands(commands)
        self._pipeline.schedule_layer(Layer.SERIES)

    def _render_line(self, start_idx: int, end_idx: int) -> None:
        """Render line chart."""
        if end_idx - start_idx < 2:
            return

        points = []
        for i in range(start_idx, end_idx):
            x = self._coord.index_to_x(i)
            y = self._coord.price_to_y(self._data[i].close)
            points.extend([x, y])

        if len(points) >= 4:
            self._pipeline.add_command(DrawCommand(
                layer=Layer.SERIES,
                tag="line_series",
                item_type="line",
                coords=tuple(points),
                options={
                    "fill": self._style.line_color.to_hex(),
                    "width": self._style.line_width,
                    "smooth": True,
                },
                z_index=0
            ))
            self._pipeline.schedule_layer(Layer.SERIES)

    def _render_area(self, start_idx: int, end_idx: int) -> None:
        """Render area chart."""
        if end_idx - start_idx < 2:
            return

        bottom_y = self._coord.viewport.bottom
        points = []

        for i in range(start_idx, end_idx):
            x = self._coord.index_to_x(i)
            y = self._coord.price_to_y(self._data[i].close)
            points.extend([x, y])

        # Close the polygon
        if len(points) >= 4:
            points.extend([points[-2], bottom_y, points[0], bottom_y])

            fill_color = self._style.area_color
            rgba = f"rgba({fill_color.r},{fill_color.g},{fill_color.b},{self._style.area_opacity})"

            self._pipeline.add_command(DrawCommand(
                layer=Layer.SERIES,
                tag="area_fill",
                item_type="polygon",
                coords=tuple(points),
                options={
                    "fill": rgba,
                    "outline": "",
                },
                z_index=0
            ))

            # Line on top
            line_points = points[:-4]
            self._pipeline.add_command(DrawCommand(
                layer=Layer.SERIES,
                tag="area_line",
                item_type="line",
                coords=tuple(line_points),
                options={
                    "fill": self._style.line_color.to_hex(),
                    "width": self._style.line_width,
                },
                z_index=1
            ))

            self._pipeline.schedule_layer(Layer.SERIES)

    def _render_histogram(self, start_idx: int, end_idx: int) -> None:
        """Render histogram bars (volume-style)."""
        commands = []
        bar_width = self._coord.get_bar_width()
        bottom_y = self._coord.viewport.bottom

        for i in range(start_idx, end_idx):
            bar = self._data[i]
            x = self._coord.index_to_x(i)

            if x + bar_width < self._coord.viewport.left or x - bar_width > self._coord.viewport.right:
                continue

            y = self._coord.price_to_y(bar.close)
            is_bullish = bar.close >= bar.open
            color = self._style.bullish_color if is_bullish else self._style.bearish_color

            commands.append(DrawCommand(
                layer=Layer.SERIES,
                tag=f"hist_{i}",
                item_type="rectangle",
                coords=(x - bar_width / 2, y, x + bar_width / 2, bottom_y),
                options={
                    "fill": color.to_hex(),
                    "outline": "",
                },
                z_index=i
            ))

        self._pipeline.add_commands(commands)
        self._pipeline.schedule_layer(Layer.SERIES)
