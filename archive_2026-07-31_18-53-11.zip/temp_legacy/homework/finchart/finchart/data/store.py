"""Data Store - Central data management with reactive updates."""
from __future__ import annotations

from typing import List, Optional, Callable, Dict, Any
from dataclasses import dataclass, field
import bisect

from ..core.types import OHLCV
from ..core.events import EventBus, EventType


class DataStore:
    """Immutable-append data store for OHLCV data.

    Design: Data is stored as a list of OHLCV tuples.
    New data is appended; historical data is immutable.
    This enables efficient binary search for visible ranges.
    """

    def __init__(self, event_bus: EventBus) -> None:
        self._data: List[OHLCV] = []
        self._event_bus = event_bus
        self._timestamp_index: Dict[float, int] = {}
        self._sorted_timestamps: List[float] = []

    @property
    def data(self) -> List[OHLCV]:
        """Return a copy of the data."""
        return self._data.copy()

    @property
    def count(self) -> int:
        return len(self._data)

    @property
    def is_empty(self) -> bool:
        return len(self._data) == 0

    def get(self, index: int) -> Optional[OHLCV]:
        """Get bar at index."""
        if 0 <= index < len(self._data):
            return self._data[index]
        return None

    def get_by_timestamp(self, timestamp: float) -> Optional[OHLCV]:
        """Get bar by exact timestamp."""
        idx = self._timestamp_index.get(timestamp)
        if idx is not None:
            return self._data[idx]
        return None

    def find_index(self, timestamp: float) -> int:
        """Find insertion index for timestamp using binary search."""
        return bisect.bisect_left(self._sorted_timestamps, timestamp)

    def find_range(self, start_time: float, end_time: float) -> tuple[int, int]:
        """Find index range for given time window."""
        start_idx = bisect.bisect_left(self._sorted_timestamps, start_time)
        end_idx = bisect.bisect_right(self._sorted_timestamps, end_time)
        return start_idx, end_idx

    def append(self, bar: OHLCV) -> None:
        """Append a new bar."""
        if self._data and bar.timestamp <= self._data[-1].timestamp:
            raise ValueError("New bar timestamp must be greater than last bar")

        self._data.append(bar)
        self._timestamp_index[bar.timestamp] = len(self._data) - 1
        self._sorted_timestamps.append(bar.timestamp)

        self._event_bus.emit_new(
            EventType.DATA_CHANGED,
            self,
            bar=bar,
            index=len(self._data) - 1
        )

    def update_last(self, bar: OHLCV) -> None:
        """Update the last bar (for real-time updates)."""
        if not self._data:
            self.append(bar)
            return

        if bar.timestamp != self._data[-1].timestamp:
            raise ValueError("Update timestamp must match last bar")

        self._data[-1] = bar
        self._event_bus.emit_new(
            EventType.DATA_CHANGED,
            self,
            bar=bar,
            index=len(self._data) - 1,
            is_update=True
        )

    def set_data(self, data: List[OHLCV]) -> None:
        """Replace all data."""
        self._data = list(data)
        self._timestamp_index = {bar.timestamp: i for i, bar in enumerate(data)}
        self._sorted_timestamps = [bar.timestamp for bar in data]

        self._event_bus.emit_new(
            EventType.DATA_CHANGED,
            self,
            count=len(data),
            is_full_replace=True
        )

    def get_price_range(self, start_idx: int, end_idx: int) -> tuple[float, float]:
        """Get min/max price for index range."""
        if start_idx < 0:
            start_idx = 0
        if end_idx > len(self._data):
            end_idx = len(self._data)

        if start_idx >= end_idx:
            return 0.0, 1.0

        bars = self._data[start_idx:end_idx]
        min_price = min(bar.low for bar in bars)
        max_price = max(bar.high for bar in bars)
        return min_price, max_price

    def get_volume_range(self, start_idx: int, end_idx: int) -> tuple[float, float]:
        """Get min/max volume for index range."""
        if start_idx < 0:
            start_idx = 0
        if end_idx > len(self._data):
            end_idx = len(self._data)

        if start_idx >= end_idx:
            return 0.0, 1.0

        bars = self._data[start_idx:end_idx]
        volumes = [bar.volume for bar in bars if bar.volume > 0]
        if not volumes:
            return 0.0, 1.0
        return min(volumes), max(volumes)
