"""OHLC data structures and time series management."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Iterator
from datetime import datetime
import bisect


@dataclass(frozen=True, slots=True)
class OHLC:
    """Immutable single candlestick data point."""
    time: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0

    @property
    def body_top(self) -> float:
        return max(self.open, self.close)

    @property
    def body_bottom(self) -> float:
        return min(self.open, self.close)

    @property
    def is_bullish(self) -> bool:
        return self.close >= self.open

    @property
    def range(self) -> float:
        return self.high - self.low

    @property
    def body_range(self) -> float:
        return abs(self.close - self.open)


@dataclass
class TimeSeries:
    """Ordered time series of OHLC data with efficient range queries."""
    _data: List[OHLC] = field(default_factory=list)

    def append(self, bar: OHLC) -> None:
        """Append a bar, maintaining chronological order."""
        if self._data and bar.time < self._data[-1].time:
            raise ValueError("Bar time must be >= last bar time")
        self._data.append(bar)

    def extend(self, bars: List[OHLC]) -> None:
        """Extend with multiple bars."""
        for bar in bars:
            self.append(bar)

    def __len__(self) -> int:
        return len(self._data)

    def __getitem__(self, idx: int) -> OHLC:
        return self._data[idx]

    def __iter__(self) -> Iterator[OHLC]:
        return iter(self._data)

    @property
    def first_time(self) -> Optional[datetime]:
        return self._data[0].time if self._data else None

    @property
    def last_time(self) -> Optional[datetime]:
        return self._data[-1].time if self._data else None

    def find_index(self, time: datetime) -> int:
        """Find insertion index for a given time (binary search)."""
        times = [bar.time for bar in self._data]
        return bisect.bisect_left(times, time)

    def visible_range(self, start_time: datetime, end_time: datetime) -> Tuple[int, int]:
        """Return [start_idx, end_idx) of bars within time range."""
        start = max(0, bisect.bisect_left([b.time for b in self._data], start_time) - 1)
        end = min(len(self._data), bisect.bisect_right([b.time for b in self._data], end_time) + 1)
        return start, end

    def slice(self, start_idx: int, end_idx: int) -> List[OHLC]:
        """Return a slice of bars."""
        return self._data[start_idx:end_idx]

    def price_range(self, start_idx: int, end_idx: int) -> Tuple[float, float]:
        """Get min/max price for a range of bars."""
        slice_data = self._data[start_idx:end_idx]
        if not slice_data:
            return 0.0, 100.0
        low = min(b.low for b in slice_data)
        high = max(b.high for b in slice_data)
        return low, high

    def clear(self) -> None:
        """Clear all data."""
        self._data.clear()
