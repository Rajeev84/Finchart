"""Drawing tools."""
