"""Coordinate Engine - Maps between data and pixel coordinates."""
from __future__ import annotations

from typing import Optional, Tuple, List
from dataclasses import dataclass, field
import math

from ..core.types import OHLCV, Viewport, VisibleRange, Point
from ..core.events import EventBus, EventType


@dataclass(slots=True)
class TimeScale:
    """Time scale configuration and state."""
    bar_spacing: float = 8.0  # pixels between bar centers
    offset: float = 0.0  # pixel offset for panning
    min_bar_spacing: float = 1.0
    max_bar_spacing: float = 200.0

    def copy(self) -> TimeScale:
        return TimeScale(
            bar_spacing=self.bar_spacing,
            offset=self.offset,
            min_bar_spacing=self.min_bar_spacing,
            max_bar_spacing=self.max_bar_spacing
        )


@dataclass(slots=True)
class PriceScale:
    """Price scale configuration and state."""
    min_price: float = 0.0
    max_price: float = 1.0
    top_padding: float = 0.1  # 10% padding
    bottom_padding: float = 0.1
    is_log: bool = False
    is_auto: bool = True

    @property
    def range(self) -> float:
        return self.max_price - self.min_price

    def copy(self) -> PriceScale:
        return PriceScale(
            min_price=self.min_price,
            max_price=self.max_price,
            top_padding=self.top_padding,
            bottom_padding=self.bottom_padding,
            is_log=self.is_log,
            is_auto=self.is_auto
        )


class CoordinateEngine:
    """Transforms between data coordinates and pixel coordinates.

    Separates time and price transformations for independent control.
    Caches computed values to avoid redundant calculations.
    """

    def __init__(self, event_bus: EventBus) -> None:
        self._event_bus = event_bus
        self._time_scale = TimeScale()
        self._price_scale = PriceScale()
        self._viewport = Viewport()
        self._visible_range = VisibleRange()

        # Cache
        self._cached_bar_width: float = 0.0
        self._cached_price_per_pixel: float = 0.0
        self._cached_pixel_per_price: float = 0.0
        self._cache_valid = False

    @property
    def time_scale(self) -> TimeScale:
        return self._time_scale

    @property
    def price_scale(self) -> PriceScale:
        return self._price_scale

    @property
    def viewport(self) -> Viewport:
        return self._viewport

    @property
    def visible_range(self) -> VisibleRange:
        return self._visible_range

    def set_viewport(self, viewport: Viewport) -> None:
        """Set the viewport dimensions."""
        self._viewport = viewport
        self._invalidate_cache()

    def set_visible_range(self, start_idx: int, end_idx: int, total_bars: int) -> None:
        """Set the visible data range."""
        self._visible_range.start_index = max(0, start_idx)
        self._visible_range.end_index = min(total_bars, end_idx)
        self._visible_range.bar_count = total_bars
        self._invalidate_cache()

    def set_price_range(self, min_price: float, max_price: float) -> None:
        """Set the price range with padding."""
        range_val = max_price - min_price
        if range_val <= 0:
            range_val = 1.0

        padding = range_val * (self._price_scale.top_padding + self._price_scale.bottom_padding)
        self._price_scale.min_price = min_price - range_val * self._price_scale.bottom_padding
        self._price_scale.max_price = max_price + range_val * self._price_scale.top_padding
        self._invalidate_cache()

        self._event_bus.emit_new(
            EventType.SCALE_CHANGED,
            self,
            min_price=self._price_scale.min_price,
            max_price=self._price_scale.max_price
        )

    def index_to_x(self, index: int) -> float:
        """Convert bar index to x pixel coordinate."""
        return self._viewport.left + self._time_scale.offset + index * self._time_scale.bar_spacing

    def x_to_index(self, x: float) -> float:
        """Convert x pixel coordinate to bar index (float for sub-bar precision)."""
        if self._time_scale.bar_spacing == 0:
            return 0.0
        return (x - self._viewport.left - self._time_scale.offset) / self._time_scale.bar_spacing

    def price_to_y(self, price: float) -> float:
        """Convert price to y pixel coordinate."""
        self._ensure_cache()
        if self._price_scale.is_log and price > 0 and self._price_scale.min_price > 0:
            log_min = math.log10(self._price_scale.min_price)
            log_max = math.log10(self._price_scale.max_price)
            log_price = math.log10(price)
            ratio = (log_price - log_min) / (log_max - log_min)
        else:
            ratio = (price - self._price_scale.min_price) / self._price_scale.range

        return self._viewport.bottom - ratio * self._viewport.height

    def y_to_price(self, y: float) -> float:
        """Convert y pixel coordinate to price."""
        self._ensure_cache()
        ratio = (self._viewport.bottom - y) / self._viewport.height

        if self._price_scale.is_log and self._price_scale.min_price > 0:
            log_min = math.log10(self._price_scale.min_price)
            log_max = math.log10(self._price_scale.max_price)
            log_price = log_min + ratio * (log_max - log_min)
            return 10 ** log_price
        else:
            return self._price_scale.min_price + ratio * self._price_scale.range

    def bar_to_rect(self, index: int, bar: OHLCV) -> Tuple[float, float, float, float]:
        """Get pixel rectangle for a bar (x, y_top, y_bottom, width)."""
        x = self.index_to_x(index)
        y_high = self.price_to_y(bar.high)
        y_low = self.price_to_y(bar.low)
        y_open = self.price_to_y(bar.open)
        y_close = self.price_to_y(bar.close)

        body_top = min(y_open, y_close)
        body_bottom = max(y_open, y_close)

        bar_width = self._time_scale.bar_spacing * 0.8
        bar_x = x - bar_width / 2

        return bar_x, body_top, body_bottom, bar_width

    def get_bar_width(self) -> float:
        """Get the current bar width in pixels."""
        return self._time_scale.bar_spacing * 0.8

    def get_wick_width(self) -> float:
        """Get the wick line width."""
        return max(1.0, self._time_scale.bar_spacing * 0.1)

    def zoom(self, factor: float, anchor_x: Optional[float] = None) -> None:
        """Zoom time scale by factor around anchor point."""
        old_spacing = self._time_scale.bar_spacing
        new_spacing = max(
            self._time_scale.min_bar_spacing,
            min(self._time_scale.max_bar_spacing, old_spacing * factor)
        )

        if anchor_x is not None:
            # Zoom around anchor point
            anchor_index = self.x_to_index(anchor_x)
            self._time_scale.offset = anchor_x - self._viewport.left - anchor_index * new_spacing

        self._time_scale.bar_spacing = new_spacing
        self._invalidate_cache()

        self._event_bus.emit_new(
            EventType.SCALE_CHANGED,
            self,
            bar_spacing=new_spacing
        )

    def pan(self, delta_x: float) -> None:
        """Pan the view by delta pixels."""
        self._time_scale.offset += delta_x
        self._invalidate_cache()

        self._event_bus.emit_new(
            EventType.SCALE_CHANGED,
            self,
            offset=self._time_scale.offset
        )

    def fit_range(self, start_idx: int, end_idx: int) -> None:
        """Fit visible range to show bars from start_idx to end_idx."""
        count = end_idx - start_idx
        if count <= 0:
            return

        self._time_scale.bar_spacing = self._viewport.width / count
        self._time_scale.offset = -start_idx * self._time_scale.bar_spacing
        self._invalidate_cache()

    def _invalidate_cache(self) -> None:
        """Invalidate coordinate cache."""
        self._cache_valid = False

    def _ensure_cache(self) -> None:
        """Ensure coordinate cache is valid."""
        if self._cache_valid:
            return

        self._cached_bar_width = self._time_scale.bar_spacing * 0.8

        price_range = self._price_scale.range
        if price_range > 0 and self._viewport.height > 0:
            self._cached_price_per_pixel = price_range / self._viewport.height
            self._cached_pixel_per_price = self._viewport.height / price_range
        else:
            self._cached_price_per_pixel = 1.0
            self._cached_pixel_per_price = 1.0

        self._cache_valid = True
