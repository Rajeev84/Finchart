"""FinChart - Professional pure-Python financial charting library."""
from .chart.widget import ChartWidget
from .core.types import OHLCV, ChartType, Color
from .indicators.base import Indicator, IndicatorResult

__version__ = "0.1.0"
__all__ = [
    "ChartWidget",
    "OHLCV",
    "ChartType",
    "Color",
    "Indicator",
    "IndicatorResult",
]
