"""Chart components."""
