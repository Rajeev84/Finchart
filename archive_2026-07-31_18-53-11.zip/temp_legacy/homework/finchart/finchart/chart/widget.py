"""Chart Widget - Main Tkinter-based financial chart widget.

This is the primary public API. It orchestrates all subsystems:
- Data Store
- Coordinate Engine
- Rendering Pipeline
- Series Renderer
- Grid Renderer
- Crosshair Renderer
- Interaction handling
- Indicator rendering
"""
from __future__ import annotations

from typing import List, Optional, Callable, Any
import tkinter as tk
from tkinter import ttk

from ..core.types import OHLCV, Viewport, ChartType, Color
from ..core.events import EventBus, EventType, Event
from ..data.store import DataStore
from ..coordinates.engine import CoordinateEngine
from ..rendering.pipeline import RenderingPipeline, Layer
from ..rendering.series import SeriesRenderer, SeriesStyle
from ..rendering.grid import GridRenderer, GridStyle
from ..rendering.crosshair import CrosshairRenderer, CrosshairStyle
from ..indicators.base import Indicator


class ChartWidget(tk.Frame):
    """Professional financial chart widget.

    Usage:
        chart = ChartWidget(parent)
        chart.pack(fill="both", expand=True)
        chart.set_data(data)
        chart.add_indicator(SMA(period=20))
    """

    def __init__(
        self,
        parent: tk.Widget,
        width: int = 800,
        height: int = 600,
        **kwargs
    ) -> None:
        super().__init__(parent, **kwargs)

        # Store explicit dimensions for viewport initialization
        self._explicit_width = width
        self._explicit_height = height

        # Core subsystems
        self._event_bus = EventBus()
        self._data_store = DataStore(self._event_bus)
        self._coord_engine = CoordinateEngine(self._event_bus)

        # Canvas setup
        self._canvas = tk.Canvas(
            self,
            width=width,
            height=height,
            bg="#131722",  # TradingView dark background
            highlightthickness=0,
            borderwidth=0,
        )
        self._canvas.pack(fill="both", expand=True)

        # Rendering pipeline
        self._pipeline = RenderingPipeline(self._canvas, self._event_bus)

        # Renderers
        self._series_renderer = SeriesRenderer(
            self._pipeline,
            self._coord_engine,
            SeriesStyle()
        )
        self._grid_renderer = GridRenderer(
            self._pipeline,
            self._coord_engine,
            GridStyle()
        )
        self._crosshair_renderer = CrosshairRenderer(
            self._pipeline,
            self._coord_engine,
            CrosshairStyle()
        )

        # Indicators
        self._indicators: List[Indicator] = []

        # Interaction state
        self._is_dragging = False
        self._drag_start_x = 0.0
        self._drag_start_offset = 0.0
        self._is_zooming = False

        # Configuration
        self._auto_scale = True
        self._right_offset_bars = 5  # Empty space on right

        # Bind events
        self._bind_events()

        # Subscribe to data changes
        self._event_bus.subscribe(EventType.DATA_CHANGED, self._on_data_changed)
        self._event_bus.subscribe(EventType.SCALE_CHANGED, self._on_scale_changed)

        # Initial layout
        self._update_viewport()

        # Background
        self._draw_background()

    # ========== Public API ==========

    def set_data(self, data: List[OHLCV]) -> None:
        """Set the chart data."""
        self._data_store.set_data(data)
        self._series_renderer.set_data(data)
        self._crosshair_renderer.set_data(data)
        self._update_indicators()
        # Defer auto-fit to after the widget is mapped and event loop is running
        self.after_idle(self._auto_fit)

    def append(self, bar: OHLCV) -> None:
        """Append a new bar."""
        self._data_store.append(bar)
        self._series_renderer.set_data(self._data_store.data)
        self._crosshair_renderer.set_data(self._data_store.data)
        self._update_indicators()

        # Auto-scroll if at right edge
        vr = self._coord_engine.visible_range
        if vr.end_index >= self._data_store.count - 2:
            self._auto_fit()

    def update_last(self, bar: OHLCV) -> None:
        """Update the last bar (real-time updates)."""
        self._data_store.update_last(bar)
        self._series_renderer.set_data(self._data_store.data)
        self._crosshair_renderer.set_data(self._data_store.data)
        self._update_indicators()
        self._update_price_scale()
        self._request_render()

    def add_indicator(self, indicator: Indicator) -> None:
        """Add a technical indicator to the chart."""
        self._indicators.append(indicator)
        if not self._data_store.is_empty:
            indicator.update(self._data_store.data)
        self._pipeline.force_full_redraw()
        self._request_render()

    def remove_indicator(self, indicator: Indicator) -> None:
        """Remove an indicator from the chart."""
        if indicator in self._indicators:
            self._indicators.remove(indicator)
            self._pipeline.force_full_redraw()
            self._request_render()

    def clear_indicators(self) -> None:
        """Remove all indicators."""
        self._indicators.clear()
        self._pipeline.force_full_redraw()
        self._request_render()

    def set_chart_type(self, chart_type: ChartType) -> None:
        """Change the chart type."""
        self._series_renderer.chart_type = chart_type
        self._pipeline.force_full_redraw()
        self._request_render()

    def fit_range(self) -> None:
        """Fit all data into view."""
        self._auto_fit()

    def set_theme(self, background: str = "#131722", grid: str = "#2a2e39") -> None:
        """Set chart theme colors."""
        self._canvas.configure(bg=background)
        self._grid_renderer.style.grid_color = Color.from_hex(grid)
        self._pipeline.force_full_redraw()
        self._request_render()

    @property
    def canvas(self) -> tk.Canvas:
        """Access the underlying canvas."""
        return self._canvas

    @property
    def event_bus(self) -> EventBus:
        """Access the event bus for custom extensions."""
        return self._event_bus

    @property
    def data_store(self) -> DataStore:
        """Access the data store."""
        return self._data_store

    # ========== Private Methods ==========

    def _bind_events(self) -> None:
        """Bind mouse and keyboard events."""
        self._canvas.bind("<Button-1>", self._on_mouse_down)
        self._canvas.bind("<B1-Motion>", self._on_mouse_drag)
        self._canvas.bind("<ButtonRelease-1>", self._on_mouse_up)
        self._canvas.bind("<Motion>", self._on_mouse_move)
        self._canvas.bind("<Leave>", self._on_mouse_leave)
        self._canvas.bind("<MouseWheel>", self._on_mouse_wheel)
        self._canvas.bind("<Button-4>", self._on_mouse_wheel)  # Linux scroll up
        self._canvas.bind("<Button-5>", self._on_mouse_wheel)  # Linux scroll down
        self.bind("<Configure>", self._on_resize)

        # Keyboard shortcuts
        self._canvas.bind("<plus>", lambda e: self._zoom_at(1.2, self._canvas.winfo_width() / 2))
        self._canvas.bind("<minus>", lambda e: self._zoom_at(0.8, self._canvas.winfo_width() / 2))
        self._canvas.bind("<Home>", lambda e: self._auto_fit())
        self._canvas.bind("<r>", lambda e: self._auto_fit())

    def _on_mouse_down(self, event: tk.Event) -> None:
        """Handle mouse button press."""
        self._is_dragging = True
        self._drag_start_x = event.x
        self._drag_start_offset = self._coord_engine.time_scale.offset
        self._canvas.configure(cursor="fleur")

    def _on_mouse_drag(self, event: tk.Event) -> None:
        """Handle mouse drag (pan)."""
        if not self._is_dragging:
            return

        delta_x = event.x - self._drag_start_x
        self._coord_engine.time_scale.offset = self._drag_start_offset + delta_x
        self._update_visible_range()
        self._request_render()

    def _on_mouse_up(self, event: tk.Event) -> None:
        """Handle mouse button release."""
        self._is_dragging = False
        self._canvas.configure(cursor="")

    def _on_mouse_move(self, event: tk.Event) -> None:
        """Handle mouse move (crosshair)."""
        if self._is_dragging:
            return

        self._crosshair_renderer.on_mouse_move(event.x, event.y)
        self._request_render()

    def _on_mouse_leave(self, event: tk.Event) -> None:
        """Handle mouse leaving canvas."""
        self._crosshair_renderer.on_mouse_leave()
        self._request_render()

    def _on_mouse_wheel(self, event: tk.Event) -> None:
        """Handle mouse wheel (zoom)."""
        # Determine scroll direction
        if event.num == 4 or event.delta > 0:
            factor = 1.15
        elif event.num == 5 or event.delta < 0:
            factor = 0.85
        else:
            return

        x = event.x
        self._zoom_at(factor, x)

    def _zoom_at(self, factor: float, anchor_x: float) -> None:
        """Zoom around a specific x coordinate."""
        self._coord_engine.zoom(factor, anchor_x)
        self._update_visible_range()
        self._update_price_scale()
        self._request_render()

    def _on_resize(self, event: tk.Event) -> None:
        """Handle widget resize."""
        self._update_viewport()
        self._auto_fit()

    def _on_data_changed(self, event: Event) -> None:
        """Handle data changes."""
        self._update_visible_range()
        self._request_render()

    def _on_scale_changed(self, event: Event) -> None:
        """Handle scale changes."""
        self._update_visible_range()
        self._request_render()

    def _update_viewport(self) -> None:
        """Update viewport from canvas dimensions."""
        width = self._canvas.winfo_width()
        height = self._canvas.winfo_height()

        # Fall back to explicit dimensions if canvas not yet mapped
        if width <= 1:
            width = self._explicit_width
        if height <= 1:
            height = self._explicit_height

        if width <= 1 or height <= 1:
            return

        self._coord_engine.set_viewport(Viewport(
            x=0,
            y=0,
            width=width,
            height=height
        ))

        # Auto-fit data when viewport becomes valid
        if not self._data_store.is_empty:
            self._auto_fit()

    def _update_visible_range(self) -> None:
        """Calculate visible bar range based on viewport and time scale."""
        if self._data_store.is_empty:
            return

        vp = self._coord_engine.viewport
        ts = self._coord_engine.time_scale

        first_visible = self._coord_engine.x_to_index(vp.left)
        last_visible = self._coord_engine.x_to_index(vp.right)

        start_idx = max(0, int(first_visible) - 1)
        end_idx = min(self._data_store.count, int(last_visible) + 2)

        self._coord_engine.set_visible_range(
            start_idx,
            end_idx,
            self._data_store.count
        )

    def _update_price_scale(self) -> None:
        """Update price scale based on visible data."""
        if not self._auto_scale or self._data_store.is_empty:
            return

        vr = self._coord_engine.visible_range
        min_price, max_price = self._data_store.get_price_range(
            vr.start_index,
            vr.end_index
        )

        # Include indicator values in price range
        for indicator in self._indicators:
            if indicator._last_result:
                for i in range(vr.start_index, min(vr.end_index, len(indicator._last_result.values))):
                    val = indicator._last_result.values[i]
                    if val is not None:
                        min_price = min(min_price, val)
                        max_price = max(max_price, val)

        if min_price < max_price:
            self._coord_engine.set_price_range(min_price, max_price)

    def _update_indicators(self) -> None:
        """Update all indicators with current data."""
        if self._data_store.is_empty:
            return
        data = self._data_store.data
        for indicator in self._indicators:
            indicator.update(data)

    def _auto_fit(self) -> None:
        """Fit all data into the viewport."""
        if self._data_store.is_empty:
            return

        count = self._data_store.count
        vp = self._coord_engine.viewport

        if vp.width <= 0:
            return

        total_bars = count + self._right_offset_bars
        bar_spacing = vp.width / total_bars

        self._coord_engine.time_scale.bar_spacing = bar_spacing
        self._coord_engine.time_scale.offset = 0

        self._update_visible_range()
        self._update_price_scale()
        self._pipeline.force_full_redraw()
        self._request_render()

    def _draw_background(self) -> None:
        """Draw the chart background."""
        pass

    def _render_indicators(self) -> None:
        """Render all indicators."""
        vr = self._coord_engine.visible_range
        for indicator in self._indicators:
            commands = indicator.render_commands(
                self._coord_engine,
                vr.start_index,
                vr.end_index
            )
            self._pipeline.add_commands(commands)
        self._pipeline.schedule_layer(Layer.INDICATORS)

    def _request_render(self) -> None:
        """Request a render pass."""
        self._series_renderer.render()
        self._grid_renderer.render(self._data_store.count)
        self._crosshair_renderer.render()
        self._render_indicators()
        self._pipeline.schedule_render()
