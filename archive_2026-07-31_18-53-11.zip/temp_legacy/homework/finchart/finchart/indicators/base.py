"""Indicator Framework - Extensible technical indicator system.

Design:
- Indicators are self-contained computation units
- They receive OHLCV data and return computed values
- The chart engine renders indicator outputs without knowing internals
- New indicators can be added without modifying core engine
"""
from __future__ import annotations

from typing import List, Optional, Dict, Any, Tuple
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
import math

from ..core.types import OHLCV, Color
from ..rendering.pipeline import DrawCommand, Layer


@dataclass
class IndicatorResult:
    """Result from an indicator computation."""
    values: List[Optional[float]]  # One value per input bar
    colors: List[Optional[Color]] = field(default_factory=list)
    labels: List[str] = field(default_factory=list)

    def __post_init__(self):
        if not self.colors:
            self.colors = [None] * len(self.values)


@dataclass
class IndicatorStyle:
    """Visual style for rendering an indicator."""
    line_color: Color = field(default_factory=lambda: Color(33, 150, 243))
    line_width: float = 1.5
    fill_color: Optional[Color] = None
    fill_opacity: float = 0.1
    show_labels: bool = False
    label_font: Tuple[str, int] = ("Segoe UI", 9)
    plot_type: str = "line"  # line, histogram, area, dots


class Indicator(ABC):
    """Base class for all technical indicators.

    Subclasses must implement:
    - name: str property
    - calculate(data: List[OHLCV]) -> IndicatorResult

    Optional overrides:
    - style: IndicatorStyle
    - render_commands(result, coord_engine) -> List[DrawCommand]
    """

    def __init__(self, style: Optional[IndicatorStyle] = None) -> None:
        self._style = style or IndicatorStyle()
        self._last_result: Optional[IndicatorResult] = None

    @property
    @abstractmethod
    def name(self) -> str:
        """Indicator name."""
        pass

    @property
    def style(self) -> IndicatorStyle:
        return self._style

    @abstractmethod
    def calculate(self, data: List[OHLCV]) -> IndicatorResult:
        """Calculate indicator values from OHLCV data.

        Returns an IndicatorResult with one value per input bar.
        Use None for bars where the indicator is not yet computed.
        """
        pass

    def update(self, data: List[OHLCV]) -> IndicatorResult:
        """Update indicator with new data and cache result."""
        self._last_result = self.calculate(data)
        return self._last_result

    def render_commands(
        self,
        coord_engine: Any,
        start_idx: int,
        end_idx: int
    ) -> List[DrawCommand]:
        """Generate draw commands for the indicator.

        Default implementation renders as a line.
        Override for custom rendering (histogram, bands, etc.)
        """
        if self._last_result is None:
            return []

        commands = []
        values = self._last_result.values

        if self._style.plot_type == "line":
            commands = self._render_line(values, coord_engine, start_idx, end_idx)
        elif self._style.plot_type == "histogram":
            commands = self._render_histogram(values, coord_engine, start_idx, end_idx)
        elif self._style.plot_type == "area":
            commands = self._render_area(values, coord_engine, start_idx, end_idx)

        return commands

    def _render_line(
        self,
        values: List[Optional[float]],
        coord_engine: Any,
        start_idx: int,
        end_idx: int
    ) -> List[DrawCommand]:
        """Render indicator as a line."""
        commands = []
        points = []

        for i in range(start_idx, min(end_idx, len(values))):
            val = values[i]
            if val is None:
                if len(points) >= 4:
                    commands.append(DrawCommand(
                        layer=Layer.INDICATORS,
                        tag=f"{self.name}_line",
                        item_type="line",
                        coords=tuple(points),
                        options={
                            "fill": self._style.line_color.to_hex(),
                            "width": self._style.line_width,
                            "smooth": True,
                        },
                        z_index=0
                    ))
                points = []
                continue

            x = coord_engine.index_to_x(i)
            y = coord_engine.price_to_y(val)
            points.extend([x, y])

        if len(points) >= 4:
            commands.append(DrawCommand(
                layer=Layer.INDICATORS,
                tag=f"{self.name}_line",
                item_type="line",
                coords=tuple(points),
                options={
                    "fill": self._style.line_color.to_hex(),
                    "width": self._style.line_width,
                    "smooth": True,
                },
                z_index=0
            ))

        return commands

    def _render_histogram(
        self,
        values: List[Optional[float]],
        coord_engine: Any,
        start_idx: int,
        end_idx: int
    ) -> List[DrawCommand]:
        """Render indicator as histogram bars."""
        commands = []
        bar_width = coord_engine.get_bar_width() * 0.5
        zero_y = coord_engine.price_to_y(0)

        for i in range(start_idx, min(end_idx, len(values))):
            val = values[i]
            if val is None:
                continue

            x = coord_engine.index_to_x(i)
            y = coord_engine.price_to_y(val)

            color = self._style.line_color
            if val < 0 and self._last_result.colors and self._last_result.colors[i]:
                color = self._last_result.colors[i]

            commands.append(DrawCommand(
                layer=Layer.INDICATORS,
                tag=f"{self.name}_hist_{i}",
                item_type="rectangle",
                coords=(x - bar_width / 2, min(y, zero_y), x + bar_width / 2, max(y, zero_y)),
                options={
                    "fill": color.to_hex(),
                    "outline": "",
                },
                z_index=i
            ))

        return commands

    def _render_area(
        self,
        values: List[Optional[float]],
        coord_engine: Any,
        start_idx: int,
        end_idx: int
    ) -> List[DrawCommand]:
        """Render indicator as filled area."""
        commands = []
        points = []

        for i in range(start_idx, min(end_idx, len(values))):
            val = values[i]
            if val is None:
                continue
            x = coord_engine.index_to_x(i)
            y = coord_engine.price_to_y(val)
            points.extend([x, y])

        if len(points) >= 4:
            bottom_y = coord_engine.viewport.bottom
            points.extend([points[-2], bottom_y, points[0], bottom_y])

            fill_color = self._style.line_color
            rgba = f"rgba({fill_color.r},{fill_color.g},{fill_color.b},{self._style.fill_opacity})"

            commands.append(DrawCommand(
                layer=Layer.INDICATORS,
                tag=f"{self.name}_area",
                item_type="polygon",
                coords=tuple(points),
                options={
                    "fill": rgba,
                    "outline": "",
                },
                z_index=0
            ))

        return commands
