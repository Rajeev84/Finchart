"""Volatility Indicators."""
from typing import List, Optional
import math

from ..core.types import OHLCV, Color
from ..rendering.pipeline import DrawCommand, Layer
from .base import Indicator, IndicatorResult, IndicatorStyle


class BollingerBands(Indicator):
    """Bollinger Bands (upper, middle, lower)."""

    def __init__(
        self,
        period: int = 20,
        std_dev: float = 2.0,
        style: Optional[IndicatorStyle] = None
    ) -> None:
        super().__init__(style or IndicatorStyle(
            line_color=Color(255, 152, 0),
            line_width=1.0,
            fill_color=Color(255, 152, 0),
            fill_opacity=0.05
        ))
        self._period = period
        self._std_dev = std_dev
        self._upper_values: List[Optional[float]] = []
        self._lower_values: List[Optional[float]] = []

    @property
    def name(self) -> str:
        return f"BB({self._period},{self._std_dev})"

    def calculate(self, data: List[OHLCV]) -> IndicatorResult:
        middle: List[Optional[float]] = []
        self._upper_values = []
        self._lower_values = []

        for i in range(len(data)):
            if i < self._period - 1:
                middle.append(None)
                self._upper_values.append(None)
                self._lower_values.append(None)
                continue

            # SMA
            total = sum(data[i - j].close for j in range(self._period))
            sma = total / self._period

            # Standard deviation
            variance = sum((data[i - j].close - sma) ** 2 for j in range(self._period)) / self._period
            std = math.sqrt(variance)

            middle.append(sma)
            self._upper_values.append(sma + self._std_dev * std)
            self._lower_values.append(sma - self._std_dev * std)

        return IndicatorResult(values=middle)

    def render_commands(self, coord_engine, start_idx, end_idx):
        """Render all three bands."""
        commands = []

        # Upper band
        upper_points = []
        for i in range(start_idx, min(end_idx, len(self._upper_values))):
            val = self._upper_values[i]
            if val is not None:
                x = coord_engine.index_to_x(i)
                y = coord_engine.price_to_y(val)
                upper_points.extend([x, y])

        if len(upper_points) >= 4:
            commands.append(DrawCommand(
                layer=Layer.INDICATORS,
                tag=f"{self.name}_upper",
                item_type="line",
                coords=tuple(upper_points),
                options={
                    "fill": self._style.line_color.to_hex(),
                    "width": self._style.line_width,
                    "smooth": True,
                },
                z_index=0
            ))

        # Lower band
        lower_points = []
        for i in range(start_idx, min(end_idx, len(self._lower_values))):
            val = self._lower_values[i]
            if val is not None:
                x = coord_engine.index_to_x(i)
                y = coord_engine.price_to_y(val)
                lower_points.extend([x, y])

        if len(lower_points) >= 4:
            commands.append(DrawCommand(
                layer=Layer.INDICATORS,
                tag=f"{self.name}_lower",
                item_type="line",
                coords=tuple(lower_points),
                options={
                    "fill": self._style.line_color.to_hex(),
                    "width": self._style.line_width,
                    "smooth": True,
                },
                z_index=0
            ))

        # Middle band
        middle_points = []
        for i in range(start_idx, min(end_idx, len(self._last_result.values))):
            val = self._last_result.values[i]
            if val is not None:
                x = coord_engine.index_to_x(i)
                y = coord_engine.price_to_y(val)
                middle_points.extend([x, y])

        if len(middle_points) >= 4:
            commands.append(DrawCommand(
                layer=Layer.INDICATORS,
                tag=f"{self.name}_middle",
                item_type="line",
                coords=tuple(middle_points),
                options={
                    "fill": self._style.line_color.to_hex(),
                    "width": self._style.line_width,
                    "smooth": True,
                    "dash": (4, 4),
                },
                z_index=0
            ))

        # Fill between bands
        if len(upper_points) >= 4 and len(lower_points) >= 4:
            # Create polygon: upper band forward, lower band backward
            fill_points = []
            for j in range(0, len(upper_points), 2):
                fill_points.extend([upper_points[j], upper_points[j + 1]])
            for j in range(len(lower_points) - 1, -1, -2):
                fill_points.extend([lower_points[j - 1], lower_points[j]])

            fill_color = self._style.fill_color
            if fill_color:
                rgba = f"rgba({fill_color.r},{fill_color.g},{fill_color.b},{self._style.fill_opacity})"
                commands.append(DrawCommand(
                    layer=Layer.INDICATORS,
                    tag=f"{self.name}_fill",
                    item_type="polygon",
                    coords=tuple(fill_points),
                    options={
                        "fill": rgba,
                        "outline": "",
                    },
                    z_index=-1
                ))

        return commands
