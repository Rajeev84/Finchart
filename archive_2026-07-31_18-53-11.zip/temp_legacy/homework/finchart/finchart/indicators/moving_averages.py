"""Moving Average Indicators."""
from typing import List, Optional

from ..core.types import OHLCV, Color, PriceSource
from .base import Indicator, IndicatorResult, IndicatorStyle


class SMA(Indicator):
    """Simple Moving Average."""

    def __init__(
        self,
        period: int = 20,
        source: PriceSource = PriceSource.CLOSE,
        style: Optional[IndicatorStyle] = None
    ) -> None:
        super().__init__(style or IndicatorStyle(
            line_color=Color(255, 193, 7),
            line_width=1.5
        ))
        self._period = period
        self._source = source

    @property
    def name(self) -> str:
        return f"SMA({self._period})"

    def calculate(self, data: List[OHLCV]) -> IndicatorResult:
        values: List[Optional[float]] = []

        for i in range(len(data)):
            if i < self._period - 1:
                values.append(None)
                continue

            total = 0.0
            for j in range(self._period):
                bar = data[i - j]
                if self._source == PriceSource.CLOSE:
                    total += bar.close
                elif self._source == PriceSource.OPEN:
                    total += bar.open
                elif self._source == PriceSource.HIGH:
                    total += bar.high
                elif self._source == PriceSource.LOW:
                    total += bar.low
                elif self._source == PriceSource.HL2:
                    total += (bar.high + bar.low) / 2
                elif self._source == PriceSource.HLC3:
                    total += (bar.high + bar.low + bar.close) / 3
                elif self._source == PriceSource.OHLC4:
                    total += (bar.open + bar.high + bar.low + bar.close) / 4

            values.append(total / self._period)

        return IndicatorResult(values=values)


class EMA(Indicator):
    """Exponential Moving Average."""

    def __init__(
        self,
        period: int = 20,
        source: PriceSource = PriceSource.CLOSE,
        style: Optional[IndicatorStyle] = None
    ) -> None:
        super().__init__(style or IndicatorStyle(
            line_color=Color(156, 39, 176),
            line_width=1.5
        ))
        self._period = period
        self._source = source

    @property
    def name(self) -> str:
        return f"EMA({self._period})"

    def calculate(self, data: List[OHLCV]) -> IndicatorResult:
        values: List[Optional[float]] = []

        if len(data) < self._period:
            return IndicatorResult(values=[None] * len(data))

        multiplier = 2.0 / (self._period + 1)

        # Initialize with SMA
        total = 0.0
        for i in range(self._period):
            total += self._get_value(data[i])
        ema = total / self._period

        for i in range(len(data)):
            if i < self._period - 1:
                values.append(None)
            elif i == self._period - 1:
                values.append(ema)
            else:
                val = self._get_value(data[i])
                ema = (val - ema) * multiplier + ema
                values.append(ema)

        return IndicatorResult(values=values)

    def _get_value(self, bar: OHLCV) -> float:
        if self._source == PriceSource.CLOSE:
            return bar.close
        elif self._source == PriceSource.OPEN:
            return bar.open
        elif self._source == PriceSource.HIGH:
            return bar.high
        elif self._source == PriceSource.LOW:
            return bar.low
        elif self._source == PriceSource.HL2:
            return (bar.high + bar.low) / 2
        elif self._source == PriceSource.HLC3:
            return (bar.high + bar.low + bar.close) / 3
        elif self._source == PriceSource.OHLC4:
            return (bar.open + bar.high + bar.low + bar.close) / 4
        return bar.close
