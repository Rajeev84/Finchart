"""Oscillator Indicators."""
from typing import List, Optional
import math

from ..core.types import OHLCV, Color
from .base import Indicator, IndicatorResult, IndicatorStyle


class RSI(Indicator):
    """Relative Strength Index."""

    def __init__(
        self,
        period: int = 14,
        style: Optional[IndicatorStyle] = None
    ) -> None:
        super().__init__(style or IndicatorStyle(
            line_color=Color(33, 150, 243),
            line_width=1.5
        ))
        self._period = period

    @property
    def name(self) -> str:
        return f"RSI({self._period})"

    def calculate(self, data: List[OHLCV]) -> IndicatorResult:
        if len(data) < self._period + 1:
            return IndicatorResult(values=[None] * len(data))

        values: List[Optional[float]] = []

        # Calculate initial averages
        gains = 0.0
        losses = 0.0

        for i in range(1, self._period + 1):
            change = data[i].close - data[i - 1].close
            if change > 0:
                gains += change
            else:
                losses += abs(change)

        avg_gain = gains / self._period
        avg_loss = losses / self._period

        for i in range(len(data)):
            if i < self._period:
                values.append(None)
            elif i == self._period:
                if avg_loss == 0:
                    values.append(100.0)
                else:
                    rs = avg_gain / avg_loss
                    values.append(100.0 - (100.0 / (1.0 + rs)))
            else:
                change = data[i].close - data[i - 1].close
                gain = max(0, change)
                loss = abs(min(0, change))

                avg_gain = (avg_gain * (self._period - 1) + gain) / self._period
                avg_loss = (avg_loss * (self._period - 1) + loss) / self._period

                if avg_loss == 0:
                    values.append(100.0)
                else:
                    rs = avg_gain / avg_loss
                    values.append(100.0 - (100.0 / (1.0 + rs)))

        return IndicatorResult(values=values)


class MACD(Indicator):
    """Moving Average Convergence Divergence."""

    def __init__(
        self,
        fast_period: int = 12,
        slow_period: int = 26,
        signal_period: int = 9,
        style: Optional[IndicatorStyle] = None
    ) -> None:
        super().__init__(style or IndicatorStyle(
            line_color=Color(33, 150, 243),
            line_width=1.5
        ))
        self._fast_period = fast_period
        self._slow_period = slow_period
        self._signal_period = signal_period

    @property
    def name(self) -> str:
        return f"MACD({self._fast_period},{self._slow_period})"

    def calculate(self, data: List[OHLCV]) -> IndicatorResult:
        if len(data) < self._slow_period:
            return IndicatorResult(values=[None] * len(data))

        # Calculate EMAs
        fast_ema = self._calculate_ema(data, self._fast_period)
        slow_ema = self._calculate_ema(data, self._slow_period)

        # MACD line = fast EMA - slow EMA
        macd_line = []
        for i in range(len(data)):
            if fast_ema[i] is None or slow_ema[i] is None:
                macd_line.append(None)
            else:
                macd_line.append(fast_ema[i] - slow_ema[i])

        # Signal line = EMA of MACD line
        signal_line = self._ema_of_list(macd_line, self._signal_period)

        # Histogram = MACD - Signal
        histogram = []
        colors = []
        for i in range(len(data)):
            if macd_line[i] is None or signal_line[i] is None:
                histogram.append(None)
                colors.append(None)
            else:
                hist = macd_line[i] - signal_line[i]
                histogram.append(hist)
                colors.append(Color(38, 166, 154) if hist >= 0 else Color(239, 83, 80))

        # Return MACD line as primary, but store others for multi-line rendering
        return IndicatorResult(values=histogram, colors=colors)

    def _calculate_ema(self, data: List[OHLCV], period: int) -> List[Optional[float]]:
        """Calculate EMA of closing prices."""
        multiplier = 2.0 / (period + 1)
        ema_values: List[Optional[float]] = []

        if len(data) < period:
            return [None] * len(data)

        total = sum(d.close for d in data[:period])
        ema = total / period

        for i in range(len(data)):
            if i < period - 1:
                ema_values.append(None)
            elif i == period - 1:
                ema_values.append(ema)
            else:
                ema = (data[i].close - ema) * multiplier + ema
                ema_values.append(ema)

        return ema_values

    def _ema_of_list(self, values: List[Optional[float]], period: int) -> List[Optional[float]]:
        """Calculate EMA of a list of values."""
        multiplier = 2.0 / (period + 1)
        ema_values: List[Optional[float]] = []

        # Find first valid value
        first_valid = None
        first_idx = 0
        for i, v in enumerate(values):
            if v is not None:
                first_valid = v
                first_idx = i
                break

        if first_valid is None:
            return [None] * len(values)

        # Collect valid values for initial SMA
        valid_values = []
        for i in range(first_idx, len(values)):
            if values[i] is not None:
                valid_values.append(values[i])
            if len(valid_values) >= period:
                break

        if len(valid_values) < period:
            return [None] * len(values)

        ema = sum(valid_values) / period

        for i in range(len(values)):
            if i < first_idx + period - 1:
                ema_values.append(None)
            elif i == first_idx + period - 1:
                ema_values.append(ema)
            else:
                val = values[i]
                if val is not None:
                    ema = (val - ema) * multiplier + ema
                ema_values.append(ema)

        return ema_values
