"""Event Bus - Decoupled publish/subscribe messaging system."""
from __future__ import annotations

import weakref
from typing import Callable, Dict, List, Any
from dataclasses import dataclass
from enum import Enum, auto


class EventType(Enum):
    """Core event types."""
    DATA_CHANGED = auto()
    VISIBLE_RANGE_CHANGED = auto()
    SCALE_CHANGED = auto()
    LAYOUT_CHANGED = auto()
    HOVER_CHANGED = auto()
    SELECTION_CHANGED = auto()
    CHART_TYPE_CHANGED = auto()
    THEME_CHANGED = auto()
    INDICATOR_ADDED = auto()
    INDICATOR_REMOVED = auto()
    DRAWING_ADDED = auto()
    DRAWING_REMOVED = auto()
    DRAWING_UPDATED = auto()
    ANIMATION_FRAME = auto()
    RESIZE = auto()
    MOUSE_DOWN = auto()
    MOUSE_MOVE = auto()
    MOUSE_UP = auto()
    MOUSE_WHEEL = auto()
    KEY_DOWN = auto()
    KEY_UP = auto()
    REQUEST_RENDER = auto()
    RENDER_COMPLETE = auto()


@dataclass(frozen=True)
class Event:
    """Immutable event container."""
    type: EventType
    source: Any
    data: Dict[str, Any]


class EventBus:
    """Central event bus with weak references to prevent memory leaks."""

    def __init__(self) -> None:
        self._subscribers: Dict[EventType, List[weakref.ref]] = {}
        self._callbacks: Dict[int, Callable[[Event], None]] = {}
        self._counter = 0
        self._emitting = False
        self._queue: List[Event] = []

    def subscribe(self, event_type: EventType, callback: Callable[[Event], None]) -> int:
        """Subscribe to an event type. Returns subscription ID."""
        self._counter += 1
        sub_id = self._counter

        if event_type not in self._subscribers:
            self._subscribers[event_type] = []

        self._subscribers[event_type].append(weakref.ref(callback))
        self._callbacks[sub_id] = callback
        return sub_id

    def unsubscribe(self, sub_id: int) -> None:
        """Unsubscribe by ID."""
        if sub_id not in self._callbacks:
            return
        callback = self._callbacks.pop(sub_id)
        for event_type, refs in self._subscribers.items():
            self._subscribers[event_type] = [
                ref for ref in refs 
                if ref() is not None and ref() is not callback
            ]

    def emit(self, event: Event) -> None:
        """Emit an event to all subscribers."""
        if self._emitting:
            self._queue.append(event)
            return

        self._emitting = True
        try:
            refs = self._subscribers.get(event.type, [])
            for ref in refs:
                callback = ref()
                if callback is not None:
                    try:
                        callback(event)
                    except Exception:
                        # Prevent one bad subscriber from breaking others
                        pass
        finally:
            self._emitting = False
            # Process queued events
            while self._queue:
                queued = self._queue.pop(0)
                self.emit(queued)

    def emit_new(self, event_type: EventType, source: Any, **data) -> None:
        """Convenience method to create and emit an event."""
        self.emit(Event(type=event_type, source=source, data=data))
