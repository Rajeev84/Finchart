"""Core type definitions for the financial charting library."""
from __future__ import annotations

from typing import Optional, List, Tuple, Callable, Dict, Any
from dataclasses import dataclass, field
from enum import Enum, auto
import time


class ChartType(Enum):
    """Supported chart types."""
    CANDLESTICK = auto()
    OHLC = auto()
    LINE = auto()
    AREA = auto()
    HISTOGRAM = auto()
    BASELINE = auto()
    STEP = auto()
    HEIKIN_ASHI = auto()


class ScaleMode(Enum):
    """Price scale modes."""
    AUTO = auto()
    MANUAL = auto()
    LOG = auto()
    PERCENTAGE = auto()


class PriceSource(Enum):
    """Price source for calculations."""
    CLOSE = auto()
    OPEN = auto()
    HIGH = auto()
    LOW = auto()
    HL2 = auto()
    HLC3 = auto()
    OHLC4 = auto()


@dataclass(frozen=True, slots=True)
class OHLCV:
    """Immutable candlestick/bar data point."""
    timestamp: float  # Unix timestamp in seconds
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0

    @property
    def time(self) -> float:
        return self.timestamp

    @property
    def body_top(self) -> float:
        return max(self.open, self.close)

    @property
    def body_bottom(self) -> float:
        return min(self.open, self.close)

    @property
    def is_bullish(self) -> bool:
        return self.close >= self.open

    @property
    def is_bearish(self) -> bool:
        return self.close < self.open

    @property
    def range(self) -> float:
        return self.high - self.low

    @property
    def body_size(self) -> float:
        return abs(self.close - self.open)

    @property
    def upper_wick(self) -> float:
        return self.high - self.body_top

    @property
    def lower_wick(self) -> float:
        return self.body_bottom - self.low


@dataclass(slots=True)
class VisibleRange:
    """Visible data range with indices."""
    start_index: int = 0
    end_index: int = 0
    bar_count: int = 0

    @property
    def count(self) -> int:
        return max(0, self.end_index - self.start_index)


@dataclass(slots=True)
class Viewport:
    """2D viewport in pixel coordinates."""
    x: float = 0.0
    y: float = 0.0
    width: float = 0.0
    height: float = 0.0

    @property
    def left(self) -> float:
        return self.x

    @property
    def right(self) -> float:
        return self.x + self.width

    @property
    def top(self) -> float:
        return self.y

    @property
    def bottom(self) -> float:
        return self.y + self.height

    @property
    def center_x(self) -> float:
        return self.x + self.width / 2

    @property
    def center_y(self) -> float:
        return self.y + self.height / 2

    def contains(self, px: float, py: float) -> bool:
        return (self.left <= px <= self.right and 
                self.top <= py <= self.bottom)

    def inset(self, dx: float, dy: float) -> Viewport:
        return Viewport(
            x=self.x + dx,
            y=self.y + dy,
            width=max(0, self.width - 2 * dx),
            height=max(0, self.height - 2 * dy)
        )


@dataclass(slots=True)
class Point:
    """2D point."""
    x: float = 0.0
    y: float = 0.0

    def __add__(self, other: Point) -> Point:
        return Point(self.x + other.x, self.y + other.y)

    def __sub__(self, other: Point) -> Point:
        return Point(self.x - other.x, self.y - other.y)


@dataclass(slots=True)
class Color:
    """RGBA color."""
    r: int = 0
    g: int = 0
    b: int = 0
    a: float = 1.0

    def to_hex(self) -> str:
        return f"#{self.r:02x}{self.g:02x}{self.b:02x}"

    def to_rgba(self) -> str:
        return f"rgba({self.r},{self.g},{self.b},{self.a})"

    @classmethod
    def from_hex(cls, hex_str: str) -> Color:
        hex_str = hex_str.lstrip("#")
        return cls(
            r=int(hex_str[0:2], 16),
            g=int(hex_str[2:4], 16),
            b=int(hex_str[4:6], 16)
        )


@dataclass(slots=True)
class Rect:
    """Rectangle."""
    x: float = 0.0
    y: float = 0.0
    width: float = 0.0
    height: float = 0.0

    @property
    def left(self) -> float:
        return self.x

    @property
    def right(self) -> float:
        return self.x + self.width

    @property
    def top(self) -> float:
        return self.y

    @property
    def bottom(self) -> float:
        return self.y + self.height

    def contains(self, px: float, py: float) -> bool:
        return (self.left <= px <= self.right and 
                self.top <= py <= self.bottom)


@dataclass(slots=True)
class Padding:
    """Padding/margins."""
    left: float = 0.0
    top: float = 0.0
    right: float = 0.0
    bottom: float = 0.0
