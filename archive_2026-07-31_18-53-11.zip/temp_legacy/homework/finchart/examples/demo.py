#!/usr/bin/env python3
"""FinChart Demo - Professional financial charting demonstration.

This demo showcases:
- Candlestick, Line, Area, Histogram chart types
- Pan and zoom interactions
- Crosshair with price/time labels
- Technical indicators (SMA, EMA, Bollinger Bands, RSI)
- Auto-scaling and fit-to-view
- Real-time data simulation
"""
import tkinter as tk
from tkinter import ttk
import random
import math
import time
from datetime import datetime, timedelta

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from finchart import ChartWidget, OHLCV, ChartType
from finchart.indicators.moving_averages import SMA, EMA
from finchart.indicators.volatility import BollingerBands
from finchart.indicators.oscillators import RSI


def generate_sample_data(count: int = 500) -> list[OHLCV]:
    """Generate realistic-looking OHLCV sample data."""
    data = []
    base_price = 100.0
    timestamp = time.time() - count * 3600  # Start from past

    for i in range(count):
        # Random walk with trend
        trend = math.sin(i / 50) * 5 + math.sin(i / 20) * 2
        noise = random.gauss(0, 1.5)

        open_price = base_price + trend + noise
        close_price = open_price + random.gauss(0, 1.0)
        high_price = max(open_price, close_price) + random.uniform(0, 2)
        low_price = min(open_price, close_price) - random.uniform(0, 2)
        volume = random.uniform(1000, 10000)

        data.append(OHLCV(
            timestamp=timestamp,
            open=round(open_price, 2),
            high=round(high_price, 2),
            low=round(low_price, 2),
            close=round(close_price, 2),
            volume=round(volume, 2)
        ))

        base_price = close_price
        timestamp += 3600  # 1 hour bars

    return data


class DemoApp:
    """Demo application with control panel."""

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("FinChart - Professional Financial Charting")
        self.root.geometry("1200x800")
        self.root.configure(bg="#0a0e17")

        # Generate data
        self._data = generate_sample_data(500)
        self._data_index = len(self._data)
        self._is_simulating = False

        self._setup_ui()

    def _setup_ui(self) -> None:
        """Setup the user interface."""
        # Main frame
        main_frame = tk.Frame(self.root, bg="#0a0e17")
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Control panel
        control_frame = tk.Frame(main_frame, bg="#1a1f2e", height=50)
        control_frame.pack(fill="x", pady=(0, 5))
        control_frame.pack_propagate(False)

        # Chart type buttons
        tk.Label(control_frame, text="Chart Type:", bg="#1a1f2e", fg="#888", 
                 font=("Segoe UI", 10)).pack(side="left", padx=(10, 5))

        chart_types = [
            ("Candlestick", ChartType.CANDLESTICK),
            ("Line", ChartType.LINE),
            ("Area", ChartType.AREA),
            ("Histogram", ChartType.HISTOGRAM),
        ]

        for name, ct in chart_types:
            btn = tk.Button(
                control_frame, text=name,
                bg="#2a2e39", fg="#ddd",
                activebackground="#3a3e49", activeforeground="#fff",
                relief="flat", cursor="hand2",
                font=("Segoe UI", 9),
                command=lambda t=ct: self._set_chart_type(t)
            )
            btn.pack(side="left", padx=2)

        # Separator
        tk.Frame(control_frame, bg="#3a3e49", width=1).pack(side="left", fill="y", padx=10, pady=8)

        # Indicator buttons
        tk.Label(control_frame, text="Indicators:", bg="#1a1f2e", fg="#888",
                 font=("Segoe UI", 10)).pack(side="left", padx=(5, 5))

        indicators = [
            ("SMA 20", lambda: self._add_indicator("sma20")),
            ("EMA 20", lambda: self._add_indicator("ema20")),
            ("BB", lambda: self._add_indicator("bb")),
            ("RSI", lambda: self._add_indicator("rsi")),
            ("Clear", self._clear_indicators),
        ]

        for name, cmd in indicators:
            btn = tk.Button(
                control_frame, text=name,
                bg="#2a2e39", fg="#ddd",
                activebackground="#3a3e49", activeforeground="#fff",
                relief="flat", cursor="hand2",
                font=("Segoe UI", 9),
                command=cmd
            )
            btn.pack(side="left", padx=2)

        # Separator
        tk.Frame(control_frame, bg="#3a3e49", width=1).pack(side="left", fill="y", padx=10, pady=8)

        # Action buttons
        tk.Button(
            control_frame, text="Fit",
            bg="#2a2e39", fg="#ddd",
            activebackground="#3a3e49", activeforeground="#fff",
            relief="flat", cursor="hand2",
            font=("Segoe UI", 9),
            command=self._fit
        ).pack(side="left", padx=2)

        self._sim_btn = tk.Button(
            control_frame, text="▶ Simulate",
            bg="#2a7d46", fg="#fff",
            activebackground="#3a8d56", activeforeground="#fff",
            relief="flat", cursor="hand2",
            font=("Segoe UI", 9),
            command=self._toggle_simulation
        )
        self._sim_btn.pack(side="left", padx=2)

        # Info label
        self._info_label = tk.Label(
            control_frame, text="Mouse: Drag=Pan, Wheel=Zoom, R=Fit",
            bg="#1a1f2e", fg="#666",
            font=("Segoe UI", 9)
        )
        self._info_label.pack(side="right", padx=10)

        # Chart widget
        self._chart = ChartWidget(main_frame, width=1160, height=700)
        self._chart.pack(fill="both", expand=True)

        # Set data
        self._chart.set_data(self._data)

    def _set_chart_type(self, chart_type: ChartType) -> None:
        """Change chart type."""
        self._chart.set_chart_type(chart_type)

    def _add_indicator(self, indicator_type: str) -> None:
        """Add an indicator."""
        if indicator_type == "sma20":
            self._chart.add_indicator(SMA(period=20))
        elif indicator_type == "ema20":
            self._chart.add_indicator(EMA(period=20))
        elif indicator_type == "bb":
            self._chart.add_indicator(BollingerBands(period=20, std_dev=2.0))
        elif indicator_type == "rsi":
            self._chart.add_indicator(RSI(period=14))

    def _clear_indicators(self) -> None:
        """Clear all indicators."""
        self._chart.clear_indicators()

    def _fit(self) -> None:
        """Fit all data into view."""
        self._chart.fit_range()

    def _toggle_simulation(self) -> None:
        """Toggle real-time data simulation."""
        if self._is_simulating:
            self._is_simulating = False
            self._sim_btn.configure(text="▶ Simulate", bg="#2a7d46")
        else:
            self._is_simulating = True
            self._sim_btn.configure(text="⏹ Stop", bg="#8b2a2a")
            self._simulate_tick()

    def _simulate_tick(self) -> None:
        """Simulate a new tick."""
        if not self._is_simulating:
            return

        last_bar = self._data[-1]

        # Random price movement
        change = random.gauss(0, 0.5)
        new_close = round(last_bar.close + change, 2)
        new_high = round(max(last_bar.high, new_close) + random.uniform(0, 0.5), 2)
        new_low = round(min(last_bar.low, new_close) - random.uniform(0, 0.5), 2)
        new_volume = round(last_bar.volume + random.uniform(-100, 100), 2)

        new_bar = OHLCV(
            timestamp=last_bar.timestamp + 3600,
            open=last_bar.close,
            high=new_high,
            low=new_low,
            close=new_close,
            volume=max(0, new_volume)
        )

        self._data.append(new_bar)
        self._chart.append(new_bar)

        # Schedule next tick
        self.root.after(200, self._simulate_tick)


def main():
    """Run the demo."""
    root = tk.Tk()
    app = DemoApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
