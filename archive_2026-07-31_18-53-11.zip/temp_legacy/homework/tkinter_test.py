"""
Tkinter Canvas Chart Demo — Full-featured candlestick chart with zoom, pan,
indicators, and shape drawing tools.
"""
import tkinter as tk
from tkinter import ttk, messagebox
import random
from datetime import datetime, timedelta

from pycanvascharts import Chart, CandlestickSeries, KLineData
from pycanvascharts.core.store import UpdateLevel
from pycanvascharts.renderers.canvas_renderer import (
    TkinterCanvasRenderer,
    HorizontalLine,
    VerticalLine,
    TrendLine,
)
from pycanvascharts.indicators.sma import SMA


def generate_data(n=200):
    """Generate sample OHLC data."""
    data = []
    base_price = 100.0
    timestamp = int(datetime(2024, 1, 1).timestamp() * 1000)

    for i in range(n):
        open_p = base_price + random.uniform(-2, 2)
        close_p = open_p + random.uniform(-3, 3)
        high_p = max(open_p, close_p) + random.uniform(0, 2)
        low_p = min(open_p, close_p) - random.uniform(0, 2)
        volume = random.uniform(1000, 10000)

        data.append(KLineData(
            timestamp=timestamp,
            open=round(open_p, 4),
            high=round(high_p, 4),
            low=round(low_p, 4),
            close=round(close_p, 4),
            volume=round(volume, 2)
        ))
        base_price = close_p
        timestamp += 24 * 60 * 60 * 1000  # +1 day

    return data


class CandlestickApp:
    """Tkinter application with full charting capabilities."""

    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Candlestick Chart - pyEasyChart")
        self.root.configure(bg="#1e222d")
        self.root.minsize(700, 400)

        # Chart dimensions
        self.chart_width = 900
        self.chart_height = 500

        # ─── Toolbar Frame ───
        toolbar = tk.Frame(root, bg="#2a2e39", height=36)
        toolbar.pack(fill=tk.X, side=tk.TOP)

        # Tool button style
        btn_style = {
            "bg": "#2a2e39",
            "fg": "#d1d4dc",
            "relief": tk.FLAT,
            "font": ("Segoe UI", 9),
            "padx": 8,
            "pady": 2,
            "activebackground": "#3a3e49",
            "activeforeground": "#ffffff",
            "bd": 0,
        }

        # Mode buttons
        self._mode_var = tk.StringVar(value="crosshair")

        def make_mode_callback(mode):
            def cb():
                self._mode_var.set(mode)
                self.renderer.set_mode(mode)
                self._update_toolbar_highlight()
            return cb

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=4, pady=4)

        # Crosshair / Pan
        self._btn_crosshair = tk.Button(toolbar, text="◉ Crosshair", command=make_mode_callback("crosshair"), **btn_style)
        self._btn_crosshair.pack(side=tk.LEFT, padx=2)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=4, pady=4)

        # Drawing tools
        self._btn_hline = tk.Button(toolbar, text="━ H-Line", command=make_mode_callback("draw_hline"), **btn_style)
        self._btn_hline.pack(side=tk.LEFT, padx=2)

        self._btn_vline = tk.Button(toolbar, text="┃ V-Line", command=make_mode_callback("draw_vline"), **btn_style)
        self._btn_vline.pack(side=tk.LEFT, padx=2)

        self._btn_trend = tk.Button(toolbar, text="╱ Trend", command=make_mode_callback("draw_trend"), **btn_style)
        self._btn_trend.pack(side=tk.LEFT, padx=2)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=4, pady=4)

        # Clear shapes
        tk.Button(toolbar, text="✕ Clear Shapes",
                  command=self._clear_shapes, **btn_style).pack(side=tk.LEFT, padx=2)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=4, pady=4)

        # SMA indicator
        tk.Button(toolbar, text="📈 SMA 14",
                  command=self._add_sma, **btn_style).pack(side=tk.LEFT, padx=2)

        tk.Button(toolbar, text="📈 SMA 50",
                  command=self._add_sma_50, **btn_style).pack(side=tk.LEFT, padx=2)

        tk.Button(toolbar, text="✕ Clear Indicators",
                  command=self._clear_indicators, **btn_style).pack(side=tk.LEFT, padx=2)

        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=4, pady=4)

        # Reset view
        tk.Button(toolbar, text="⟲ Fit View",
                  command=self._fit_view, **btn_style).pack(side=tk.LEFT, padx=2)

        # Status label (right side)
        self._status_var = tk.StringVar(value="Crosshair mode — drag to pan, scroll to zoom")
        status_label = tk.Label(toolbar, textvariable=self._status_var,
                                 bg="#2a2e39", fg="#787b86",
                                 font=("Segoe UI", 8), anchor=tk.E)
        status_label.pack(side=tk.RIGHT, padx=10, fill=tk.X)

        # ─── Canvas Frame ───
        canvas_frame = tk.Frame(root, bg="#1e222d")
        canvas_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        self.canvas = tk.Canvas(
            canvas_frame,
            width=self.chart_width,
            height=self.chart_height,
            bg="#1e222d",
            highlightthickness=0,
        )
        self.canvas.pack(fill=tk.BOTH, expand=True)

        # ─── Create Chart ───
        self.chart = Chart(width=self.chart_width, height=self.chart_height, theme="dark")

        # Create and assign Tkinter renderer
        self.renderer = TkinterCanvasRenderer(self.canvas, self.chart)
        self.chart._renderer = self.renderer

        # Generate and set data
        data = generate_data(200)
        self.chart.add_series(CandlestickSeries, data=data)

        # Fit content to view
        self.chart.fit_content()

        # Bind resize
        self.root.bind("<Configure>", self.on_resize)

        # Initial toolbar highlight
        self._update_toolbar_highlight()

    def _update_toolbar_highlight(self):
        """Highlight the active tool button."""
        mode = self._mode_var.get()
        active_bg = "#3a3e49"
        default_bg = "#2a2e39"
        self._btn_crosshair.config(bg=active_bg if mode == "crosshair" else default_bg)
        self._btn_hline.config(bg=active_bg if mode == "draw_hline" else default_bg)
        self._btn_vline.config(bg=active_bg if mode == "draw_vline" else default_bg)
        self._btn_trend.config(bg=active_bg if mode == "draw_trend" else default_bg)

        # Update status
        status_map = {
            "crosshair": "Crosshair mode — drag to pan, scroll to zoom",
            "draw_hline": "Horizontal Line mode — click to place a horizontal line",
            "draw_vline": "Vertical Line mode — click to place a vertical line",
            "draw_trend": "Trend Line mode — click two points to draw a trend line",
        }
        self._status_var.set(status_map.get(mode, ""))

    def _add_sma(self):
        """Add SMA(14) indicator."""
        data = self.chart._store.get_data_list()
        if not data:
            return
        sma = SMA(store=self.chart._store, styles=self.chart._styles,
                   period=14, color="#f0d43a")
        sma.set_data(data)
        self.chart._store.add_indicator("sma_14", sma)
        self.chart._store.notify(UpdateLevel.Full)
        self._status_var.set("Added SMA(14) indicator")

    def _add_sma_50(self):
        """Add SMA(50) indicator."""
        data = self.chart._store.get_data_list()
        if not data:
            return
        sma = SMA(store=self.chart._store, styles=self.chart._styles,
                   period=50, color="#50b5ff")
        sma.set_data(data)
        self.chart._store.add_indicator("sma_50", sma)
        self.chart._store.notify(UpdateLevel.Full)
        self._status_var.set("Added SMA(50) indicator")

    def _clear_indicators(self):
        """Remove all indicators."""
        self.chart._store._indicators.clear()
        self.chart._store.notify(UpdateLevel.Full)
        self._status_var.set("Cleared all indicators")

    def _clear_shapes(self):
        """Remove all drawn shapes."""
        self.renderer.remove_shapes()
        self._status_var.set("Cleared all drawn shapes")

    def _fit_view(self):
        """Reset zoom to fit all data."""
        self.chart.fit_content()
        self._status_var.set("View reset to fit all data")

    def on_resize(self, event):
        """Handle window resize."""
        if event.widget == self.root and event.width > 100 and event.height > 100:
            new_w = event.width - 10
            new_h = event.height - 50
            if new_w > 100 and new_h > 100:
                self.chart._width = new_w
                self.chart._height = new_h
                self.chart._layout_dirty = True
                self.chart._store.notify(UpdateLevel.Full)


def main():
    root = tk.Tk()
    app = CandlestickApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()