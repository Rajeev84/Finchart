# EasyPyChart vs pycanvascharts — Comprehensive Comparison

## 1. OVERVIEW

| Aspect | **EasyPyChart** | **pycanvascharts** |
|--------|----------------|-------------------|
| **Purpose** | TradingView‑inspired interactive charting for Python | TradingView‑inspired charting library for Python |
| **Rendering Engine** | **Tkinter Canvas** (native desktop GUI) | **HTML5 Canvas via embedded JS** (standalone HTML / Jupyter) |
| **Output** | Desktop window (tkinter) & standalone HTML | Standalone HTML file / Jupyter display |
| **Files** | ~13 files (core, data, interaction_manager, layout_manager + tests/demos) | ~16 files (core/, renderers/, series/, indicators/, utils/) |
| **Maturity** | More mature, battle-tested with drawing tools, session persistence, market profile | Newer, cleaner architecture but fewer features |

## 2. ARCHITECTURE

### EasyPyChart
- **Tightly coupled**: `EasyPyChart` (tk.Frame subclass) is self-contained (rendering, events, coordinate transforms all in one file `core.py` ~1969 lines)
- **Managers on top**: `InteractionManager` + `LayoutManager` wrap the chart for advanced features (drawing tools, session management)
- **Data layer**: `ChartData` wraps a pandas DataFrame, handles OHLCV normalization, time-index interpolation

### pycanvascharts
- **Modular / layered architecture**:
  - `Chart` → orchestrator
  - `ChartStore` → central data/state with observer pattern (subscribe/notify)
  - `Pane` + `MainPane`/`IndicatorPane`/`XAxisPane` → layout management
  - `TimeAxis`/`PriceAxis` → axis abstractions
  - `BaseSeries` + subclasses → series abstraction
  - `TkinterCanvasRenderer` → renderer separate from chart logic
  - `EventBus` → pub/sub for events
  - `Styles` → comprehensive styling/theming (Layout, Grid, Candle, PriceAxis, TimeAxis, Crosshair, Tooltip)
- **Cleaner separation of concerns** but less feature depth

## 3. FEATURE COMPARISON

| Feature | **EasyPyChart** | **pycanvascharts** |
|---------|----------------|-------------------|
| **Candlestick chart** | ✅ Full OHLC rendering with up/down colors | ✅ Full OHLC rendering via embedded JS |
| **Other series types** | Line series (indicators only) | Candlestick, Bar, Line, Area, Histogram (structurally defined) |
| **Indicators** | Custom series via `create_series()`; `LayoutManager` manages global indicator configs | `SMA` indicator class; extensible via `indicators/` |
| **Subplots / Panes** | ✅ Weight-based multi-pane layout | ✅ Pane system (MainPane, IndicatorPane, XAxisPane) with stretch factors |
| **Zoom & Pan** | ✅ Mouse wheel zoom, click-drag pan | ✅ Mouse wheel zoom, click-drag pan |
| **Crosshair** | ✅ Full crosshair with date + price labels, tooltip | ✅ Full crosshair with price label + OHLC tooltip |
| **Drawing tools** | **Rich support**: Line, Rectangle, HLine, VLine, Angle Line, Long/Short Position (multi‑phase) | **Basic**: HorizontalLine, VerticalLine, TrendLine shape classes |
| **Shape selection/drag/resize** | ✅ Selection handles, drag, resize handles, group selection | ❌ Not implemented |
| **Persistence** | ✅ JSON state save/load per symbol; `LayoutManager` with `save_session`/`load_session` | ❌ Not implemented |
| **Market Profile (TPO)** | ✅ Full Market Profile overlay with Value Area, POC, Open/Close lines | ❌ Not implemented |
| **Event system** | Callback-based dispatch with rich event payload | `EventBus` pub/sub |
| **Theme/Styles** | Basic config dict | Comprehensive `Styles` class with Layout/Grid/Candle/Axis/Crosshair/Tooltip styles + light/dark Theme factory |
| **HTML export** | ✅ Standalone HTML + JS | ✅ Primary output is HTML |
| **Jupyter support** | Not specific | ✅ `chart.show()` in Jupyter |
| **Multi-symbol context** | ✅ `LayoutManager.set_context()` with per-symbol drawing/view states | ❌ Not implemented |
| **Series Update API** | `chart.plot('candlestick').update(df)` fluent interface | `chart.add_series()` + `series.set_data()` |
| **Tests** | ✅ Several test files (test_chart.py, test_drawing_tools.py, test_realtime.py, etc.) | ❌ No test files found |

## 4. STRENGTHS & WEAKNESSES

### EasyPyChart ✅ Strengths
- **Extremely feature-rich**: Drawing tools, position management (Long/Short multi-phase with labels/resizing), Market Profile, session persistence
- **Production-ready interaction**: Shape selection, drag, resize handles, group operations
- **Multi-symbol/timeframe support**: Context switching preserves drawings, view states, indicators per symbol
- **Data flexibility**: Accepts any DataFrame, normalizes columns automatically
- **Event dispatch**: Rich event payload with OHLC enrichment, shape/series hit testing

### EasyPyChart ❌ Weaknesses
- **Monolithic core**: `core.py` is 1969 lines mixing rendering, events, layout, drawing, persistence
- **Tkinter-only**: Cannot run headless or in web-only environments
- **Complexity**: Requires understanding `InteractionManager` + `LayoutManager` for full usage
- **No formal styles/theming system** (uses raw config dicts)

### pycanvascharts ✅ Strengths
- **Clean, modular architecture**: Proper separation of store/renderer/axes/panes/series/styles
- **HTML-first output**: Renders in any browser, works in Jupyter, embeddable
- **Comprehensive styling**: TradingView-inspired style system with full customization
- **Extensible**: Easy to add new series types, indicators, or renderers
- **DPR-aware canvas**: Handles retina/high-DPI displays properly
- **React-style observer pattern**: Store notifies subscribers on data/state changes

### pycanvascharts ❌ Weaknesses
- **Feature-incomplete**: No drawing tools persistence, no Market Profile, no multi-symbol context, no shape manipulation
- **No tests** found in the repository
- **Renderer coupling**: The only real renderer is the HTML/JS canvas renderer (TkinterCanvasRenderer exists but is standalone)
- **Series implementations are stubs**: Most series classes (`LineSeries`, `BarSeries`, `AreaSeries`, `HistogramSeries`) have minimal or empty implementations
- **Indicators limited**: Only SMA is implemented

## 5. WHEN TO USE WHICH

| Use Case | **Choose** |
|----------|-----------|
| Desktop GUI trading app with tkinter | **EasyPyChart** |
| Need drawing tools (lines, rectangles, positions) with drag/resize | **EasyPyChart** |
| Need Market Profile (TPO) | **EasyPyChart** |
| Need multi-symbol/timeframe session management | **EasyPyChart** |
| Jupyter notebook with web rendering | **pycanvascharts** |
| Embeddable web chart | **pycanvascharts** |
| Clean architecture / easy extensibility | **pycanvascharts** |
| Need light/dark theme out-of-the-box | **pycanvascharts** |
| Need all-in-one solution (charts + drawings + persistence + indicators) | **EasyPyChart** |

## 6. VERSION / INSPIRATION NOTES

- **EasyPyChart** draws inspiration from **TradingView** (dark theme, crosshair, drawing tools) and has been iterated more extensively with real-world usage patterns (position management, session persistence, Market Profile).
- **pycanvascharts** is explicitly inspired by **TradingView** (styles/theming) and **KLineCharts** (store/pane architecture), aiming for a cleaner codebase but still in early development.