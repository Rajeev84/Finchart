"""demo_1.py - Basic FinChart Usage Demo.

Demonstrates:
  - Loading synthetic OHLCV data into ChartWidget
  - Enabling SMA and EMA overlays
  - Dark / Light theme switching via keyboard
  - Fit-to-content and zoom controls
  - Line and Area chart type switching

Run:
    python demo_1.py
"""
import tkinter as tk
import math
import random
from datetime import datetime, timedelta

from finchart import ChartWidget, OHLCV, DarkTheme, LightTheme
from finchart.core.types import ChartType
from finchart.indicators import SMA, EMA


def generate_price_data(n: int = 300, seed: int = 42) -> list:
    """Generate synthetic OHLCV candlestick data using a random walk."""
    random.seed(seed)
    bars = []
    price = 180.0
    base_ts = datetime(2024, 1, 2, 9, 30)

    for i in range(n):
        open_ = price
        change = random.gauss(0.0, price * 0.008)
        close = max(1.0, price + change)
        high  = max(open_, close) * (1.0 + abs(random.gauss(0.0, 0.003)))
        low   = min(open_, close) * (1.0 - abs(random.gauss(0.0, 0.003)))
        vol   = random.uniform(500_000, 5_000_000)

        ts = (base_ts + timedelta(minutes=i * 5)).timestamp()
        bars.append(OHLCV(timestamp=ts, open=open_, high=high, low=low, close=close, volume=vol))
        price = close

    return bars


def main():
    root = tk.Tk()
    root.title("FinChart Demo — Basic Usage")
    root.geometry("1280x760")
    root.configure(bg="#131722")

    # Status bar
    status = tk.Label(
        root,
        text="  [T] Theme  [L] Line  [A] Area  [C] Candles  [F] Fit  [+/-] Zoom  [Drag] Pan",
        bg="#0D1117",
        fg="#787B86",
        font=("Segoe UI", 9),
        anchor="w",
    )
    status.pack(side="bottom", fill="x", ipady=4)

    # Info bar (hover callback updates this)
    info_var = tk.StringVar(value="Hover over a bar to see OHLCV data")
    info_bar = tk.Label(
        root,
        textvariable=info_var,
        bg="#131722",
        fg="#B2B5BE",
        font=("Segoe UI", 9),
        anchor="w",
    )
    info_bar.pack(side="bottom", fill="x", ipady=2)

    # Hover callback
    def on_hover(event_type: str, data: dict):
        if event_type == "hover" and data.get("bar"):
            bar = data["bar"]
            dt = datetime.fromtimestamp(bar.timestamp).strftime("%Y-%m-%d %H:%M")
            info_var.set(
                f"  {dt}   O: {bar.open:.2f}   H: {bar.high:.2f}   L: {bar.low:.2f}   "
                f"C: {bar.close:.2f}   V: {bar.volume:,.0f}"
            )

    # Chart Widget
    chart = ChartWidget(
        root,
        width=1280,
        height=700,
        theme=DarkTheme(),
        callback=on_hover,
    )
    chart.pack(fill="both", expand=True, padx=0, pady=0)

    # Load data and add indicators
    bars = generate_price_data(300)
    chart.set_data(bars)
    chart.add_indicator(SMA(20, color="#2196F3", width=1.5))
    chart.add_indicator(EMA(9, color="#FF9800", width=1.5))

    # ---- Keyboard Bindings ----
    _dark = [True]

    def toggle_theme(e=None):
        if _dark[0]:
            chart.set_theme(LightTheme())
            root.configure(bg="#FFFFFF")
            status.configure(bg="#F0F3FA", fg="#444444")
            info_bar.configure(bg="#FFFFFF", fg="#444444")
        else:
            chart.set_theme(DarkTheme())
            root.configure(bg="#131722")
            status.configure(bg="#0D1117", fg="#787B86")
            info_bar.configure(bg="#131722", fg="#B2B5BE")
        _dark[0] = not _dark[0]

    root.bind("<t>", toggle_theme)
    root.bind("<T>", toggle_theme)
    root.bind("<l>", lambda e: chart.set_chart_type(ChartType.LINE))
    root.bind("<L>", lambda e: chart.set_chart_type(ChartType.LINE))
    root.bind("<a>", lambda e: chart.set_chart_type(ChartType.AREA))
    root.bind("<A>", lambda e: chart.set_chart_type(ChartType.AREA))
    root.bind("<c>", lambda e: chart.set_chart_type(ChartType.CANDLESTICK))
    root.bind("<C>", lambda e: chart.set_chart_type(ChartType.CANDLESTICK))
    root.bind("<f>", lambda e: chart.fit_content())
    root.bind("<F>", lambda e: chart.fit_content())
    root.bind("<equal>", lambda e: chart.zoom(1.2))   # + key
    root.bind("<minus>",  lambda e: chart.zoom(0.83))  # - key

    root.mainloop()


if __name__ == "__main__":
    main()
