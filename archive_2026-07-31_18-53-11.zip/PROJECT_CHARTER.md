# Professional Pure-Python Financial Charting Library

## Vision
- Mission
- Goals
- Non-goals

## Guiding Principles
- Architecture first
- Performance first
- Extensibility
- Maintainability
- User experience
- API design

## Reference Research
- TradingView Lightweight Charts
- KLineCharts

Rules:
- Study architecture only.
- Never copy implementations.
- Extract engineering principles.
- Design an original Python architecture.

## High-Level Architecture
- Chart Core
- Rendering Engine
- Rendering Pipeline
- Coordinate Engine
- Layout Engine
- State Store
- Event Bus
- Interaction Engine
- Drawing Engine
- Indicator Engine
- Plugin System
- Theme System
- Export System

## Dependency Rules

Public API
↓
Application
↓
Chart Core
↓
State
↓
Layout
↓
Coordinates
↓
Renderer
↓
Canvas Backend

Rules:
- No circular dependencies
- No upward dependencies
- Interface-based communication

## Development Methodology

Research
↓

Architecture
↓

Prototype
↓

Review
↓

Refactor
↓

Test
↓

Benchmark
↓

Optimize
↓

Repeat

## Milestones

0 Research

1 Architecture

2 Rendering

3 Core Engine

4 Layout

5 Interaction

6 Drawing Tools

7 Indicators

8 Plugins

9 Public API

10 Documentation

11 Optimization

## Coding Standards

- Type hints
- Docstrings
- SOLID
- Composition over inheritance
- Automated tests
- Benchmarks
- Examples
- Documentation

## Performance Philosophy

Profile first.

Optimize second.

Measure every optimization.

## Architecture Decision Records

Each major decision records:

- Problem
- Context
- Alternatives
- Decision
- Consequences
- Review trigger

## Definition of Done

Every subsystem must have:

✓ Architecture reviewed

✓ Public interfaces

✓ Tests

✓ Benchmarks

✓ Documentation

✓ Examples

✓ ADR

✓ No TODOs