"""Diagnose missing axis labels after Phase 1 render changes."""
import tkinter as tk
from datetime import datetime

from finchart import ChartWidget, OHLCV, DarkTheme


def main() -> None:
    root = tk.Tk()
    root.withdraw()
    chart = ChartWidget(root, width=800, height=500, theme=DarkTheme())
    chart.update_idletasks()

    bars = []
    base = datetime(2024, 1, 1).timestamp()
    price = 100.0
    for i in range(100):
        close = price + (i % 7) - 3
        bars.append(
            OHLCV(
                base + i * 3600,
                price,
                max(price, close) + 1,
                min(price, close) - 1,
                close,
                1e6,
            )
        )
        price = close

    chart.set_data(bars)
    for _ in range(10):
        root.update_idletasks()
        root.update()

    c = chart._canvas
    texts = []
    for item in c.find_all():
        if c.type(item) == "text" and str(c.itemcget(item, "state")) == "normal":
            texts.append(
                (c.gettags(item), c.itemcget(item, "text"), c.coords(item))
            )

    print("visible text count:", len(texts))
    for t in texts:
        print(" ", t)

    grid_items = c.find_withtag("layer_grid")
    print("layer_grid count:", len(grid_items))
    grid_text = 0
    grid_hidden_text = 0
    for item in grid_items:
        typ = c.type(item)
        state = c.itemcget(item, "state")
        if typ == "text":
            if state == "normal":
                grid_text += 1
            else:
                grid_hidden_text += 1
            print(" grid text", state, c.itemcget(item, "text"), c.coords(item), c.gettags(item))
    print("grid visible text:", grid_text, "hidden:", grid_hidden_text)

    # Simulate hover crosshair
    chart._on_mouse_move_event(
        type("E", (), {"data": {"x": 200.0, "y": 150.0}})()
    )
    for _ in range(5):
        root.update_idletasks()
        root.update()

    texts_after = [
        item
        for item in c.find_all()
        if c.type(item) == "text" and str(c.itemcget(item, "state")) == "normal"
    ]
    print("visible text after hover:", len(texts_after))
    for item in texts_after:
        print(" ", c.gettags(item), c.itemcget(item, "text"))

    # Count buffered vs current grid
    print("current GRID items:", len(chart._pipeline._current_items[__import__("finchart.rendering.pipeline", fromlist=["Layer"]).Layer.GRID]))
    root.destroy()


if __name__ == "__main__":
    main()
