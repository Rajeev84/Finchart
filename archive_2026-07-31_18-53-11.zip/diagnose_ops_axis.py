"""Diagnose axis label disappearance after theme/chart-type/indicator operations."""
import tkinter as tk
from datetime import datetime
import random

from finchart import ChartWidget, OHLCV, DarkTheme, LightTheme
from finchart.core.types import ChartType
from finchart.indicators import SMA, RSI, MACD
from finchart.rendering.pipeline import Layer


def flush(root: tk.Tk, n: int = 5) -> None:
    for _ in range(n):
        root.update_idletasks()
        root.update()


def count_visible_grid_texts(canvas: tk.Canvas) -> int:
    count = 0
    for item in canvas.find_withtag("layer_grid"):
        if canvas.type(item) == "text" and str(canvas.itemcget(item, "state")) == "normal":
            count += 1
    return count


def count_all_visible_texts(canvas: tk.Canvas) -> int:
    count = 0
    for item in canvas.find_all():
        if canvas.type(item) == "text" and str(canvas.itemcget(item, "state")) == "normal":
            count += 1
    return count


def main() -> None:
    root = tk.Tk()
    root.geometry("1440x860")
    chart = ChartWidget(root, width=1440, height=780, theme=DarkTheme())
    chart.pack(fill="both", expand=True)

    random.seed(99)
    bars = []
    price = 45000.0
    base_ts = datetime(2024, 1, 1, 0, 0).timestamp()
    for i in range(500):
        open_ = price
        change = random.gauss(0.0002 * price, 0.012 * price)
        close = max(1.0, price + change)
        high = max(open_, close) * (1.0 + abs(random.gauss(0.0, 0.004)))
        low = min(open_, close) * (1.0 - abs(random.gauss(0.0, 0.004)))
        vol = random.uniform(10_000_000, 100_000_000)
        ts = base_ts + i * 3600
        bars.append(OHLCV(timestamp=ts, open=open_, high=high, low=low, close=close, volume=vol))
        price = close

    chart.set_data(bars)
    flush(root, 20)

    def report(label: str) -> None:
        grid_texts = count_visible_grid_texts(chart._canvas)
        all_texts = count_all_visible_texts(chart._canvas)
        grid_items = len(chart._pipeline._current_items[Layer.GRID])
        series_items = len(chart._pipeline._current_items[Layer.SERIES])
        ch_items = len(chart._pipeline._current_items[Layer.CROSSHAIR])
        buffer = len(chart._pipeline._command_buffer)
        pending = chart._pipeline._pending_layers
        full = chart._pipeline._needs_full_redraw
        print(f"  {label}: grid_texts={grid_texts}, all_texts={all_texts}, "
              f"grid_items={grid_items}, series_items={series_items}, "
              f"ch_items={ch_items}, buffer={buffer}, pending={pending}, full={full}")

    print("=== INITIAL ===")
    report("initial")

    print("\n=== THEME TOGGLE ===")
    chart.set_theme(LightTheme())
    flush(root, 10)
    report("light_theme")
    chart.set_theme(DarkTheme())
    flush(root, 10)
    report("dark_theme_back")

    print("\n=== CHART TYPE SWITCH ===")
    chart.set_chart_type(ChartType.LINE)
    flush(root, 10)
    report("line")
    chart.set_chart_type(ChartType.AREA)
    flush(root, 10)
    report("area")
    chart.set_chart_type(ChartType.HISTOGRAM)
    flush(root, 10)
    report("histogram")
    chart.set_chart_type(ChartType.CANDLESTICK)
    flush(root, 10)
    report("candlestick_back")

    print("\n=== INDICATORS ===")
    sma = chart.add_indicator(SMA(20, "#2196F3"))
    flush(root, 10)
    report("sma_added")
    rsi = chart.add_indicator(RSI(14))
    flush(root, 10)
    report("rsi_added")
    macd = chart.add_indicator(MACD())
    flush(root, 10)
    report("macd_added")

    print("\n=== MOUSE MOVE WITH INDICATORS ===")
    chart._on_mouse_move_event(type("E", (), {"data": {"x": 400.0, "y": 200.0}})())
    flush(root, 5)
    report("after_hover")

    print("\n=== PAN WITH INDICATORS + HOVER ===")
    chart._coord_engine.time_scale.offset += 40
    chart._on_scale_changed_event(type("E", (), {"data": {}})())
    chart._on_mouse_move_event(type("E", (), {"data": {"x": 420.0, "y": 200.0}})())
    flush(root, 5)
    report("after_pan+hover")

    print("\n=== REMOVE INDICATORS ===")
    chart.remove_indicator(rsi)
    flush(root, 10)
    report("rsi_removed")
    chart.remove_indicator(macd)
    flush(root, 10)
    report("macd_removed")

    print("\n=== MOUSE LEAVE ===")
    chart._on_mouse_move_event(type("E", (), {"data": {"x": 400.0, "y": 200.0}})())
    flush(root, 5)
    report("before_leave")
    chart._on_mouse_move_event(type("E", (), {"data": {"x": -1.0, "y": -1.0, "leave": True}})())
    flush(root, 5)
    report("after_leave")

    print("\n=== ZOOM ===")
    chart.zoom(1.2)
    flush(root, 5)
    report("zoom_in")
    chart.zoom(0.83)
    flush(root, 5)
    report("zoom_out")

    print("\n=== FIT CONTENT ===")
    chart.fit_content()
    flush(root, 10)
    report("fit")

    print("\n=== Z-ORDER (all visible items) ===")
    for i, item in enumerate(chart._canvas.find_all()):
        state = str(chart._canvas.itemcget(item, "state"))
        if state != "normal":
            continue
        typ = chart._canvas.type(item)
        tags = chart._canvas.gettags(item)
        print(f"  [{i}] type={typ} tags={tags}")

    root.destroy()


if __name__ == "__main__":
    main()