@echo off
setlocal
title Archive Old Files - 7-Zip Backup Tool

color 0B

echo.
echo ============================================================
echo.
echo      ###    #####   ####  #####  ###  ###  #####
echo     #   #   #      #     #       # ## #  #
echo     #####   ###     ###  ###     #  ##   ###
echo     #   #   #          # #       #      #
echo     #   #   #####  ####  #####   #      #####
echo.
echo              OLD FILES ARCHIVER
echo.
echo ============================================================
echo.


:: ============================================================
:: Timestamp
:: ============================================================


for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HH-mm-ss"') do set "STAMP=%%i"

set "ARCHIVE=archive\archive_%STAMP%.zip"

echo %ARCHIVE%


:: ============================================================
:: Configuration
:: ============================================================

set "ZIP=C:\Program Files\7-Zip\7z.exe"
set "DEST=C:\Users\CoreFlow\OneDrive\Workspace\Finchart\archive"


echo [INFO] Date      : %STAMP%
echo [INFO] Archive   : %ARCHIVE%
echo [INFO] Source    : %CD%
echo [INFO] Target    : %DEST%
echo.


:: ============================================================
:: Check 7-Zip
:: ============================================================

if not exist "%ZIP%" (
    echo.
    echo ERROR: 7-Zip not found!
    echo %ZIP%
    pause
    exit /b 1
)


:: ============================================================
:: Exclusions
:: ============================================================

set "EXCLUDE="
set "EXCLUDE=%EXCLUDE% -xr!*.zip"
set "EXCLUDE=%EXCLUDE% -xr!.git"
set "EXCLUDE=%EXCLUDE% -xr!.agents"
set "EXCLUDE=%EXCLUDE% -xr!.cursor"
set "EXCLUDE=%EXCLUDE% -xr!.venv"
set "EXCLUDE=%EXCLUDE% -xr!__pycache__"
set "EXCLUDE=%EXCLUDE% -xr!node_modules"
set "EXCLUDE=%EXCLUDE% -xr!.idea"
set "EXCLUDE=%EXCLUDE% -xr!.vscode"
set "EXCLUDE=%EXCLUDE% -xr!dist"
set "EXCLUDE=%EXCLUDE% -xr!build"
set "EXCLUDE=%EXCLUDE% -xr!temp"
set "EXCLUDE=%EXCLUDE% -xr!tmp"
set "EXCLUDE=%EXCLUDE% -xr!*.pyc"
set "EXCLUDE=%EXCLUDE% -xr!*.log"
set "EXCLUDE=%EXCLUDE% -xr!*.pytest_cache"
set "EXCLUDE=%EXCLUDE% -xr!*archive"


echo ------------------------------------------------------------
echo Excluded:
echo.
echo   [X] .git
echo   [X] .agents
echo   [X] .cursor
echo   [X] .venv
echo   [X] __pycache__
echo   [X] node_modules
echo   [X] .idea
echo   [X] .vscode
echo   [X] dist
echo   [X] build
echo   [X] temp
echo   [X] tmp
echo   [X] *.pyc
echo   [X] *.log
echo.
echo ------------------------------------------------------------
echo.


:: ============================================================
:: Create archive
:: ============================================================

echo Starting compression...
echo.

"%ZIP%" a "%ARCHIVE%" * %EXCLUDE%


if errorlevel 1 (
    echo.
    echo ============================================================
    echo ERROR: Compression failed
    echo ============================================================
    pause
    exit /b 1
)


echo.
echo ============================================================
echo.
echo       +--------------------------------+
echo       ^|                                ^|
echo       ^|     ARCHIVE CREATED OK         ^|
echo       ^|                                ^|
echo       +--------------------------------+
echo.
echo File:
echo %ARCHIVE%
echo.
echo ============================================================
echo.


:: ============================================================
:: Copy Archive
:: ============================================================

if not exist "%DEST%" (
    echo Creating destination folder...
    mkdir "%DEST%"
)


echo Copying archive...
echo.

copy /Y "%ARCHIVE%" "%DEST%\"


if errorlevel 1 (
    echo.
    echo ERROR: Copy failed
    pause
    exit /b 1
)


echo.
echo ============================================================
echo.
echo       BACKUP COMPLETED SUCCESSFULLY
echo.
echo       Saved:
echo       %DEST%\%ARCHIVE%
echo.
echo ============================================================
echo.

pause