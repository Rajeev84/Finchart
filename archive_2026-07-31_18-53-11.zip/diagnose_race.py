"""Reproduce full-redraw race wiping axis labels."""
import tkinter as tk
from datetime import datetime

from finchart import ChartWidget, OHLCV, DarkTheme
from finchart.rendering.pipeline import Layer
from finchart.core.events import Event, EventType


def flush(root, n=5):
    for _ in range(n):
        root.update_idletasks()
        root.update()


def grid_text_count(c):
    n = 0
    for item in c.find_withtag("layer_grid"):
        if c.type(item) == "text" and c.itemcget(item, "state") == "normal":
            n += 1
    return n


def hover(chart, x, y):
    chart._on_mouse_move_event(Event(EventType.MOUSE_MOVE, chart, {"x": x, "y": y}))


def main():
    root = tk.Tk()
    root.withdraw()
    chart = ChartWidget(root, width=800, height=500, theme=DarkTheme())
    bars = []
    base = datetime(2024, 1, 1).timestamp()
    price = 100.0
    for i in range(80):
        close = price + (i % 5) - 2
        bars.append(OHLCV(base + i * 3600, price, max(price, close) + 1, min(price, close) - 1, close, 1))
        price = close
    chart.set_data(bars)
    flush(root)
    print("baseline grid text", grid_text_count(chart._canvas))

    # Race: force full redraw flag, then hover buffers ONLY crosshair before idle runs
    chart._pipeline._needs_full_redraw = True
    chart._pipeline.clear_commands()
    chart._pipeline._pending_layers.clear()
    hover(chart, 200.0, 100.0)
    flush(root)
    print("after race grid text", grid_text_count(chart._canvas))
    print("crosshair items", len(chart._pipeline._current_items[Layer.CROSSHAIR]))
    print("grid items", len(chart._pipeline._current_items[Layer.GRID]))
    print("series items", len(chart._pipeline._current_items[Layer.SERIES]))

    chart._request_render()
    flush(root)
    print("restored grid text", grid_text_count(chart._canvas))

    chart._pipeline.force_full_redraw()
    print("after force: buffer", len(chart._pipeline._command_buffer), "needs_full", chart._pipeline._needs_full_redraw)
    hover(chart, 220.0, 110.0)
    print(
        "after hover before idle: buffer layers",
        [c.layer.name for c in chart._pipeline._command_buffer],
    )
    flush(root)
    print("after force+hover race grid text", grid_text_count(chart._canvas))
    print("series items", len(chart._pipeline._current_items[Layer.SERIES]))

    root.destroy()


if __name__ == "__main__":
    main()
