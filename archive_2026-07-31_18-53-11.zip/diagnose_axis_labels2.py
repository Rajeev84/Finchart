"""Reproduce axis label occlusion with indicators + pan + hover."""
import tkinter as tk
from datetime import datetime

from finchart import ChartWidget, OHLCV, DarkTheme
from finchart.indicators import MACD, RSI
from finchart.rendering.pipeline import Layer


def flush(root: tk.Tk, n: int = 10) -> None:
    for _ in range(n):
        root.update_idletasks()
        root.update()


def visible_texts(canvas: tk.Canvas):
    out = []
    for item in canvas.find_all():
        if canvas.type(item) == "text" and str(canvas.itemcget(item, "state")) == "normal":
            out.append((canvas.gettags(item), canvas.itemcget(item, "text")))
    return out


def items_covering(canvas: tk.Canvas, x: float, y: float):
    hits = canvas.find_overlapping(x - 1, y - 1, x + 1, y + 1)
    rows = []
    for item in hits:
        if str(canvas.itemcget(item, "state")) != "normal":
            continue
        rows.append((canvas.type(item), canvas.gettags(item), canvas.coords(item)[:4]))
    return rows


def main() -> None:
    root = tk.Tk()
    root.geometry("1000x700")
    chart = ChartWidget(root, width=1000, height=650, theme=DarkTheme())
    chart.pack(fill="both", expand=True)

    bars = []
    base = datetime(2024, 1, 1).timestamp()
    price = 45000.0
    for i in range(200):
        close = price * (1 + ((i % 11) - 5) * 0.001)
        bars.append(
            OHLCV(
                base + i * 3600,
                price,
                max(price, close) * 1.002,
                min(price, close) * 0.998,
                close,
                1e6,
            )
        )
        price = close

    chart.set_data(bars)
    flush(root)
    print("AFTER SET", len(visible_texts(chart._canvas)), visible_texts(chart._canvas)[:5])

    chart.add_indicator(MACD())
    chart.add_indicator(RSI(14))
    flush(root)
    texts = visible_texts(chart._canvas)
    print("AFTER INDS", len(texts))
    for t in texts:
        print(" ", t)

    # Hover
    chart._on_mouse_move_event(type("E", (), {"data": {"x": 400.0, "y": 120.0}})())
    flush(root)
    texts = visible_texts(chart._canvas)
    grid_texts = [t for t in texts if "layer_grid" in t[0]]
    ch_texts = [t for t in texts if "layer_crosshair" in t[0]]
    print("AFTER HOVER grid_text", len(grid_texts), "crosshair_text", len(ch_texts))

    # Pan
    chart._coord_engine.time_scale.offset += 40
    chart._on_scale_changed_event(type("E", (), {"data": {}})())
    flush(root)
    texts = visible_texts(chart._canvas)
    grid_texts = [t for t in texts if "layer_grid" in t[0]]
    print("AFTER PAN grid_text", len(grid_texts))
    for t in grid_texts:
        print(" ", t)

    # Check stacking at a price label position
    if grid_texts:
        # find a price tick item
        for item in chart._canvas.find_withtag("layer_grid"):
            if chart._canvas.type(item) == "text" and "price_tick" in chart._canvas.gettags(item):
                x, y = chart._canvas.coords(item)
                print("price label at", x, y, chart._canvas.itemcget(item, "text"))
                print(" overlapping:")
                for row in items_covering(chart._canvas, x, y):
                    print("  ", row)
                # stack order: higher find_all index roughly later
                break

    for item in chart._canvas.find_withtag("layer_grid"):
        if chart._canvas.type(item) == "text" and "time_tick" in chart._canvas.gettags(item):
            x, y = chart._canvas.coords(item)
            print("time label at", x, y, chart._canvas.itemcget(item, "text"))
            print(" overlapping:")
            for row in items_covering(chart._canvas, x, y):
                print("  ", row)
            break

    # Print layer raise order check: is any non-grid rect covering full time axis?
    vp = chart._coord_engine.viewport
    axis_y = vp.bottom - 25
    print("time axis strip overlaps at center:")
    for row in items_covering(chart._canvas, vp.width / 2, axis_y + 12):
        print(" ", row)

    print("GRID current", len(chart._pipeline._current_items[Layer.GRID]))
    print("SERIES current", len(chart._pipeline._current_items[Layer.SERIES]))
    print("CROSSHAIR current", len(chart._pipeline._current_items[Layer.CROSSHAIR]))

    root.destroy()


if __name__ == "__main__":
    main()
