# FinChart

FinChart is a professional, high-performance financial charting library implemented in **100% pure Python** using **Tkinter Canvas** as the rendering backend. 

It provides the responsiveness, interaction quality, aesthetic elegance, and extensibility of **TradingView Lightweight Charts** while remaining completely native to standard Python GUI applications.

---

## Key Features

- **TradingView-Grade Interaction**: Smooth mouse wheel zooming around the cursor, low-latency click-and-drag panning, interactive crosshairs, snapping, and shape resize handles.
- **High-Performance Retained-Mode Renderer**: Stable 60 FPS rendering using canvas item pooling, viewport index clipping (culling non-visible bars), dirty layer isolation, and deferred invalidation.
- **Multi-Pane Layout Engine**: Divide canvas space into multiple subplots (e.g. Candlesticks, Volume, RSI, MACD) with relative height weights and automatic resizing.
- **Standard Technical Indicators**: Out-of-the-box SMA, EMA, RSI, MACD, and Bollinger Bands calculated with zero external dependencies.
- **Interactive Drawing Tools**: Built-in interactive shapes (TrendLines, HorizontalLines, VerticalLines, Rectangles) with resize handles, selection states, and JSON session persistence.
- **Pure Python Architecture**: Zero C/C++ build chains, zero web-views or browser wrappers. Runs natively anywhere Python and standard Tkinter are supported.

---

## Installation & Requirements

FinChart is pure-Python and does not require any heavy third-party packages. It requires Python 3.8+ and standard `tkinter` support.

To install standard packages for development/demos:
```bash
pip install -e .
```

---

## Getting Started

Here is a basic example of running a chart widget:

```python
import tkinter as tk
from finchart import ChartWidget, OHLCV
from finchart.indicators import SMA

# 1. Create root window
root = tk.Tk()
root.title("FinChart Quickstart")
root.geometry("1024x768")

# 2. Initialize widget
chart = ChartWidget(root, width=1024, height=700)
chart.pack(fill="both", expand=True)

# 3. Load bar data
bars = [
    OHLCV(timestamp=1700000000.0, open=100.0, high=105.0, low=95.0, close=102.0),
    OHLCV(timestamp=1700000060.0, open=102.0, high=108.0, low=101.0, close=106.0),
    # Add more bars here...
]
chart.set_data(bars)

# 4. Add indicators
chart.add_indicator(SMA(20, color="#2196F3"))

# 5. Start event loop
root.mainloop()
```

---

## Running Demos & Verification

We provide pre-built test suites and interactive demos:

1. **Basic Usage Demo**:
   ```bash
   python demo_1.py
   ```
   *Controls:* `T` to toggle theme, `L` for line chart, `A` for area, `C` for candlesticks, `F` to auto-fit, `+`/`-` to zoom, left-click drag to pan.

2. **Full Features Demo**:
   ```bash
   python demo_fullfeatures.py
   ```
   *Features:* Toggles for SMA, EMA, Bollinger Bands, RSI, MACD, real-time live data streaming simulator, multi-dataset resizing (100 to 2000 bars), and session serialization.

3. **Performance Benchmark**:
   ```bash
   python verify_benchmark.py
   ```

4. **Unit Verification Suite**:
   ```bash
   python verify_1.py
   python verify_2.py
   python verify_3.py
   ```

---

## Architecture & Subsystems

FinChart is composed of decoupled core subsystems:
1. `api`: Main public wrapper `ChartWidget`.
2. `core`: Core types (`OHLCV`, `Viewport`, `Color`, `EventBus`, `DataStore`).
3. `coordinates`: Bidirectional pixel-to-value coordinate transformations (`CoordinateEngine`, `TimeScale`, `PriceScale`).
4. `layout`: Bounding-box multi-pane partition engine (`LayoutEngine`).
5. `rendering`: Deferred retained-mode drawing pipeline and specialized renderers (`CanvasItemPool`, `SeriesRenderer`, `GridRenderer`, `CrosshairRenderer`).
6. `interaction`: Mouse and keyboard controllers (`InteractionController`, `hit_test`).
7. `indicators`: Plugin indicator calculations and visualizations.
8. `drawing`: Interactive overlay shapes.
9. `themes`: Color palettes.
10. `utils`: Math helpers.

See `/docs` and `/wiki` for comprehensive technical design specifications.

---

## License

This project is licensed under the MIT License.
